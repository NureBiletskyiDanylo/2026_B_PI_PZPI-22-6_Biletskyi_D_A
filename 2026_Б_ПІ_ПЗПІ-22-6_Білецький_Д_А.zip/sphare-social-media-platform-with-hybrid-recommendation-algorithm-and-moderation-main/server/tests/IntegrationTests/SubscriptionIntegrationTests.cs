﻿using System.Net;
using System.Net.Http.Headers;
using System.Net.Http.Json;
using Application.DTOs.AccountDTOs;
using Application.DTOs.UserDTOs;
using FluentAssertions;
using IntegrationTests.Core;

namespace IntegrationTests;

public class SubscriptionIntegrationTests : IClassFixture<CustomWebApplicationFactory>
{
    private readonly HttpClient _client;
    private readonly CustomWebApplicationFactory _factory;
 
    public SubscriptionIntegrationTests(CustomWebApplicationFactory factory)
    {
        _factory = factory;
        _client = factory.CreateClient();
    }
 
    private async Task<AccountClaimsDto> RegisterUserAsync(string usernamePrefix)
    {
        var suffix = Guid.NewGuid().ToString("N")[..8];
 
        using var content = new MultipartFormDataContent();
        content.Add(new StringContent($"{usernamePrefix}{suffix}"), "Username");
        content.Add(new StringContent($"{usernamePrefix}{suffix}@test.com"), "Email");
        content.Add(new StringContent("TestPass123!"), "Password");
 
        var response = await _client.PostAsync("/api/account/register", content);
        response.StatusCode.Should().Be(HttpStatusCode.OK);
 
        return (await response.Content.ReadFromJsonAsync<AccountClaimsDto>())!;
    }
 
    private HttpClient AuthorizedClient(string token)
    {
        var client = _factory.CreateClient();
        client.DefaultRequestHeaders.Authorization =
            new AuthenticationHeaderValue("Bearer", token);
        return client;
    }
 
    [Fact]
    public async Task Subscribe_Should_Increase_FollowersCount_And_Be_Reflected_In_IsFollowing()
    {
        // Arrange
 
        var follower = await RegisterUserAsync("follower");
        var target = await RegisterUserAsync("target");
 
        using var followerClient = AuthorizedClient(follower.Token);
 
        // Act
 
        var subscribeResponse =
            await followerClient.PostAsJsonAsync(
                "/api/subscription/subscribe",
                target.UniqueNameIdentifier);
 
        // Assert
 
        subscribeResponse.StatusCode.Should().Be(HttpStatusCode.OK);
 
        var countResponse =
            await followerClient.GetAsync(
                $"/api/subscription/followers-count?uniqueNameIdentifier={target.UniqueNameIdentifier}");
 
        countResponse.StatusCode.Should().Be(HttpStatusCode.OK);
        (await countResponse.Content.ReadFromJsonAsync<int>()).Should().Be(1);
 
        var isFollowingResponse =
            await followerClient.GetAsync(
                $"/api/subscription/is-following?uniqueNameIdentifier={target.UniqueNameIdentifier}");
 
        isFollowingResponse.StatusCode.Should().Be(HttpStatusCode.OK);
        (await isFollowingResponse.Content.ReadFromJsonAsync<bool>()).Should().BeTrue();
    }
 
    [Fact]
    public async Task Unsubscribe_Should_Decrease_FollowersCount_And_Be_Reflected_In_IsFollowing()
    {
        // Arrange
 
        var follower = await RegisterUserAsync("unfollower");
        var target = await RegisterUserAsync("unfoltarget");
 
        using var followerClient = AuthorizedClient(follower.Token);
 
        await followerClient.PostAsJsonAsync(
            "/api/subscription/subscribe",
            target.UniqueNameIdentifier);
 
        // Act
 
        var unsubscribeResponse =
            await followerClient.PostAsJsonAsync(
                "/api/subscription/unsubscribe",
                target.UniqueNameIdentifier);
 
        // Assert
 
        unsubscribeResponse.StatusCode.Should().Be(HttpStatusCode.OK);
 
        var countResponse =
            await followerClient.GetAsync(
                $"/api/subscription/followers-count?uniqueNameIdentifier={target.UniqueNameIdentifier}");
 
        (await countResponse.Content.ReadFromJsonAsync<int>()).Should().Be(0);
 
        var isFollowingResponse =
            await followerClient.GetAsync(
                $"/api/subscription/is-following?uniqueNameIdentifier={target.UniqueNameIdentifier}");
 
        (await isFollowingResponse.Content.ReadFromJsonAsync<bool>()).Should().BeFalse();
    }
 
    [Fact]
    public async Task GetFollowers_Should_Return_User_Who_Subscribed()
    {
        // Arrange
 
        var follower = await RegisterUserAsync("flwr");
        var target = await RegisterUserAsync("flwrtarget");
 
        using var followerClient = AuthorizedClient(follower.Token);
 
        await followerClient.PostAsJsonAsync(
            "/api/subscription/subscribe",
            target.UniqueNameIdentifier);
 
        // Act
 
        var response =
            await followerClient.GetAsync(
                $"/api/subscription/followers?uniqueNameIdentifier={target.UniqueNameIdentifier}");
 
        // Assert
 
        response.StatusCode.Should().Be(HttpStatusCode.OK);
 
        var followers = await response.Content.ReadFromJsonAsync<List<PublicUserDto>>();
 
        followers.Should().ContainSingle(u =>
            u.UniqueNameIdentifier == follower.UniqueNameIdentifier);
    }
 
    [Fact]
    public async Task GetSubscriptions_Should_Return_Target_User_For_Follower()
    {
        // Arrange
 
        var follower = await RegisterUserAsync("subr");
        var target = await RegisterUserAsync("subrtarget");
 
        using var followerClient = AuthorizedClient(follower.Token);
 
        await followerClient.PostAsJsonAsync(
            "/api/subscription/subscribe",
            target.UniqueNameIdentifier);
 
        // Act
 
        var response =
            await followerClient.GetAsync(
                $"/api/subscription/subscriptions?uniqueNameIdentifier={follower.UniqueNameIdentifier}");
 
        // Assert
 
        response.StatusCode.Should().Be(HttpStatusCode.OK);
 
        var subscriptions = await response.Content.ReadFromJsonAsync<List<PublicUserDto>>();
 
        subscriptions.Should().ContainSingle(u =>
            u.UniqueNameIdentifier == target.UniqueNameIdentifier);
    }
 
    [Fact]
    public async Task Subscribe_To_NonExistent_User_Should_Return_BadRequest()
    {
        // Arrange
 
        var follower = await RegisterUserAsync("gfollower");
 
        using var followerClient = AuthorizedClient(follower.Token);
 
        // Act
 
        var response =
            await followerClient.PostAsJsonAsync(
                "/api/subscription/subscribe",
                "this-user-does-not-exist");
 
        // Assert
 
        response.StatusCode.Should().Be(HttpStatusCode.BadRequest);
    }
 
    [Fact]
    public async Task Subscribe_Without_Authorization_Should_Return_Unauthorized()
    {
        // Arrange
 
        var target = await RegisterUserAsync("noauthtarget");
 
        // Act -- свідомо НЕ додаємо токен авторизації
 
        var response =
            await _client.PostAsJsonAsync(
                "/api/subscription/subscribe",
                target.UniqueNameIdentifier);
 
        // Assert
 
        response.StatusCode.Should().Be(HttpStatusCode.Unauthorized);
    }
 
    [Fact]
    public async Task GetFollowersCount_Without_Authorization_Should_Still_Work()
    {
        // Arrange -- цей ендпоінт НЕ позначений [Authorize] в контролері
 
        var target = await RegisterUserAsync("pbtarget");
 
        // Act
 
        var response =
            await _client.GetAsync(
                $"/api/subscription/followers-count?uniqueNameIdentifier={target.UniqueNameIdentifier}");
 
        // Assert
 
        response.StatusCode.Should().Be(HttpStatusCode.OK);
        (await response.Content.ReadFromJsonAsync<int>()).Should().Be(0);
    }
}