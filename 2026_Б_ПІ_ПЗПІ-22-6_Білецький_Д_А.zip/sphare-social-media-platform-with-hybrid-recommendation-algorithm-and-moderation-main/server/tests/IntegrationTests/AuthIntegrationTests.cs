using System.Net;
using System.Net.Http.Headers;
using System.Net.Http.Json;
using Application.Core;
using Application.DTOs.AccountDTOs;
using FluentAssertions;
using IntegrationTests.Core;

namespace IntegrationTests;

public class AuthIntegrationTests : IClassFixture<CustomWebApplicationFactory>
{
    private readonly HttpClient _client;

    public AuthIntegrationTests(CustomWebApplicationFactory factory)
    {
        _client = factory.CreateClient();
    }
    
    [Fact]
    public async Task Login_With_Valid_Credentials_Should_Return_Token()
    {
        // Arrange

        var loginDto = new LoginDto
        {
            Email = "admin@test.com",
            Password = "Admin123!"
        };

        // Act

        var response =
            await _client.PostAsJsonAsync(
                "/api/account/login",
                loginDto);

        // Assert

        response.StatusCode.Should().Be(HttpStatusCode.OK);

        var result = await response.Content.ReadFromJsonAsync<AccountClaimsDto>();

        result!.Token.Should().NotBeNullOrEmpty();
    }
    
    [Fact]
    public async Task Register_With_Valid_Data_Should_Return_Token()
    {
        // Arrange

        using var content = new MultipartFormDataContent();

        content.Add(new StringContent("newuser123"), "Username");
        content.Add(new StringContent("newuser@test.com"), "Email");
        content.Add(new StringContent("NewUser123!"), "Password");

        // Act

        var response =
            await _client.PostAsync(
                "/api/account/register",
                content);

        // Assert

        response.StatusCode
            .Should()
            .Be(HttpStatusCode.OK);

        var result =
            await response.Content
                .ReadFromJsonAsync<AccountClaimsDto>();

        result!.Token.Should().NotBeNullOrEmpty();
        result.Username.Should().Be("newuser123");
    }
    
    [Fact]
    public async Task Register_With_Existing_Email_Should_Return_BadRequest()
    {
        // Arrange

        using var content = new MultipartFormDataContent();

        content.Add(new StringContent("anotherusername"), "Username");
        content.Add(new StringContent("admin@test.com"), "Email"); // вже існує
        content.Add(new StringContent("SomePass123!"), "Password");

        // Act

        var response =
            await _client.PostAsync(
                "/api/account/register",
                content);

        // Assert

        response.StatusCode
            .Should()
            .Be(HttpStatusCode.BadRequest);
    }
    
    [Fact]
    public async Task Register_With_Profile_Image_Should_Return_Token()
    {
        // Arrange

        using var content = new MultipartFormDataContent();

        content.Add(new StringContent("userwithpic"), "Username");
        content.Add(new StringContent("userwithpic@test.com"), "Email");
        content.Add(new StringContent("UserPic123!"), "Password");

        // Невеликий валідний PNG-байт-масив (1x1 пікс.), щоб не тягнути реальний файл з диску
        byte[] imageBytes =
        [
            0x89, 0x50, 0x4E, 0x47, 0x0D, 0x0A, 0x1A, 0x0A,
            0x00, 0x00, 0x00, 0x0D, 0x49, 0x48, 0x44, 0x52,
            0x00, 0x00, 0x00, 0x01, 0x00, 0x00, 0x00, 0x01,
            0x08, 0x06, 0x00, 0x00, 0x00, 0x1F, 0x15, 0xC4,
            0x89, 0x00, 0x00, 0x00, 0x0D, 0x49, 0x44, 0x41,
            0x54, 0x78, 0x9C, 0x62, 0x00, 0x01, 0x00, 0x00,
            0x05, 0x00, 0x01, 0x0D, 0x0A, 0x2D, 0xB4, 0x00,
            0x00, 0x00, 0x00, 0x49, 0x45, 0x4E, 0x44, 0xAE,
            0x42, 0x60, 0x82
        ];

        using var imageContent = new ByteArrayContent(imageBytes);
        imageContent.Headers.ContentType =
            new MediaTypeHeaderValue("image/png");

        content.Add(imageContent, "Image", "test-avatar.png");

        // Act

        var response =
            await _client.PostAsync(
                "/api/account/register",
                content);

        // Assert

        response.StatusCode
            .Should()
            .Be(HttpStatusCode.OK);

        var result =
            await response.Content
                .ReadFromJsonAsync<AccountClaimsDto>();

        result!.Token.Should().NotBeNullOrEmpty();
    }
}