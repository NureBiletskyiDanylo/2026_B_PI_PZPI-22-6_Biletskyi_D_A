﻿using Application.Interfaces.Services;
using CloudinaryDotNet.Actions;
using Microsoft.AspNetCore.Http;

namespace IntegrationTests.Core;

public class FakeCloudinaryService : ICloudinaryService
{
    public Task<ImageUploadResult> AddPhotoAsync(IFormFile image)
    {
        return Task.FromResult(BuildSuccessResult(Guid.NewGuid().ToString()));
    }
 
    public Task<List<ImageUploadResult>> AddPhotosAsync(List<IFormFile> images)
    {
        var results = images
            .Select(_ => BuildSuccessResult(Guid.NewGuid().ToString()))
            .ToList();
 
        return Task.FromResult(results);
    }
 
    public Task<ImageUploadResult> AddProfilePhotoAsync(IFormFile image, string userId)
    {
        return Task.FromResult(BuildSuccessResult($"{userId}_profile"));
    }
 
    public Task<ImageUploadResult> AddProfilePhotoAsyncWithReplacement(
        IFormFile image, string userId, string publicId)
    {
        return Task.FromResult(BuildSuccessResult(publicId));
    }
 
    public Task<DeletionResult> DeletePhotoAsync(string publicId)
    {
        return Task.FromResult(new DeletionResult
        {
            Result = "ok"
        });
    }
 
    public Task<DelResResult> DeletePhotosAsync(List<string> imageIds)
    {
        return Task.FromResult(new DelResResult());
    }
 
    private static ImageUploadResult BuildSuccessResult(string publicId)
    {
        return new ImageUploadResult
        {
            PublicId = publicId,
            Url = new Uri($"https://fake-cloudinary.test/{publicId}.png"),
            SecureUrl = new Uri($"https://fake-cloudinary.test/{publicId}.png"),
            Error = null
        };
    }
}
