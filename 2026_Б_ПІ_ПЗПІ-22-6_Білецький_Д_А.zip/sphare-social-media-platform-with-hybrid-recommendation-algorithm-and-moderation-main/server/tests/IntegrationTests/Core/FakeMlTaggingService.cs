﻿using Application.Interfaces.Services;
using Application.Models;

namespace IntegrationTests.Core;

public class FakeMlTaggingService : IMlTaggingService
{
    public Task<TagExtractionResult?> ExtractTagsAsync(
        string text, List<string> existingTags, CancellationToken ct)
    {
        var candidateWords = text
            .Split(' ', StringSplitOptions.RemoveEmptyEntries | StringSplitOptions.TrimEntries)
            .Select(w => w.Trim('.', ',', '!', '?').ToLowerInvariant())
            .Where(w => w.Length > 4)
            .Distinct()
            .Take(5)
            .ToList();
 
        var existingSet = existingTags
            .Select(t => t.ToLowerInvariant())
            .ToHashSet();
 
        var newTags = candidateWords
            .Where(w => !existingSet.Contains(w))
            .ToList();
 
        return Task.FromResult<TagExtractionResult?>(new TagExtractionResult
        {
            MatchedTags = candidateWords,
            NewTags = newTags
        });
    }
}