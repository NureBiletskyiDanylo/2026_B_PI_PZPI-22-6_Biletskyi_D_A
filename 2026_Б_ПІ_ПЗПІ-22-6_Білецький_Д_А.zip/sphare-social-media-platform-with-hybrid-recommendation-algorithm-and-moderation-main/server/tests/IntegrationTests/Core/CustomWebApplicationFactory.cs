﻿using Application.DTOs.AccountDTOs;
using Application.Interfaces.Services;
using Infrastructure;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Mvc.Testing;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.DependencyInjection.Extensions; // <-- ADD THIS
using Neo4j.Driver;
using Testcontainers.Neo4j;
using Testcontainers.PostgreSql;

namespace IntegrationTests.Core;

public class CustomWebApplicationFactory : WebApplicationFactory<Program>, IAsyncLifetime
{
    private readonly PostgreSqlContainer _dbContainer = new PostgreSqlBuilder("postgres:16-alpine")
        .WithDatabase("sphare_test")
        .WithUsername("test")
        .WithPassword("test")
        .Build();
 
    private readonly Neo4jContainer _neo4JContainer = new Neo4jBuilder("neo4j:5-community")
        .Build();
 
    protected override void ConfigureWebHost(IWebHostBuilder builder)
    {
        builder.UseEnvironment("Testing");
 
        builder.ConfigureServices(services =>
        {
            // 1. Replace DbContextOptions
            services.RemoveAll<DbContextOptions<ApplicationDbContext>>();
            services.AddDbContext<ApplicationDbContext>(options =>
                options.UseNpgsql(_dbContainer.GetConnectionString()));
 
            // 2. Replace Neo4j IDriver
            services.RemoveAll<IDriver>();
            services.AddSingleton<IDriver>(_ => GraphDatabase.Driver(
                _neo4JContainer.GetConnectionString(),
                AuthTokens.None));
 
            // 3. Replace ICloudinaryService
            services.RemoveAll<ICloudinaryService>();
            services.AddScoped<ICloudinaryService, FakeCloudinaryService>();
            
            // 4. Replace IMlTaggingService
            services.RemoveAll<IMlTaggingService>();
            services.AddScoped<IMlTaggingService, FakeMlTaggingService>();
        });
    }
 
    public async Task InitializeAsync()
    {
        await Task.WhenAll(
            _dbContainer.StartAsync(),
            _neo4JContainer.StartAsync());
 
        using var scope = Services.CreateScope();
        var sp = scope.ServiceProvider;
 
        var db = sp.GetRequiredService<ApplicationDbContext>();
        await db.Database.MigrateAsync();
 
        var accountService = sp.GetRequiredService<IAccountService>();
 
        var registerDto = new RegisterDto
        {
            Username = "admin",
            Email = "admin@test.com",
            Password = "Admin123!"
        };
 
        var result = await accountService.RegisterAsync(registerDto, CancellationToken.None);
 
        if (!result.IsSuccess)
            throw new Exception($"Failed to seed test user: {result.Error}");
    }
 
    public new async Task DisposeAsync()
    {
        await Task.WhenAll(
            _dbContainer.StopAsync(),
            _neo4JContainer.StopAsync());
    }
}