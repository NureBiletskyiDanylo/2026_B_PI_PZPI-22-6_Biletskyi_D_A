﻿using System.Net;
using System.Net.Http.Headers;
using System.Net.Http.Json;
using Application.DTOs.AccountDTOs;
using Application.DTOs.PublicationDTOs;
using Domain.Enums;
using FluentAssertions;
using IntegrationTests.Core;

namespace IntegrationTests;

public class PublicationIntegrationTests : IClassFixture<CustomWebApplicationFactory>
{
    private readonly HttpClient _client;
    private readonly CustomWebApplicationFactory _factory;
 
    public PublicationIntegrationTests(CustomWebApplicationFactory factory)
    {
        _factory = factory;
        _client = factory.CreateClient();
    }
 
    private async Task<AccountClaimsDto> RegisterUserAsync(string usernamePrefix)
    {
        var suffix = Guid.NewGuid().ToString("N")[..8];
        var trimmedPrefix = usernamePrefix.Length > 12 ? usernamePrefix[..12] : usernamePrefix;
        var username = $"{trimmedPrefix}{suffix}";

        using var content = new MultipartFormDataContent();
        content.Add(new StringContent(username), "Username");
        content.Add(new StringContent($"{username}@test.com"), "Email");
    
        content.Add(new StringContent("TestPassword123!"), "Password"); 

        var response = await _client.PostAsync("/api/account/register", content);
        response.StatusCode.Should().Be(HttpStatusCode.OK);

        return (await response.Content.ReadFromJsonAsync<AccountClaimsDto>())!;
    }
 
    private HttpClient AuthorizedClient(string token)
    {
        var client = _factory.CreateClient();
        client.DefaultRequestHeaders.Authorization =
            new AuthenticationHeaderValue("Bearer", token);
        return client;
    }
 
    private static MultipartFormDataContent BuildOrdinaryPublicationContent(string textContent)
    {
        var content = new MultipartFormDataContent
        {
            { new StringContent(textContent), "content" },
            { new StringContent("ordinary"), "publicationType" }
        };
        return content;
    }
 
    [Fact]
    public async Task CreatePublication_With_Valid_Content_Should_Return_OK_With_Id()
    {
        // Arrange
 
        var author = await RegisterUserAsync("pubauthor");
        using var authorClient = AuthorizedClient(author.Token);
 
        using var content = BuildOrdinaryPublicationContent("My first integration-tested post");
 
        // Act
 
        var response =
            await authorClient.PostAsync("/api/publication/create-publication", content);
 
        // Assert
 
        response.StatusCode.Should().Be(HttpStatusCode.OK);
 
        var publicationId = await response.Content.ReadAsStringAsync();
        publicationId.Should().NotBeNullOrWhiteSpace();
    }
 
    [Fact]
    public async Task CreatePublication_Without_Content_And_Images_Should_Return_BadRequest()
    {
        // Arrange
 
        var author = await RegisterUserAsync("emptypub");
        using var authorClient = AuthorizedClient(author.Token);
 
        // Свідомо НЕ додаємо ні content, ні images -- порушує IValidatableObject.Validate
        using var content = new MultipartFormDataContent
        {
            { new StringContent("ordinary"), "publicationType" }
        };
 
        // Act
 
        var response =
            await authorClient.PostAsync("/api/publication/create-publication", content);
 
        // Assert
 
        response.StatusCode.Should().Be(HttpStatusCode.BadRequest);
    }
 
    [Fact]
    public async Task CreatePublication_Without_Authorization_Should_Return_Unauthorized()
    {
        // Arrange
 
        using var content = BuildOrdinaryPublicationContent("Should never be created");
 
        // Act -- свідомо без токена, через звичайний _client
 
        var response =
            await _client.PostAsync("/api/publication/create-publication", content);
 
        // Assert
 
        response.StatusCode.Should().Be(HttpStatusCode.Unauthorized);
    }
 
    [Fact]
    public async Task GetPublicationById_After_Creation_Should_Return_Matching_Content_And_IsOwner_True()
    {
        // Arrange
 
        var author = await RegisterUserAsync("getpubowner");
        using var authorClient = AuthorizedClient(author.Token);
 
        const string publicationText = "Content to verify after fetch";
 
        using var createContent = BuildOrdinaryPublicationContent(publicationText);
        var createResponse =
            await authorClient.PostAsync("/api/publication/create-publication", createContent);
 
        createResponse.StatusCode.Should().Be(HttpStatusCode.OK);
        var publicationId = await createResponse.Content.ReadAsStringAsync();
 
        // Act
 
        var getResponse =
            await authorClient.GetAsync($"/api/publication/{publicationId}");
 
        // Assert
 
        getResponse.StatusCode.Should().Be(HttpStatusCode.OK);
 
        var publication = await getResponse.Content.ReadFromJsonAsync<PublicationDto>();
 
        publication!.Content.Should().Be(publicationText);
        publication.PublicationType.Should().Be(PublicationTypes.ordinary);
        publication.IsOwner.Should().BeTrue();
        publication.Author.Should().NotBeNull();
    }
 
    [Fact]
    public async Task GetPublicationById_From_NonOwner_Should_Return_IsOwner_False()
    {
        // Arrange
 
        var author = await RegisterUserAsync("realowner");
        using var authorClient = AuthorizedClient(author.Token);
 
        using var createContent = BuildOrdinaryPublicationContent("Visible to others too");
        var createResponse =
            await authorClient.PostAsync("/api/publication/create-publication", createContent);
 
        var publicationId = await createResponse.Content.ReadAsStringAsync();
 
        var viewer = await RegisterUserAsync("viewernotowner");
        using var viewerClient = AuthorizedClient(viewer.Token);
 
        // Act
 
        var getResponse =
            await viewerClient.GetAsync($"/api/publication/{publicationId}");
 
        // Assert
 
        getResponse.StatusCode.Should().Be(HttpStatusCode.OK);
 
        var publication = await getResponse.Content.ReadFromJsonAsync<PublicationDto>();
        publication!.IsOwner.Should().BeFalse();
    }
 
    [Fact]
    public async Task GetPublicationById_With_NonExistent_Id_Should_Return_NotFound()
    {
        // Arrange
 
        var author = await RegisterUserAsync("ghostpubuser");
        using var authorClient = AuthorizedClient(author.Token);
 
        // Act
 
        var response =
            await authorClient.GetAsync($"/api/publication/{Guid.NewGuid()}");
 
        // Assert
 
        response.StatusCode.Should().Be(HttpStatusCode.NotFound);
    }
 
    [Fact]
    public async Task DeletePublication_By_Owner_Should_Return_OK_And_Then_NotFound_On_Fetch()
    {
        // Arrange
 
        var author = await RegisterUserAsync("deleter");
        using var authorClient = AuthorizedClient(author.Token);
 
        using var createContent = BuildOrdinaryPublicationContent("To be deleted");
        var createResponse =
            await authorClient.PostAsync("/api/publication/create-publication", createContent);
 
        var publicationId = await createResponse.Content.ReadAsStringAsync();
 
        // Act
 
        var deleteResponse =
            await authorClient.DeleteAsync($"/api/publication/{publicationId}");
 
        // Assert
 
        deleteResponse.StatusCode.Should().Be(HttpStatusCode.OK);
 
        var getAfterDeleteResponse =
            await authorClient.GetAsync($"/api/publication/{publicationId}");
 
        getAfterDeleteResponse.StatusCode.Should().Be(HttpStatusCode.OK);
        
        var publication = await getAfterDeleteResponse.Content.ReadFromJsonAsync<PublicationDto>();
        publication!.IsDeleted.Should().BeTrue();
    }
 
    [Fact]
    public async Task DeletePublication_By_NonOwner_Should_Return_Forbidden_Or_BadRequest()
    {
        // Arrange
 
        var author = await RegisterUserAsync("rightfulowner");
        using var authorClient = AuthorizedClient(author.Token);
 
        using var createContent = BuildOrdinaryPublicationContent("Not yours to delete");
        var createResponse =
            await authorClient.PostAsync("/api/publication/create-publication", createContent);
 
        var publicationId = await createResponse.Content.ReadAsStringAsync();
 
        var intruder = await RegisterUserAsync("intruderuser");
        using var intruderClient = AuthorizedClient(intruder.Token);
 
        // Act
 
        var deleteResponse =
            await intruderClient.DeleteAsync($"/api/publication/{publicationId}");
 
        // Assert
 
        deleteResponse.StatusCode.Should().Match(code =>
            code == HttpStatusCode.Forbidden || code == HttpStatusCode.BadRequest);
    }
}