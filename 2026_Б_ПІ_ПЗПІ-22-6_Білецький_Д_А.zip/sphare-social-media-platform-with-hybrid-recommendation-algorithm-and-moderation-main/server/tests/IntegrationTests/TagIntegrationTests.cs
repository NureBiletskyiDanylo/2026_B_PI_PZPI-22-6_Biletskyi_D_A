﻿using System.Net;
using System.Net.Http.Headers;
using System.Net.Http.Json;
using Application.DTOs.AccountDTOs;
using Application.DTOs.TagDTOs;
using FluentAssertions;
using IntegrationTests.Core;

namespace IntegrationTests;

public class TagIntegrationTests : IClassFixture<CustomWebApplicationFactory>
{
    private readonly HttpClient _client;
    private readonly CustomWebApplicationFactory _factory;
 
    public TagIntegrationTests(CustomWebApplicationFactory factory)
    {
        _factory = factory;
        _client = factory.CreateClient();
    }
 
    private async Task<AccountClaimsDto> RegisterUserAsync(string usernamePrefix)
    {
        var suffix = Guid.NewGuid().ToString("N")[..8];
        var trimmedPrefix = usernamePrefix.Length > 12 ? usernamePrefix[..12] : usernamePrefix;
        var username = $"{trimmedPrefix}{suffix}";
 
        using var content = new MultipartFormDataContent();
        content.Add(new StringContent(username), "Username");
        content.Add(new StringContent($"{username}@test.com"), "Email");
        content.Add(new StringContent("TestPass123!"), "Password");
 
        var response = await _client.PostAsync("/api/account/register", content);
        response.StatusCode.Should().Be(HttpStatusCode.OK);
 
        return (await response.Content.ReadFromJsonAsync<AccountClaimsDto>())!;
    }
 
    private HttpClient AuthorizedClient(string token)
    {
        var client = _factory.CreateClient();
        client.DefaultRequestHeaders.Authorization =
            new AuthenticationHeaderValue("Bearer", token);
        return client;
    }
 
    private async Task<string> CreatePublicationAsync(HttpClient authorClient, string textContent)
    {
        using var content = new MultipartFormDataContent
        {
            { new StringContent(textContent), "content" },
            { new StringContent("ordinary"), "publicationType" }
        };
 
        var response =
            await authorClient.PostAsync("/api/publication/create-publication", content);
 
        response.StatusCode.Should().Be(HttpStatusCode.OK);
 
        return await response.Content.ReadAsStringAsync();
    }
 
    [Fact]
    public async Task AddTag_By_Owner_Should_Return_OK_And_Tag_Should_Appear_In_GetTagsForPublication()
    {
        // Arrange
 
        var author = await RegisterUserAsync("tagauthor");
        using var authorClient = AuthorizedClient(author.Token);
 
        var publicationId = await CreatePublicationAsync(authorClient, "A publication about cooking");
 
        var tagDto = new CreateTagDto { Name = "Cooking" };
 
        // Act
 
        var addResponse =
            await authorClient.PostAsJsonAsync(
                $"/api/tag/add-tag?publicationId={publicationId}",
                tagDto);
 
        // Assert
 
        addResponse.StatusCode.Should().Be(HttpStatusCode.OK);
 
        var getResponse =
            await authorClient.GetAsync($"/api/tag/tags-publication?publicationId={publicationId}");
 
        getResponse.StatusCode.Should().Be(HttpStatusCode.OK);
 
        var tags = await getResponse.Content.ReadFromJsonAsync<List<TagDto>>();
 
        tags.Should().ContainSingle(t => t.Name == "cooking");
    }
 
    [Fact]
    public async Task AddTag_By_NonAuthor_Should_Return_Unauthorized()
    {
        // Arrange
 
        var author = await RegisterUserAsync("realtagowner");
        using var authorClient = AuthorizedClient(author.Token);
 
        var publicationId = await CreatePublicationAsync(authorClient, "Someone else's publication");
 
        var intruder = await RegisterUserAsync("tagintruder");
        using var intruderClient = AuthorizedClient(intruder.Token);
 
        var tagDto = new CreateTagDto { Name = "ShouldNotBeAdded" };
 
        // Act
 
        var response =
            await intruderClient.PostAsJsonAsync(
                $"/api/tag/add-tag?publicationId={publicationId}",
                tagDto);
 
        // Assert
 
        response.StatusCode.Should().Be(HttpStatusCode.Forbidden);
    }
 
    [Fact]
    public async Task AddTag_On_NonExistent_Publication_Should_Return_NotFound()
    {
        // Arrange
 
        var author = await RegisterUserAsync("ghostpubtagger");
        using var authorClient = AuthorizedClient(author.Token);
 
        var tagDto = new CreateTagDto { Name = "Irrelevant" };
 
        // Act
 
        var response =
            await authorClient.PostAsJsonAsync(
                $"/api/tag/add-tag?publicationId={Guid.NewGuid()}",
                tagDto);
 
        // Assert
 
        response.StatusCode.Should().Be(HttpStatusCode.NotFound);
    }
 
    [Fact]
    public async Task AddTags_Exceeding_Limit_Of_20_Should_Return_BadRequest()
    {
        // Arrange
 
        var author = await RegisterUserAsync("limittagger");
        using var authorClient = AuthorizedClient(author.Token);
 
        var publicationId = await CreatePublicationAsync(authorClient, "Publication for limit testing");
 
        var tagsDto = new CreateTagsDto
        {
            Tags = Enumerable.Range(1, 21)
                .Select(i => new CreateTagDto { Name = $"tag{i}" })
                .ToList()
        };
 
        // Act
 
        var response =
            await authorClient.PostAsJsonAsync(
                $"/api/tag/add-tags?publicationId={publicationId}",
                tagsDto);
 
        // Assert
 
        response.StatusCode.Should().Be(HttpStatusCode.BadRequest);
    }
 
    [Fact]
    public async Task SearchTags_Should_Return_Previously_Added_Tag_By_Prefix()
    {
        // Arrange
 
        var author = await RegisterUserAsync("searchtagger");
        using var authorClient = AuthorizedClient(author.Token);
 
        var publicationId = await CreatePublicationAsync(authorClient, "Publication to be tagged for search");
 
        await authorClient.PostAsJsonAsync(
            $"/api/tag/add-tag?publicationId={publicationId}",
            new CreateTagDto { Name = "javascript" });
 
        // Act
 
        // Ендпоінт пошуку без [Authorize] -- доступний анонімно
        var response =
            await _client.GetAsync("/api/tag/tag-search?searchName=java");
 
        // Assert
 
        response.StatusCode.Should().Be(HttpStatusCode.OK);
 
        var results = await response.Content.ReadFromJsonAsync<List<TagDto>>();
        results.Should().Contain(t => t.Name == "javascript");
    }
 
    [Fact]
    public async Task RemoveTagPublication_Should_Remove_Tag_From_Publication()
    {
        // Arrange
 
        var author = await RegisterUserAsync("removetagger");
        using var authorClient = AuthorizedClient(author.Token);
 
        var publicationId = await CreatePublicationAsync(authorClient, "Publication with a removable tag");
 
        await authorClient.PostAsJsonAsync(
            $"/api/tag/add-tag?publicationId={publicationId}",
            new CreateTagDto { Name = "removable" });
 
        var tagsAfterAdd =
            await (await authorClient.GetAsync($"/api/tag/tags-publication?publicationId={publicationId}"))
                .Content.ReadFromJsonAsync<List<TagDto>>();
 
        var tagId = tagsAfterAdd!.Single(t => t.Name == "removable").Id;
 
        // Act
 
        var deleteResponse =
            await authorClient.DeleteAsync(
                $"/api/tag/tag-publication?publicationId={publicationId}&tagId={tagId}");
 
        // Assert
 
        deleteResponse.StatusCode.Should().Be(HttpStatusCode.OK);
 
        var tagsAfterDelete =
            await (await authorClient.GetAsync($"/api/tag/tags-publication?publicationId={publicationId}"))
                .Content.ReadFromJsonAsync<List<TagDto>>();
 
        tagsAfterDelete.Should().NotContain(t => t.Name == "removable");
    }
 
    [Fact]
    public async Task SyncTags_Should_Add_New_And_Remove_Unwanted_Tags()
    {
        // Arrange
 
        var author = await RegisterUserAsync("synctagger");
        using var authorClient = AuthorizedClient(author.Token);
 
        var publicationId = await CreatePublicationAsync(authorClient, "Publication for tag sync");
 
        await authorClient.PostAsJsonAsync(
            $"/api/tag/add-tags?publicationId={publicationId}",
            new CreateTagsDto
            {
                Tags =
                [
                    new CreateTagDto { Name = "keep-me" },
                    new CreateTagDto { Name = "remove-me" }
                ]
            });
 
        var syncDto = new SyncTagsDto
        {
            TagNames = ["keep-me", "brand-new-tag"]
        };
 
        // Act
 
        var syncResponse =
            await authorClient.PutAsJsonAsync(
                $"/api/tag/sync?publicationId={publicationId}",
                syncDto);
 
        // Assert
 
        syncResponse.StatusCode.Should().Be(HttpStatusCode.OK);
 
        var finalTags =
            await (await authorClient.GetAsync($"/api/tag/tags-publication?publicationId={publicationId}"))
                .Content.ReadFromJsonAsync<List<TagDto>>();
 
        finalTags!.Select(t => t.Name).Should().BeEquivalentTo(["keep-me", "brand-new-tag"]);
    }
 
    [Fact]
    public async Task GenerateTagsForPublication_With_FakeMlService_Should_Return_Tags_Derived_From_Content()
    {
        // Arrange
 
        var author = await RegisterUserAsync("mltaguser");
        using var authorClient = AuthorizedClient(author.Token);
 
        var publicationId =
            await CreatePublicationAsync(authorClient, "An elephant walked across the savanna");
 
        // Act
 
        var response =
            await authorClient.GetAsync($"/api/tag/generate-tags?publicationId={publicationId}");
 
        // Assert
 
        response.StatusCode.Should().Be(HttpStatusCode.OK);
 
        var generatedTags = await response.Content.ReadFromJsonAsync<List<GeneratedTagDto>>();
 
        generatedTags.Should().NotBeNullOrEmpty();
        generatedTags.Should().Contain(t => t.Name == "elephant");
    }
}