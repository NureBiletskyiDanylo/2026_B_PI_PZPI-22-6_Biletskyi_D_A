using System.Security.Cryptography;
using System.Text;
using Application.Core;
using Application.DTOs.AccountDTOs;
using Application.Interfaces.Repositories;
using Application.Interfaces.Services;
using Application.Services.TokenService;
using Domain.Entities;
using Domain.Enums;
using Infrastructure.Services;
using MediatR;
using Microsoft.AspNetCore.Http;
using NSubstitute;

namespace UnitTests;

public class AuthUnitTests
{
    private readonly IUserRepository _userRepository;
    private readonly IPhotoService _photoService;
    private readonly ISpamRepository _spamRepository;
    private readonly ISubscriptionService _subscriptionService;
    private readonly ITokenService _tokenService;
    private readonly IRefreshTokenService _refreshTokenService;
    private readonly AccountService _sut; // System Under Test

    public AuthUnitTests()
    {
        _userRepository = Substitute.For<IUserRepository>();
        _photoService = Substitute.For<IPhotoService>();
        _spamRepository = Substitute.For<ISpamRepository>();
        _subscriptionService = Substitute.For<ISubscriptionService>();
        _tokenService = Substitute.For<ITokenService>();
        _refreshTokenService = Substitute.For<IRefreshTokenService>();
        

        _sut = new AccountService(
            _userRepository, 
            _photoService, 
            _spamRepository, 
            _subscriptionService, 
            _tokenService, 
            _refreshTokenService,
            null
        );
    }


    [Fact]
    public async Task RegisterAsync_WithExistingEmail_ReturnsBadRequest()
    {
        // Arrange
        var registerDto = new RegisterDto { Email = "duplicate@example.com", Username = "user", Password = "Password1!" };
        _userRepository.IsUserExistsByEmailAsync(registerDto.Email, Arg.Any<CancellationToken>()).Returns(true);

        // Act
        var result = await _sut.RegisterAsync(registerDto, CancellationToken.None);

        // Assert
        Assert.False(result.IsSuccess);
        Assert.Equal(400, result.Code);
        Assert.Equal("User with specified email already exists", result.Error);
    }

    [Fact]
    public async Task RegisterAsync_WhenUserCreationFails_ReturnsInternalServerError()
    {
        // Arrange
        var registerDto = new RegisterDto { Email = "new@example.com", Username = "user", Password = "Password1!" };
        _userRepository.IsUserExistsByEmailAsync(registerDto.Email, Arg.Any<CancellationToken>()).Returns(false);
        _userRepository.BuildUniqueNameIdentifier(registerDto.Username, null, Arg.Any<CancellationToken>()).Returns("user");
        _userRepository.CreateUserAsync(Arg.Any<User>(), Arg.Any<CancellationToken>()).Returns(false);

        // Act
        var result = await _sut.RegisterAsync(registerDto, CancellationToken.None);

        // Assert
        Assert.False(result.IsSuccess);
        Assert.Equal(500, result.Code);
        Assert.Equal("User was not created or something went wrong", result.Error);
    }

    [Fact]
    public async Task RegisterAsync_WhenSubscriptionInitializationFails_BubblesUpError()
    {
        // Arrange
        var registerDto = new RegisterDto { Email = "new@example.com", Username = "user", Password = "Password1!" };
        _userRepository.IsUserExistsByEmailAsync(registerDto.Email, Arg.Any<CancellationToken>()).Returns(false);
        _userRepository.BuildUniqueNameIdentifier(registerDto.Username, null, Arg.Any<CancellationToken>()).Returns("user");
        _userRepository.CreateUserAsync(Arg.Any<User>(), Arg.Any<CancellationToken>()).Returns(true);
        
        _subscriptionService.InitialiseSubscription(Arg.Any<string>())
            .Returns(Result<Unit>.Failure("Subscription tier unavailable", 422));

    // Act
        var result = await _sut.RegisterAsync(registerDto, CancellationToken.None);

        // Assert
        Assert.False(result.IsSuccess);
        Assert.Equal(422, result.Code);
        Assert.Equal("Subscription tier unavailable", result.Error);
    }

    [Fact]
    public async Task RegisterAsync_WithValidImage_CallsPhotoService()
    {
        // Arrange
        var mockFile = Substitute.For<IFormFile>();
        var registerDto = new RegisterDto { Email = "image@example.com", Username = "user", Password = "Password1!", Image = mockFile };
        
        _userRepository.IsUserExistsByEmailAsync(registerDto.Email, Arg.Any<CancellationToken>()).Returns(false);
        _userRepository.BuildUniqueNameIdentifier(registerDto.Username, null, Arg.Any<CancellationToken>()).Returns("user");
        _userRepository.CreateUserAsync(Arg.Any<User>(), Arg.Any<CancellationToken>()).Returns(true);
        _subscriptionService.InitialiseSubscription(Arg.Any<string>()).Returns(Result<Unit>.Success(Unit.Value));
        
        _photoService.UploadUserProfilePicture(mockFile, Arg.Any<string>(), Arg.Any<CancellationToken>())
            .Returns(Result<Unit>.Failure("Image too heavy", 500));

        // Act
        var result = await _sut.RegisterAsync(registerDto, CancellationToken.None);

        // Assert
        Assert.False(result.IsSuccess);
        await _photoService.Received(1).UploadUserProfilePicture(mockFile, Arg.Any<string>(), Arg.Any<CancellationToken>());
    }

    [Fact]
    public async Task RegisterAsync_Success_ReturnsValidAccountClaimsDto()
    {
        // Arrange
        var registerDto = new RegisterDto { Email = "success@example.com", Username = "successuser", Password = "SecurePassword123" };
        var mockRefreshToken = new RefreshToken { Token = "rt-sample-123" };

        _userRepository.IsUserExistsByEmailAsync(registerDto.Email, Arg.Any<CancellationToken>()).Returns(false);
        _userRepository.BuildUniqueNameIdentifier(registerDto.Username, null, Arg.Any<CancellationToken>()).Returns("successuser");
        _userRepository.CreateUserAsync(Arg.Any<User>(), Arg.Any<CancellationToken>()).Returns(true);
        _subscriptionService.InitialiseSubscription(Arg.Any<string>()).Returns(Result<Unit>.Success(Unit.Value));
        _spamRepository.CreateSpamRating(Arg.Any<string>(), Arg.Any<CancellationToken>()).Returns(Result<Unit>.Success(Unit.Value));
        _refreshTokenService.AddOrUpdateRefreshToken(Arg.Any<string>(), Arg.Any<CancellationToken>()).Returns(Result<RefreshToken>.Success(mockRefreshToken));
        _tokenService.CreateToken(Arg.Any<User>()).Returns("jwt-mock-token");

        // Act
        var result = await _sut.RegisterAsync(registerDto, CancellationToken.None);

        // Assert
        Assert.True(result.IsSuccess);
        Assert.NotNull(result.Value);
        Assert.Equal("successuser", result.Value.Username);
        Assert.Equal("jwt-mock-token", result.Value.Token);
        Assert.Equal("rt-sample-123", result.Value.RefreshToken);
    }



    [Fact]
    public async Task LoginAsync_WithNonExistentEmail_ReturnsNotFound()
    {
        // Arrange
        var loginDto = new LoginDto { Email = "nonexistent@example.com", Password = "Password1!" };
        _userRepository.GetUserByEmailWithRefreshTokensAsync(loginDto.Email, Arg.Any<CancellationToken>()).Returns((User)null!);

        // Act
        var result = await _sut.LoginAsync(loginDto, CancellationToken.None);

        // Assert
        Assert.False(result.IsSuccess);
        Assert.Equal(404, result.Code);
        Assert.Equal("User with specified email does not exist", result.Error);
    }

    [Fact]
    public async Task LoginAsync_WithWrongPassword_ReturnsUnauthorized()
    {
        // Arrange
        var loginDto = new LoginDto { Email = "user@example.com", Password = "WrongPassword!" };
        
        using var hmac = new HMACSHA512();
        var mockUser = new User
        {
            Username = "userUsername",
            UniqueNameIdentifier = "userUsername",
            Email = "user@example.com",
            PasswordSalt = hmac.Key,
            PasswordHash = hmac.ComputeHash(Encoding.UTF8.GetBytes("CorrectPassword!")) // Notice mismatch
        };

        _userRepository.GetUserByEmailWithRefreshTokensAsync(loginDto.Email, Arg.Any<CancellationToken>()).Returns(mockUser);

        // Act
        var result = await _sut.LoginAsync(loginDto, CancellationToken.None);

        // Assert
        Assert.False(result.IsSuccess);
        Assert.Equal(401, result.Code);
        Assert.Equal("Invalid credentials", result.Error);
    }

    [Fact]
    public async Task LoginAsync_Success_ReturnsTokenAndClaims()
    {
        // Arrange
        var loginDto = new LoginDto { Email = "user@example.com", Password = "CorrectPassword!" };
        using var hmac = new HMACSHA512();
    
        var mockUser = new User
        {
            Id = "user-id-abc",
            Username = "realuser",
            UniqueNameIdentifier = "realuser", 
            Email = "user@example.com",
            PasswordSalt = hmac.Key,
            PasswordHash = hmac.ComputeHash(Encoding.UTF8.GetBytes("CorrectPassword!")),
            Role = Roles.User,
            Blocked = false
        };

        var mockRefreshToken = new RefreshToken { Token = "new-refresh-token" };

        _userRepository.GetUserByEmailWithRefreshTokensAsync(loginDto.Email, Arg.Any<CancellationToken>()).Returns(mockUser);
        _refreshTokenService.AddOrUpdateRefreshToken(mockUser.Id, Arg.Any<CancellationToken>()).Returns(Result<RefreshToken>.Success(mockRefreshToken));
        _tokenService.CreateToken(mockUser).Returns("valid-jwt");

        // Act
        var result = await _sut.LoginAsync(loginDto, CancellationToken.None);

        // Assert
        Assert.True(result.IsSuccess);
        Assert.Equal("realuser", result.Value!.Username);
        Assert.Equal("valid-jwt", result.Value.Token);
        Assert.Equal("new-refresh-token", result.Value.RefreshToken);
    }


    [Fact]
    public async Task RefreshTokenAsync_WithInvalidToken_ReturnsUnauthorized()
    {
        // Arrange
        _userRepository.GetUserByRefreshTokenAsync("invalid-token", Arg.Any<CancellationToken>()).Returns((User)null!);

        // Act
        var result = await _sut.RefreshTokenAsync("invalid-token", CancellationToken.None);

        // Assert
        Assert.False(result.IsSuccess);
        Assert.Equal(401, result.Code);
        Assert.Equal("Invalid refresh token", result.Error);
    }

    [Fact]
    public async Task RefreshTokenAsync_WithExpiredToken_ReturnsUnauthorized()
    {
        // Arrange
        var tokenStr = "expired-token";
        var mockToken = new RefreshToken { Token = tokenStr, Expires = DateTime.UtcNow.AddDays(-1) }; 
    
        var mockUser = new User 
        { 
            Username = "expireduser", 
            UniqueNameIdentifier = "expireduser", 
            Email = "expired@example.com" 
        };
        mockUser.RefreshTokens.Add(mockToken);

        _userRepository.GetUserByRefreshTokenAsync(tokenStr, Arg.Any<CancellationToken>()).Returns(mockUser);

        // Act
        var result = await _sut.RefreshTokenAsync(tokenStr, CancellationToken.None);

        // Assert
        Assert.False(result.IsSuccess);
        Assert.Equal(401, result.Code);
        Assert.Equal("Refresh token expired, please log in again", result.Error);
    }
    
    [Fact]
    public async Task RefreshTokenAsync_WithRevokedToken_TriggersTokenReuseAttackMitigation()
    {
        // Arrange
        var tokenStr = "stolen-token";
        var mockToken = new RefreshToken { Token = tokenStr, IsRevoked = true, Expires = DateTime.UtcNow.AddDays(1) };
    
        var mockUser = new User 
        { 
            Username = "stolenuser", 
            UniqueNameIdentifier = "stolenuser", 
            Email = "stolen@example.com" 
        };
        mockUser.RefreshTokens.Add(mockToken);

        _userRepository.GetUserByRefreshTokenAsync(tokenStr, Arg.Any<CancellationToken>()).Returns(mockUser);
    
        _refreshTokenService.RemoveUserRefreshTokensAsync(Arg.Any<ICollection<RefreshToken>>(), Arg.Any<CancellationToken>())
            .Returns(Result<MediatR.Unit>.Success(MediatR.Unit.Value));

        // Act
        var result = await _sut.RefreshTokenAsync(tokenStr, CancellationToken.None);

        // Assert
        Assert.False(result.IsSuccess);
        Assert.Equal(401, result.Code);
        Assert.Equal("Security violation detected, please log in again", result.Error);
    
        _refreshTokenService.Received(1).RemoveUserRefreshTokensAsync(Arg.Any<ICollection<RefreshToken>>(), Arg.Any<CancellationToken>());
    }

    [Fact]
    public async Task RefreshTokenAsync_Success_RevokesOldTokenAndIssuesNewOne()
    {
        // Arrange
        var tokenStr = "valid-old-token";
        var mockToken = new RefreshToken { Token = tokenStr, IsRevoked = false, Expires = DateTime.UtcNow.AddDays(1) };
    
        var mockUser = new User 
        { 
            Id = "user-1", 
            UniqueNameIdentifier = "user1", 
            Username = "user1", 
            Email = "user1@example.com", 
            Role = Roles.User 
        };
        mockUser.RefreshTokens.Add(mockToken);

        var nextToken = new RefreshToken { Token = "shiny-new-token" };

        _userRepository.GetUserByRefreshTokenAsync(tokenStr, Arg.Any<CancellationToken>()).Returns(mockUser);
        _tokenService.CreateRefreshToken().Returns(nextToken);
        _tokenService.CreateToken(mockUser).Returns("new-jwt");

        // Act
        var result = await _sut.RefreshTokenAsync(tokenStr, CancellationToken.None);

        // Assert
        Assert.True(result.IsSuccess);
        Assert.True(mockToken.IsRevoked); 
        Assert.Equal("shiny-new-token", result.Value!.RefreshToken);
        Assert.Equal("new-jwt", result.Value.Token);
        Assert.Contains(nextToken, mockUser.RefreshTokens);
    }
}