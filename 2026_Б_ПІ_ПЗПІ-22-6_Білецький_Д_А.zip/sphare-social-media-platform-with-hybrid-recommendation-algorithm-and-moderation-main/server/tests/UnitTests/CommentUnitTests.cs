﻿using Application.DTOs.CommentDTOs;
using Application.Interfaces.Logger;
using Application.Interfaces.Repositories;
using Domain.Entities;
using Domain.Enums;
using Infrastructure.Services;
using NSubstitute;

namespace UnitTests;

public class CommentUnitTests
{
    private readonly IUserActionLogger<CommentService> _logger;
    private readonly ISpamRepository _spamRepository;
    private readonly ICommentRepository _commentRepository;
    private readonly IPublicationRepository _publicationRepository;
    private readonly IUserRepository _userRepository;
    private readonly CommentService _sut;

    public CommentUnitTests()
    {
        _logger = Substitute.For<IUserActionLogger<CommentService>>();
        _spamRepository = Substitute.For<ISpamRepository>();
        _commentRepository = Substitute.For<ICommentRepository>();
        _publicationRepository = Substitute.For<IPublicationRepository>();
        _userRepository = Substitute.For<IUserRepository>();

        _sut = new CommentService(
            _logger,
            _spamRepository,
            _commentRepository,
            _publicationRepository,
            _userRepository
        );
    }


    [Fact]
    public async Task GetCommentsByPublicationIdAsync_PublicationDoesNotExist_ReturnsNotFound404()
    {
        // Arrange
        var pubId = "missing-pub";
        _publicationRepository.IsPublicationExistsAsync(pubId, Arg.Any<CancellationToken>()).Returns(false);

        // Act
        var result = await _sut.GetCommentsByPublicationIdAsync(pubId, "user-123", 1, 10, CancellationToken.None);

        // Assert
        Assert.False(result.IsSuccess);
        Assert.Equal(404, result.Code);
        Assert.Equal("Publication does not exist", result.Error);
    }

    [Fact]
    public async Task GetRepliesAsync_ParentCommentDoesNotExist_ReturnsNotFound404()
    {
        // Arrange
        var parentId = "missing-parent";
        _commentRepository.IsCommentExistsByIdAsync(parentId, Arg.Any<CancellationToken>()).Returns(false);

        // Act
        var result = await _sut.GetRepliesAsync(parentId, "user-123", 1, 10, CancellationToken.None);

        // Assert
        Assert.False(result.IsSuccess);
        Assert.Equal(404, result.Code);
        Assert.Equal("Parent comment does not exist", result.Error);
    }



    [Fact]
    public async Task DeleteCommentAsync_CommentDoesNotExist_ReturnsNotFound404()
    {
        // Arrange
        _commentRepository.GetCommentAuthorIdByCommentIdAsync("missing-id", Arg.Any<CancellationToken>()).Returns(string.Empty);

        // Act
        var result = await _sut.DeleteCommentAsync("missing-id", "user-123", false, CancellationToken.None);

        // Assert
        Assert.False(result.IsSuccess);
        Assert.Equal(404, result.Code);
    }

    [Fact]
    public async Task DeleteCommentAsync_UserIsNotAuthorAndNotAdmin_ReturnsUnauthorized401()
    {
        // Arrange
        var commentId = "comm-1";
        _commentRepository.GetCommentAuthorIdByCommentIdAsync(commentId, Arg.Any<CancellationToken>()).Returns("owner-user-id");

        // Act
        var result = await _sut.DeleteCommentAsync(commentId, "malicious-user-id", false, CancellationToken.None);

        // Assert
        Assert.False(result.IsSuccess);
        Assert.Equal(401, result.Code);
        Assert.Equal("Comment does not belong to you", result.Error);
    }

    [Fact]
    public async Task DeleteCommentAsync_UserIsAdminButNotAuthor_AllowsDeletionAndLogsAction()
    {
        // Arrange
        var commentId = "comm-1";
        _commentRepository.GetCommentAuthorIdByCommentIdAsync(commentId, Arg.Any<CancellationToken>()).Returns("owner-user-id");

        // Act
        var result = await _sut.DeleteCommentAsync(commentId, "admin-user-id", true, CancellationToken.None);

        // Assert
        Assert.True(result.IsSuccess);
        await _commentRepository.Received(1).DeleteCommentAsync(commentId, Arg.Any<CancellationToken>());
        await _logger.Received(1).LogAsync("owner-user-id", UserLogAction.DeleteComment, Arg.Any<object>(), commentId, Arg.Any<CancellationToken>());
    }



    [Fact]
    public async Task CreateCommentAsync_SendingCommentsTooFast_ReturnsBadRequest400()
    {
        // Arrange
        var dto = new CreateCommentDto { Content = "Fast post", PublicationId = "pub-1" };
    
        var mockUserInfo = new UserInfoProjection
        { 
            Id = "user-1", 
            Username = "testuser",
            UniqueNameIdentifier = "testuser",
            Blocked = false,
            ImageUrl = null,
            PublicationExists = true, 
            LastCommentDate = DateTime.UtcNow.AddSeconds(-2)
        };

        _userRepository.GetUserInfoAsync("user-1", "pub-1", Arg.Any<CancellationToken>())
            .Returns(mockUserInfo);

        // Act
        var result = await _sut.CreateCommentAsync("user-1", dto, CancellationToken.None);

        // Assert
        Assert.False(result.IsSuccess);
        Assert.Equal(400, result.Code);
        Assert.Equal("You are sending comments too fast", result.Error);
    }

    [Fact]
    public async Task CreateCommentAsync_AntiSpamDailyLimitReached_ReturnsBadRequest400()
    {
        // Arrange
        var dto = new CreateCommentDto { Content = "Hello", PublicationId = "pub-1" };

        var mockUserInfo = new UserInfoProjection
        { 
            Id = "user-1", 
            Username = "testuser",
            UniqueNameIdentifier = "testuser",
            Blocked = false,
            ImageUrl = null,
            PublicationExists = true, 
            LastCommentDate = DateTime.UtcNow.AddSeconds(-30) 
        };

        _userRepository.GetUserInfoAsync("user-1", "pub-1", Arg.Any<CancellationToken>())
            .Returns(mockUserInfo);
    
        _spamRepository.MakeComment("user-1", Arg.Any<CancellationToken>()).Returns(false); 

        // Act
        var result = await _sut.CreateCommentAsync("user-1", dto, CancellationToken.None);

        // Assert
        Assert.False(result.IsSuccess);
        Assert.Equal(400, result.Code);
        Assert.Equal("You cannot make comments for today due to our antispam rules", result.Error);
    }

    [Fact]
    public async Task CreateCommentAsync_MismatchedPublicationParentId_ReturnsInternalServerError500()
    {
        // Arrange
        var dto = new CreateCommentDto { Content = "Reply to alternative comment", PublicationId = "target-pub-id", ParentCommentId = "parent-id" };
    
        var mockUserInfo = new UserInfoProjection
        { 
            Id = "user-1", 
            Username = "testuser",
            UniqueNameIdentifier = "testuser",
            Blocked = false,
            ImageUrl = null,
            PublicationExists = true, 
            LastCommentDate = DateTime.UtcNow.AddSeconds(-30) 
        };

        _userRepository.GetUserInfoAsync("user-1", "target-pub-id", Arg.Any<CancellationToken>())
            .Returns(mockUserInfo);
        
        _spamRepository.MakeComment("user-1", Arg.Any<CancellationToken>()).Returns(true);
        _commentRepository.GetPublicationIdByCommentIdAsync("parent-id", Arg.Any<CancellationToken>()).Returns("completely-different-pub-id");

        // Act
        var result = await _sut.CreateCommentAsync("user-1", dto, CancellationToken.None);

        // Assert
        Assert.False(result.IsSuccess);
        Assert.Equal(500, result.Code);
        Assert.Equal("Comment reply internal server error. Try again later!", result.Error);
    }

    [Fact]
    public async Task CreateCommentAsync_WhenDepthExceedsMaxLimit_FlattensEffectiveParentId()
    {
        // Arrange
        var dto = new CreateCommentDto { Content = "Deep reply", PublicationId = "pub-1", ParentCommentId = "level-11-id" };
        
        var mockUserInfo = new UserInfoProjection
        { 
            Id = "user-1", 
            Username = "user", 
            UniqueNameIdentifier = "user", 
            Blocked = false,
            ImageUrl = null,
            PublicationExists = true, 
            LastCommentDate = DateTime.UtcNow.AddSeconds(-30) 
        };

        _userRepository.GetUserInfoAsync("user-1", "pub-1", Arg.Any<CancellationToken>())
            .Returns(mockUserInfo);
            
        _spamRepository.MakeComment("user-1", Arg.Any<CancellationToken>()).Returns(true);
        _commentRepository.GetPublicationIdByCommentIdAsync("level-11-id", Arg.Any<CancellationToken>()).Returns("pub-1");

        _commentRepository.GetParentCommentId("level-11-id", Arg.Any<CancellationToken>()).Returns("level-10-id");
        _commentRepository.GetParentCommentId("level-10-id", Arg.Any<CancellationToken>()).Returns("level-9-id");
        _commentRepository.GetParentCommentId("level-9-id", Arg.Any<CancellationToken>()).Returns("level-8-id");
        _commentRepository.GetParentCommentId("level-8-id", Arg.Any<CancellationToken>()).Returns("level-7-id");
        _commentRepository.GetParentCommentId("level-7-id", Arg.Any<CancellationToken>()).Returns("level-6-id");
        _commentRepository.GetParentCommentId("level-6-id", Arg.Any<CancellationToken>()).Returns("level-5-id");
        _commentRepository.GetParentCommentId("level-5-id", Arg.Any<CancellationToken>()).Returns("level-4-id");
        _commentRepository.GetParentCommentId("level-4-id", Arg.Any<CancellationToken>()).Returns("level-3-id");
        _commentRepository.GetParentCommentId("level-3-id", Arg.Any<CancellationToken>()).Returns("level-2-id");
        _commentRepository.GetParentCommentId("level-2-id", Arg.Any<CancellationToken>()).Returns("level-1-id");
        _commentRepository.GetParentCommentId("level-1-id", Arg.Any<CancellationToken>()).Returns((string)null!);

        // Act
        var result = await _sut.CreateCommentAsync("user-1", dto, CancellationToken.None);

        // Assert
        Assert.True(result.IsSuccess);
        
        await _commentRepository.Received(1).CreateComment(
            Arg.Is<Comment>(c => c.ParentCommentId == "level-10-id"), 
            "level-10-id", 
            Arg.Any<CancellationToken>()
        );
    }
}