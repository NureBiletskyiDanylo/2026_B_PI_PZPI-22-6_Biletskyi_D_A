﻿using Application.Core;
using Application.DTOs.PublicationDTOs;
using Application.Interfaces.Logger;
using Application.Interfaces.Repositories;
using Application.Interfaces.Services;
using Domain.Entities;
using Domain.Entities.Publications;
using Domain.Enums;
using Infrastructure.Services;
using MediatR;
using Microsoft.AspNetCore.Http;
using NSubstitute;

namespace UnitTests;

public class PublicationUnitTests
{
    private readonly IPublicationRepository _publicationRepository;
    private readonly IUserActionLogger<PublicationService> _logger;
    private readonly ISpamRepository _spamRepository;
    private readonly IPhotoService _photoService;
    private readonly IUserRepository _userRepository;
    private readonly PublicationService _sut;

    public PublicationUnitTests()
    {
        _publicationRepository = Substitute.For<IPublicationRepository>();
        _logger = Substitute.For<IUserActionLogger<PublicationService>>();
        _spamRepository = Substitute.For<ISpamRepository>();
        _photoService = Substitute.For<IPhotoService>();
        _userRepository = Substitute.For<IUserRepository>();

        _sut = new PublicationService(
            _publicationRepository,
            _logger,
            _spamRepository,
            _photoService,
            _userRepository,
            null
        );
    }


    [Fact]
    public async Task GetPublicationByIdAsync_UserDoesNotExist_ReturnsNotFound()
    {
        // Arrange
        _userRepository.IsUserExistsByIdAsync("invalid-user", Arg.Any<CancellationToken>()).Returns(false);

        // Act
        var result = await _sut.GetPublicationByIdAsync("pub-1", "invalid-user", CancellationToken.None);

        // Assert
        Assert.False(result.IsSuccess);
    }

    [Fact]
    public async Task GetPublicationByIdAsync_PublicationDoesNotExist_ReturnsNotFound()
    {
        // Arrange
        _userRepository.IsUserExistsByIdAsync("user-1", Arg.Any<CancellationToken>()).Returns(true);
        _publicationRepository.GetPublicationByIdAsync("missing-pub", "user-1", Arg.Any<CancellationToken>()).Returns((PublicationDto)null!);

        // Act
        var result = await _sut.GetPublicationByIdAsync("missing-pub", "user-1", CancellationToken.None);

        // Assert
        Assert.False(result.IsSuccess);
        Assert.Equal(404, result.Code);
    }

    [Fact]
    public async Task GetPublicationByIdAsync_UserIsAuthor_SetsIsOwnerToTrue()
    {
        // Arrange
        var userId = "author-user-id";
        _userRepository.IsUserExistsByIdAsync(userId, Arg.Any<CancellationToken>()).Returns(true);
        
        var mockPubDto = new PublicationDto 
        { 
            Id = "pub-1", 
            Author = new Application.DTOs.UserDTOs.PublicUserBriefDto { Id = userId, Username = "author", UniqueNameIdentifier = "author" } 
        };
        _publicationRepository.GetPublicationByIdAsync("pub-1", userId, Arg.Any<CancellationToken>()).Returns(mockPubDto);

        // Act
        var result = await _sut.GetPublicationByIdAsync("pub-1", userId, CancellationToken.None);

        // Assert
        Assert.True(result.IsSuccess);
        Assert.True(result.Value!.IsOwner);
    }



    [Fact]
    public async Task CreatePublicationAsync_UserNotFound_ReturnsUnauthorized()
    {
        // Arrange
        _userRepository.GetUserByIdAsync("stranger", Arg.Any<CancellationToken>()).Returns((User)null!);

        // Act
        var result = await _sut.CreatePublicationAsync(new CreatePublicationDto { Content = "Hello" }, "stranger", CancellationToken.None);

        // Assert
        Assert.False(result.IsSuccess);
    }

    [Fact]
    public async Task CreatePublicationAsync_SpamDetected_ReturnsSpamFailure()
    {
        // Arrange
        var mockUser = new User { Id = "spammer", Username = "spam", UniqueNameIdentifier = "spam", Email = "spam@test.com" };
        _userRepository.GetUserByIdAsync(mockUser.Id, Arg.Any<CancellationToken>()).Returns(mockUser);
        _spamRepository.IsPublicationSpamming(mockUser.Id, mockUser.DateOfCreation, Arg.Any<CancellationToken>()).Returns(true);

        // Act
        var result = await _sut.CreatePublicationAsync(new CreatePublicationDto { Content = "Spam post" }, mockUser.Id, CancellationToken.None);

        // Assert
        Assert.False(result.IsSuccess);
        await _publicationRepository.DidNotReceive().AddPublication(Arg.Any<Publication>(), Arg.Any<CancellationToken>());
    }

    [Fact]
    public async Task CreatePublicationAsync_PlannedType_CreatesPlannedPublication()
    {
        // Arrange
        var mockUser = new User { Id = "scheduler", Username = "sched", UniqueNameIdentifier = "sched", Email = "sched@test.com" };
        var publishTime = DateTime.UtcNow.AddDays(2);
        var createDto = new CreatePublicationDto 
        { 
            Content = "Planned content", 
            PublicationType = PublicationTypes.planned,
            PublishAt = publishTime
        };

        _userRepository.GetUserByIdAsync(mockUser.Id, Arg.Any<CancellationToken>()).Returns(mockUser);
        _spamRepository.IsPublicationSpamming(mockUser.Id, mockUser.DateOfCreation, Arg.Any<CancellationToken>()).Returns(false);

        // Act
        var result = await _sut.CreatePublicationAsync(createDto, mockUser.Id, CancellationToken.None);

        // Assert
        Assert.True(result.IsSuccess);
        await _publicationRepository.Received(1).AddPublication(Arg.Is<PlannedPublication>(p => p.PublishAt == publishTime && p.Content == "Planned content"), Arg.Any<CancellationToken>());
    }

    [Fact]
    public async Task CreatePublicationAsync_WithImages_UploadsAndAttachesImages()
    {
        // Arrange
        var mockUser = new User { Id = "photographer", Username = "photo", UniqueNameIdentifier = "photo", Email = "photo@test.com" };
        var imageFiles = new List<IFormFile> { Substitute.For<IFormFile>() };
        var createDto = new CreatePublicationDto { Content = "With images", PublicationType = PublicationTypes.ordinary, Images = imageFiles };
        
        var mockUploadedImages = new List<Image> { new Image { Id = "img-1", ImageUrl = "https://cdn.com/1.jpg" } };

        _userRepository.GetUserByIdAsync(mockUser.Id, Arg.Any<CancellationToken>()).Returns(mockUser);
        _spamRepository.IsPublicationSpamming(mockUser.Id, mockUser.DateOfCreation, Arg.Any<CancellationToken>()).Returns(false);
        _photoService.UploadPublicationImages(imageFiles, Arg.Any<string>(), Arg.Any<CancellationToken>())
            .Returns(Result<List<Image>>.Success(mockUploadedImages));

        // Act
        var result = await _sut.CreatePublicationAsync(createDto, mockUser.Id, CancellationToken.None);

        // Assert
        Assert.True(result.IsSuccess);
        await _publicationRepository.Received(1).AddPublication(Arg.Is<Publication>(p => p.Images == mockUploadedImages), Arg.Any<CancellationToken>());
    }



    [Fact]
    public async Task UpdatePublicationContentAsync_UserNotAuthor_ReturnsUnauthorized()
    {
        // Arrange
        var dto = new UpdatePublicationContentDto { PublicationId = "pub-1", NewContent = "Edited" };
        _publicationRepository.IsUserAuthorAsync("not-author", "pub-1", Arg.Any<CancellationToken>()).Returns(false);

        // Act
        var result = await _sut.UpdatePublicationContentAsync(dto, "not-author", CancellationToken.None);

        // Assert
        Assert.False(result.IsSuccess);
    }

    [Fact]
    public async Task UpdatePublicationContentAsync_Success_UpdatesAndReturnsSuccessUnit()
    {
        // Arrange
        var dto = new UpdatePublicationContentDto { PublicationId = "pub-1", NewContent = "Valid Edit" };
        _publicationRepository.IsUserAuthorAsync("author-id", "pub-1", Arg.Any<CancellationToken>()).Returns(true);
        _publicationRepository.UpdatePublicationContentAsync(dto, Arg.Any<CancellationToken>()).Returns(true);
        _publicationRepository.GetPublicationByIdAsync("pub-1", "author-id", Arg.Any<CancellationToken>()).Returns(new PublicationDto());

        // Act
        var result = await _sut.UpdatePublicationContentAsync(dto, "author-id", CancellationToken.None);

        // Assert
        Assert.True(result.IsSuccess);
        Assert.Equal(Unit.Value, result.Value);
    }



    [Fact]
    public async Task DeletePublicationAsync_UserIsNotAuthor_ReturnsUnauthorized()
    {
        // Arrange
        var navProps = new PublicationNavigationProperties { PublicationId = "pub-1", AuthorId = "actual-owner-id" };
        _publicationRepository.GetPublicationNavigationPropertiesAsync("pub-1", Arg.Any<CancellationToken>()).Returns(navProps);

        // Act
        var result = await _sut.DeletePublicationAsync("pub-1", "malicious-user-id", CancellationToken.None);

        // Assert
        Assert.False(result.IsSuccess);
    }

    [Fact]
    public async Task DeletePublicationAsync_WithImages_CallsPhotoServiceCleanup()
    {
        // Arrange
        var imageIds = new List<string> { "cloud-id-1", "cloud-id-2" };
        var navProps = new PublicationNavigationProperties { PublicationId = "pub-1", AuthorId = "owner-id", ImageIds = imageIds };
        
        _publicationRepository.GetPublicationNavigationPropertiesAsync("pub-1", Arg.Any<CancellationToken>()).Returns(navProps);
        _publicationRepository.IsPublicationExistsAsync("pub-1", Arg.Any<CancellationToken>()).Returns(true);
        _publicationRepository.DeletePublicationAsync("pub-1", Arg.Any<CancellationToken>()).Returns(true);
        _photoService.DeletePublicationImagesAsync(imageIds, Arg.Any<CancellationToken>()).Returns(Result<Unit>.Success(Unit.Value));

        // Act
        var result = await _sut.DeletePublicationAsync("pub-1", "owner-id", CancellationToken.None);

        // Assert
        Assert.True(result.IsSuccess);
        await _photoService.Received(1).DeletePublicationImagesAsync(imageIds, Arg.Any<CancellationToken>());
    }

}