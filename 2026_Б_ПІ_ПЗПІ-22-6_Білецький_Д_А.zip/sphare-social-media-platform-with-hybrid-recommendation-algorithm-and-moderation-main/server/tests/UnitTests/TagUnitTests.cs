﻿using Application.Core;
using Application.DTOs.TagDTOs;
using Application.Interfaces.Repositories;
using Application.Interfaces.Services;
using Application.Models;
using AutoMapper;
using Domain.Entities.Publications;
using Domain.Entities.RecomendationEntities;
using Infrastructure.Services;
using MediatR;
using NSubstitute;

namespace UnitTests;

public class TagServicesUnitTests
{
    private readonly ITagRepository _tagRepository;
    private readonly IPublicationRepository _publicationRepository;
    private readonly IMlTaggingService _mlTaggingService;
    private readonly IMapper _mapper;
    
    private readonly TagService _tagServiceSut;
    private readonly PublicationTagService _publicationTagServiceSut;

    public TagServicesUnitTests()
    {
        _tagRepository = Substitute.For<ITagRepository>();
        _publicationRepository = Substitute.For<IPublicationRepository>();
        _mlTaggingService = Substitute.For<IMlTaggingService>();
        _mapper = Substitute.For<IMapper>();

        _tagServiceSut = new TagService(_tagRepository, _publicationRepository, _mapper);
        _publicationTagServiceSut = new PublicationTagService(_publicationRepository, _mlTaggingService, _mapper, _tagRepository);
    }

    #region TagService - Authorization & Validation Rules

    [Fact]
    public async Task CreateTagAsync_PublicationDoesNotExist_ReturnsFailure()
    {
        // Arrange
        var userId = "user-1";
        var pubId = "missing-pub";
        _publicationRepository.IsPublicationExistsAsync(pubId, Arg.Any<CancellationToken>()).Returns(false);

        // Act
        var result = await _tagServiceSut.CreateTagAsync(userId, pubId, new CreateTagDto { Name = "Dotnet" }, CancellationToken.None);

        // Assert
        Assert.False(result.IsSuccess);
    }

    [Fact]
    public async Task CreateTagAsync_UserIsNotAuthor_ReturnsUnauthorizedFailure()
    {
        // Arrange
        var userId = "hacker-user";
        var pubId = "pub-1";
        _publicationRepository.IsPublicationExistsAsync(pubId, Arg.Any<CancellationToken>()).Returns(true);
        _publicationRepository.IsUserAuthorAsync(userId, pubId, Arg.Any<CancellationToken>()).Returns(false);

        // Act
        var result = await _tagServiceSut.CreateTagAsync(userId, pubId, new CreateTagDto { Name = "Dotnet" }, CancellationToken.None);

        // Assert
        Assert.False(result.IsSuccess);
    }

    [Fact]
    public async Task CreateTagsAsync_ExceedingMaxLimitOf20Tags_ReturnsFailure()
    {
        // Arrange
        var userId = "author-user";
        var pubId = "pub-1";
        _publicationRepository.IsPublicationExistsAsync(pubId, Arg.Any<CancellationToken>()).Returns(true);
        _publicationRepository.IsUserAuthorAsync(userId, pubId, Arg.Any<CancellationToken>()).Returns(true);
        
        _tagRepository.GetTagsAmountByPublicationIdAsync(pubId, Arg.Any<CancellationToken>()).Returns(15);

        var dto = new CreateTagsDto
        {
            Tags = new List<CreateTagDto>
            {
                new() { Name = "T1" }, new() { Name = "T2" }, new() { Name = "T3" },
                new() { Name = "T4" }, new() { Name = "T5" }, new() { Name = "T6" }
            }
        };

        // Act
        var result = await _tagServiceSut.CreateTagsAsync(userId, pubId, dto, CancellationToken.None);

        // Assert
        Assert.False(result.IsSuccess);
    }

    #endregion

    #region TagService - Mutations & Execution Logic

    [Fact]
    public async Task SaveGeneratedTags_SplitsAndSavesNewAndExistingTagsCorrectly()
    {
        // Arrange
        var userId = "author-user";
        var pubId = "pub-1";
        _publicationRepository.IsPublicationExistsAsync(pubId, Arg.Any<CancellationToken>()).Returns(true);
        _publicationRepository.IsUserAuthorAsync(userId, pubId, Arg.Any<CancellationToken>()).Returns(true);
        _tagRepository.GetTagsAmountByPublicationIdAsync(pubId, Arg.Any<CancellationToken>()).Returns(5);

        var incomingTags = new List<GeneratedTagDto>
        {
            new() { Name = "csharp" },
            new() { Name = "mediatr" }
        };

        var existingTagEntities = new List<Tag> { new() { Id = 10, Name = "csharp" } };
        var newTagEntities = new List<Tag> { new() { Name = "mediatr" } };

        _tagRepository.SplitExistingAndNewTagsAsync(Arg.Any<List<Tag>>(), Arg.Any<CancellationToken>())
            .Returns((existingTagEntities, newTagEntities));

        // Act
        var result = await _tagServiceSut.SaveGeneratedTags(userId, pubId, incomingTags, CancellationToken.None);

        // Assert
        Assert.True(result.IsSuccess);
        await _tagRepository.Received(1).AddTagsAsync(newTagEntities, Arg.Any<CancellationToken>());
        await _tagRepository.Received(1).AddTagsToPublicationAsync(pubId, Arg.Is<List<Tag>>(l => l.Count == 2), Arg.Any<CancellationToken>());
    }

    [Fact]
    public async Task SyncTagsAsync_CleansPayloadAndCallsRepositorySync()
    {
        // Arrange
        var userId = "author-user";
        var pubId = "pub-1";
        _publicationRepository.IsPublicationExistsAsync(pubId, Arg.Any<CancellationToken>()).Returns(true);
        _publicationRepository.IsUserAuthorAsync(userId, pubId, Arg.Any<CancellationToken>()).Returns(true);
        
        var desiredNames = new List<string> { " CleanCode ", "cleancode", "Architecture" };
        _tagRepository.SyncTagsForPublicationAsync(pubId, Arg.Any<List<string>>(), Arg.Any<CancellationToken>())
            .Returns(Result<Unit>.Success(Unit.Value));

        // Act
        var result = await _tagServiceSut.SyncTagsAsync(userId, pubId, desiredNames, CancellationToken.None);

        // Assert
        Assert.True(result.IsSuccess);
        await _tagRepository.Received(1).SyncTagsForPublicationAsync(
            pubId, 
            Arg.Is<List<string>>(l => l.Count == 2 && l.Contains("cleancode") && l.Contains("architecture")), 
            Arg.Any<CancellationToken>()
        );
    }

    #endregion

    #region PublicationTagService - ML Extraction Tests

    [Fact]
    public async Task GenerateTags_EmptyPublicationContent_ReturnsBadRequest400()
    {
        // Arrange
        var userId = "author-user";
        var pubId = "pub-1";
        var mockPublication = new Publication { Id = pubId, Content = "" };

        _publicationRepository.IsUserAuthorAsync(userId, pubId, Arg.Any<CancellationToken>()).Returns(true);
        _publicationRepository.GetRawPublicationByIdAsync(pubId, Arg.Any<CancellationToken>()).Returns(mockPublication);

        // Act
        var result = await _publicationTagServiceSut.GenerateTags(pubId, userId, CancellationToken.None);

        // Assert
        Assert.False(result.IsSuccess);
        Assert.Equal(400, result.Code);
    }

    [Fact]
    public async Task GenerateTags_ValidContext_ExtractsAndMapsTagsSuccessfully()
    {
        // Arrange
        var userId = "author-user";
        var pubId = "pub-1";
        var mockPublication = new Publication { Id = pubId, Content = "Learning advanced database architectures." };

        _publicationRepository.IsUserAuthorAsync(userId, pubId, Arg.Any<CancellationToken>()).Returns(true);
        _publicationRepository.GetRawPublicationByIdAsync(pubId, Arg.Any<CancellationToken>()).Returns(mockPublication);
        
        _tagRepository.GetTagsForPublicationAsync(pubId, Arg.Any<CancellationToken>())
            .Returns(new List<Tag> { new() { Name = "database" } });

        var mlResult = new TagExtractionResult { NewTags = new List<string> { "architecture" } };
        _mlTaggingService.ExtractTagsAsync("Learning advanced database architectures.", Arg.Is<List<string>>(l => l.Contains("database")), Arg.Any<CancellationToken>())
            .Returns(mlResult);

        // Act
        await _publicationTagServiceSut.GenerateTags(pubId, userId, CancellationToken.None);

        // Assert
        _mapper.Received(1).Map<List<GeneratedTagDto>>(Arg.Is<List<Tag>>(l => l.Count == 1 && l[0].Name == "architecture"));
    }
    

    #endregion
}