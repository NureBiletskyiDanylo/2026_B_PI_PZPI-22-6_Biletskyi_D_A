﻿namespace Domain.Entities;

public class UserSettings
{
    public string UserId { get; set; } = null!;
    
    public bool ProfanityFilter { get; set; } = false;
    public bool Mfa { get; set; } = false;

    public User User { get; set; } = null!;
}