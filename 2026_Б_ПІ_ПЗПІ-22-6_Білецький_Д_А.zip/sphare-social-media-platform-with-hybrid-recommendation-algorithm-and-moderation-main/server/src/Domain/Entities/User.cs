﻿using Domain.Entities.Complaints;
using Domain.Entities.Publications;
using Domain.Entities.RecomendationEntities;
using Domain.Enums;

namespace Domain.Entities;

public class User
{
    public string Id { get; set; } = Guid.NewGuid().ToString();
    public required string Username { get; set; }
    public required string UniqueNameIdentifier { get; set; }
    public required string Email { get; set; }
    public byte[] PasswordHash { get; set; } = [];
    public byte[] PasswordSalt { get; set; } = [];
    public Roles Role { get; set; } = Roles.User;
    public DateOnly DateOfCreation { get; set; } = DateOnly.FromDateTime(DateTime.UtcNow);
    public int ViolationScore { get; set; }
    public bool Blocked { get; set; }
    public DateTime? BlockedAt { get; set; }
    public int SubscriberNumber { get; set; }
    
    // google props
    public string? GoogleId { get; set; }
    public bool HasPassword { get; set; } = true;
    
    //Navigation properties
    public UserSettings UserSettings { get; set; } = null!;
    public List<Publication> CreatedPublications { get; set; } = [];
    public List<Like> LikedPublications { get; set; } = [];
    public string? ProfileImageId { get; set; }
    public Image? ProfileImage { get; set; }
    public List<Violation> Violations { get; set; } = [];
    public UserProfileDetails? ProfileDetails { get; set; }
    public string? ProfileDetailsId { get; set; }
    public Address? Address { get; set; }
    public int? AddressId { get; set; }
    public List<PublicationComplaint> PublicationComplaintsMade { get; set; } = [];
    public List<CommentComplaint> CommentComplaintsMade { get; set; } = [];
    public List<ChatUser> Chats { get; set; } = [];
    public List<UserActionLog> ActionLogs { get; set; } = [];
    public SpamRating SpamRating { get; set; } = null!;
    public List<PublicationView> ViewedPublications { get; set; } = [];
    public List<UserInterestTag> InterestTags { get; set; } = [];
    public ICollection<RefreshToken> RefreshTokens { get; set; } = [];
}
