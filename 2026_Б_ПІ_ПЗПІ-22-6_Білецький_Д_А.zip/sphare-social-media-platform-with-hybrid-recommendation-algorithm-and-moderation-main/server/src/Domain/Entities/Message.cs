﻿namespace Domain.Entities;
public class Message
{
    public string Id { get; set; } = Guid.NewGuid().ToString();
    public string Content { get; set; } = string.Empty;
    public DateTime SentAt { get; set; } = DateTime.UtcNow;
    public DateTime? EditedAt { get; set; }
    public bool WasEdited { get; set; }
    public bool IsRead { get; set; } = false;

    
    // Navigation properties
    public string SenderId { get; set; } = string.Empty;
    public User Sender { get; set; } = null!;
    public string ChatId { get; set; } = Guid.NewGuid().ToString();
    public Chat Chat { get; set; } = null!;
 } 