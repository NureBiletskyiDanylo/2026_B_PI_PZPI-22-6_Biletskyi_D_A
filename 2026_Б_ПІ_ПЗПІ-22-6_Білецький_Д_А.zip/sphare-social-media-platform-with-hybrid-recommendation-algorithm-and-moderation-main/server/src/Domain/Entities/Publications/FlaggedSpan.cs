﻿namespace Domain.Entities.Publications;

public record FlaggedSpan(int Start, int End);

public record ProfanityCheckResult(bool ContainsProfanity, IReadOnlyList<FlaggedSpan> FlaggedSpans);