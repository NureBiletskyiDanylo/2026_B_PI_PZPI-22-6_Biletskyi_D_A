﻿using Application.DTOs.ComplaintDTOs;
using Application.Features.Complaints.Commands;
using Application.Features.Complaints.Queries;
using Application.Helpers;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace API.Controllers;
[Authorize]
public class ComplaintController : BaseApiController
{
    [HttpPost("publication")]
    public async Task<ActionResult> RegisterPublicationComplaint(CreateComplaintDto complaint)
    {
        var userId = User.GetUserId();
        return HandleResult(await Mediator
            .Send(new CreatePublicationComplaint.Command { Complaint = complaint, UserId = userId }));
    }

    [HttpPost("comment")]
    public async Task<ActionResult> RegisterCommentComplaint(CreateComplaintDto complaint)
    {
        var userId = User.GetUserId();
        return HandleResult(await Mediator
            .Send(new CreateCommentComplaint.Command { Complaint = complaint, UserId = userId }));
    }

    [Authorize(Roles = "Admin")]
    [HttpGet("publication")]
    public async Task<ActionResult> GetPublicationComplaints()
    {
        return HandleResult(await Mediator
            .Send(new GetPublicationComplaints.Query()));
    }

    [Authorize(Roles = "Admin")]
    [HttpGet("comment")]
    public async Task<ActionResult> GetCommentComplaints()
    {
        return HandleResult(await Mediator
            .Send(new GetCommentComplaints.Query()));
    }

    [HttpGet("publication-grouped")]
    public async Task<ActionResult> GetPublicationComplaintsGrouped()
    {
        return HandleResult(await Mediator
            .Send(new GetGroupedComplaints.Query()));
    }
}
