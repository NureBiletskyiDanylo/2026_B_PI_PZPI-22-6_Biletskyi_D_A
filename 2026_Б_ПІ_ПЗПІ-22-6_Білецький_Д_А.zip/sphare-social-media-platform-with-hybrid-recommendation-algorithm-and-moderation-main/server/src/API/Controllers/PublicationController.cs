﻿using Application.Core.Pagination;
using Application.DTOs.LikeDTOs;
using Application.DTOs.PublicationDTOs;
using Microsoft.AspNetCore.Authorization;

namespace API.Controllers;

using Application.Features.Likes.Commands;
using Application.Features.Publications.Commands;
using Application.Features.Publications.Queries;
using Application.Helpers;
using Microsoft.AspNetCore.Mvc;

public class PublicationController : BaseApiController
{
    [Authorize]
    [HttpPost("create-publication")]
    public async Task<ActionResult> CreatePublication([FromForm] CreatePublicationDto publication)
    {
        string userId = User.GetUserId();

        return HandleResult(await Mediator.Send(new CreatePublication.Command { CreatorId = userId, Publication = publication }));
    }

    [Authorize]
    [HttpPut("update-content")]
    public async Task<ActionResult> UpdatePublicationContent(UpdatePublicationContentDto updateContent,
        CancellationToken ct)
    {
        var userId = User.GetUserId();
        return HandleResult(await Mediator.Send(
            new UpdatePublicationContent.Command { UpdateContentDto = updateContent, UserId = userId }, ct));
    }

    [Authorize]
    [HttpPut("update-planned")]
    public async Task<ActionResult> UpdatePlannedPublication(UpdatePlannedPublicationDto updateDto,
        CancellationToken ct)
    {
        var userId = User.GetUserId();
        return HandleResult(await Mediator.Send(
            new UpdatePlannedPublication.Command { UserId = userId, UpdateDto = updateDto }, ct));
    }

    [Authorize]
    [HttpPut("update-conditional")]
    public async Task<ActionResult> UpdateConditionalPublication(
        UpdateConditionalPublicationDto updateDto, CancellationToken ct)
    {
        var userId = User.GetUserId();
        return HandleResult(await Mediator.Send(
            new UpdateConditionalPublication.Command { UserId = userId, UpdateDto = updateDto }, ct));
    }
    

    [Authorize]
    [HttpGet("publication-of-{uniqueNameIdentifier}")]
    public async Task<ActionResult<PagedList<PublicationDto>>> GetPublicationsOfAuthor(string uniqueNameIdentifier,
        PaginationParams pgParams)
    {
        var userId = User.GetUserId();

        return HandleResult(await Mediator.Send(
            new GetPublicationsByUniqueNameIdentifier.Query
            {
                UniqueNameIdentifier = uniqueNameIdentifier,
                UserId = userId,
                PaginationParams = pgParams
            }
        ));
    }

    [Authorize]
    [HttpGet("{id}")]
    public async Task<ActionResult<PublicationDto>> GetPublicationById(string id)
    {
        string userId = User.GetUserId();

        return HandleResult(await Mediator.Send(new GetPublicationById.Query
        {
            PublicationId = id,
            UserId = userId
        }));
    }

    [Authorize]
    [HttpDelete("{id}")]
    public async Task<ActionResult> DeletePublication(string id)
    {
        var userId = User.GetUserId();
        return HandleResult(await Mediator.Send(new DeletePublication.Command
        {
            Id = id,
            UserId = userId
        }));
    }

    [Authorize]
    [HttpGet("like/{id}")]
    public async Task<ActionResult<LikeDto>> LikePublication(string id)
    {
        var userId = User.GetUserId();

        return HandleResult(await Mediator.Send(new LikePublication.Command
        {
            PublicationId = id,
            UserId = userId
        }));
    }

    // TODO: replace with filtration + pagination
    /*
    [HttpGet("planned-publications")]
    public async Task<ActionResult> GetPlannedPublications()
    {
        var userId = User.GetUserId();
        return HandleResult(await Mediator.Send(new GetPlannedPublications.Query { UserId = userId }));
    }
    */
    [Authorize]
    [HttpGet("publication-calendar")]
    public async Task<ActionResult> GetPublicationModelForCalendar()
    {
        var userId = User.GetUserId();

        return HandleResult(await Mediator.Send(new GetPublicationsCalendar.Query { UserId = userId }));
    }

    [Authorize]
    [HttpGet("publication/view-update/{id}")]
    public async Task<ActionResult> PublicationViewAdded(string id)
    {
        return HandleResult(await Mediator.Send(new UpdatePublicationViews.Command { PublicationId = id }));
    }

    [Authorize]
    [HttpGet("fetch-update-data/{id}")]
    public async Task<ActionResult> GetUpdateData(string id, CancellationToken ct)
    {
        var userId = User.GetUserId();
        return HandleResult(await Mediator.Send(new GetUpdateData.Query
        {
            PublicationId = id,
            UserId = userId
        }, ct));
    }
}
