﻿using System.Reflection.Metadata;
using Application.DTOs.DetailedUserInfoDTOs;
using Application.DTOs.UserDTOs;
using Microsoft.AspNetCore.Authorization;

namespace API.Controllers;

using Application.Features.Users.Commands;
using Application.Features.Users.Queries;
using Application.Helpers;
using Microsoft.AspNetCore.Mvc;

public class PublicUserController : BaseApiController
{
    [HttpGet("by-uni")]
    public async Task<ActionResult<PublicUserDto>> GetPublicUserByUni([FromQuery]string uNi)
    {
        string? userId;
        try
        {
            userId = User.GetUserId();
        }
        catch
        {
            return HandleResult(await Mediator.Send(
                new GetPublicUserByUniqueNameIdentifier.Query() { UniqueNameIdentifier = uNi, UserId = null}));
        }
        return HandleResult(await Mediator.Send(
            new GetPublicUserByUniqueNameIdentifier.Query() { UniqueNameIdentifier = uNi, UserId = userId}));
    }

    /*
    [Authorize]
    [HttpGet("my-profile")]
    public async Task<ActionResult> GetMyProfile()
    {
        string id = User.GetUserId();

        return HandleResult(await Mediator.Send(new GetPublicUserById.Query() { Id = id }));
    }
    */

    [Authorize]
    [HttpGet("fetch-update-data")]
    public async Task<ActionResult> GetDataForUpdate()
    {
        string id = User.GetUserId();

        return HandleResult(await Mediator.Send(new GetUpdateData.Query { UserId = id }));
    }

    [Authorize]
    [HttpPut("update-main-info")]
    public async Task<ActionResult<PublicUserDto>> UpdateMainInfo([FromBody] UpdateUserMainInfoDto
        updateUserMainInfoDto, CancellationToken ct)
    {
        var userId = User.GetUserId();
        var result = await Mediator.Send(new UpdateUserMainInfo.Command()
        {
            MainInfo = updateUserMainInfoDto,
            UserId = userId
        }, ct);

        return result.Match(
            user => Ok(user),
            options => Conflict(new { Options = options }),
            error => Problem(error.Message, statusCode: error.Code));
    }

    [Authorize]
    [HttpPut("update-additional-info")]
    public async Task<ActionResult<UserProfileDetailsDto>> UpdateAdditionalInfo(
        [FromBody] UpdateUserAdditionalInfoDto updateUserAdditionalInfoDto, CancellationToken ct )
    {
        var userId = User.GetUserId();
        var result = await Mediator.Send(new UpdateUserAdditionalInfo.Command
        {
            UserId = userId,
            UpdateModel = updateUserAdditionalInfoDto
        }, ct);

        return HandleResult(result);
    }

    [Authorize]
    [HttpPut("update-address")]
    public async Task<ActionResult<AddressDto>> UpdateAddress([FromBody] UpdateUserAddressDto updateUserAddressDto,
        CancellationToken ct)
    {
        var userId = User.GetUserId();
        var result = await Mediator.Send(new UpdateUserAddress.Command
        {
            UpdateModel = updateUserAddressDto,
            UserId = userId
        }, ct);

        return HandleResult(result);
    }

    [Authorize]
    [HttpPut("update-profile-image")]
    public async Task<ActionResult> UpdateProfileImage([FromForm] UpdateUserProfileImageDto updateUserProfileImageDto,
        CancellationToken ct)
    {
        var userId = User.GetUserId();
        var result = await Mediator.Send(new UpdateUserProfileImage.Command
        {
            UserId = userId,
            UpdateModel = updateUserProfileImageDto
        }, ct);

        return HandleResult(result);
    }

    [Authorize]
    [HttpDelete("delete-profile-image")]
    public async Task<ActionResult> DeleteProfileImage(CancellationToken ct)
    {
        var userId = User.GetUserId();
        var result = await Mediator.Send(new DeleteUserProfileImage.Command
        {
            UserId = userId
        }, ct);

        return HandleResult(result);
    }

    [HttpGet("user-search")]
    public async Task<ActionResult<List<PublicUserDto>>> SearchForUserByUniqueNameIdentifier([FromQuery] string searchQuery)
    {
        return HandleResult(await Mediator.Send(new GetUsersBySearchString.Query { SearchString = searchQuery }));
    }

    [Authorize]
    [HttpPost("settings/profanity")]
    public async Task<ActionResult> SetProfanitySetting(bool profanitySetting)
    {
        var userId = User.GetUserId();
        
        return HandleResult(await Mediator.Send(new SetProfanityFilterSetting.Command{UserId = userId, Value = 
            profanitySetting}));
    }
}
