﻿using Application.Core;
using Application.DTOs.AccountDTOs;
using Application.Interfaces.Services;

namespace Application.Features.Account.Commands;

public class GoogleLogin
{
    public class Command : IRequest<Result<AccountClaimsDto>>
    {
        public required GoogleAuthDto GoogleDto { get; set; }
    }
    
    public class Handler(IAccountService accountService) : IRequestHandler<Command, Result<AccountClaimsDto>>
    {
        public async Task<Result<AccountClaimsDto>> Handle(Command request, CancellationToken cancellationToken)
        {
            return await accountService.GoogleLoginAsync(request.GoogleDto, cancellationToken);
        }
    }
}