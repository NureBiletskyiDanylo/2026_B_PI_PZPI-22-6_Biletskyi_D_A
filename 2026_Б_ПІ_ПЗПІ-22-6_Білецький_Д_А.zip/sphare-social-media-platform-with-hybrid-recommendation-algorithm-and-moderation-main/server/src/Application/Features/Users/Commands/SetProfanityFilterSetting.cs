﻿using Application.Core;
using Application.Interfaces.Services;

namespace Application.Features.Users.Commands;

public class SetProfanityFilterSetting
{
    public class Command : IRequest<Result<Unit>>
    {
        public required string UserId { get; set; }
        public required bool Value { get; set; }
    }
    
    public class Handler(IUserService userService) : IRequestHandler<Command, Result<Unit>>
    {
        public async Task<Result<Unit>> Handle(Command request, CancellationToken cancellationToken)
        {
            return await userService.SetProfanityFilterSettings(request.UserId, request.Value, cancellationToken);
        }
    }
}