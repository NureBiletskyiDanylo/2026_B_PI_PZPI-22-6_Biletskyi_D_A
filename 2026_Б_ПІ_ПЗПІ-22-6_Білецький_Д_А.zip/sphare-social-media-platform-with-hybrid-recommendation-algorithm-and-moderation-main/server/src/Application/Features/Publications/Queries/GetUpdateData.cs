﻿using Application.Core;
using Application.DTOs.PublicationDTOs;
using Application.Interfaces.Services;

namespace Application.Features.Publications.Queries;

public class GetUpdateData
{
    public class Query : IRequest<Result<PublicationUpdateData?>>
    {
        public required string PublicationId { get; set; }
        public required string UserId { get; set; }
    }
    
    public class Handler(IPublicationService publicationService) : IRequestHandler<Query, Result<PublicationUpdateData?>>
    {
        public async Task<Result<PublicationUpdateData?>> Handle(Query request, CancellationToken cancellationToken)
        {
            return await publicationService.GetPublicationUpdateDataAsync(request.PublicationId, request.UserId,
                cancellationToken);
        }
    }
}