﻿using Application.Core;
using Application.DTOs.PublicationDTOs;
using Application.Interfaces.Services;

namespace Application.Features.Publications.Commands;

public class UpdatePublicationContent
{
    public class Command : IRequest<Result<Unit>>
    {
        public required UpdatePublicationContentDto UpdateContentDto { get; set; }
        public required string UserId { get; set; }
    }
    
    public class Handler(IPublicationService publicationService)
        : IRequestHandler<Command, Result<Unit>>
    {
        public async Task<Result<Unit>> Handle(Command request, CancellationToken cancellationToken)
        {
            return await publicationService.UpdatePublicationContentAsync(request.UpdateContentDto, request.UserId,
                cancellationToken);
        }
    }
}