﻿using Application.Core;
using Application.DTOs.PublicationDTOs;
using Application.Interfaces.Services;

namespace Application.Features.Publications.Commands;

public class UpdatePlannedPublication
{
    public class Command : IRequest<Result<Unit>>
    {
        public required string UserId { get; set; }
        public required UpdatePlannedPublicationDto UpdateDto { get; set; }
    }

    public class Handler(IPublicationService publicationService) : IRequestHandler<Command, Result<Unit>>
    {
        public async Task<Result<Unit>> Handle(Command request, CancellationToken cancellationToken)
        {
            return await publicationService.UpdatePlannedPublicationAsync(request.UpdateDto, request.UserId,
                cancellationToken);
        }
    }
}