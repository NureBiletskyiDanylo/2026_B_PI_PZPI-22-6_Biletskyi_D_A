﻿using Application.Core;
using Application.Interfaces;
using Application.Interfaces.Services;

namespace Application.Features.Messaging.Commands;

public class MarkMessageAsRead
{
    public class Command : IRequest<Result<Unit>>
    {
        public required string ChatId { get; set; }
        public required string UserId { get; set; }
    }
    
    public class Handler(IMessagingService messagingService, IChatNotifier chatNotifier) : IRequestHandler<Command, 
        Result<Unit>>
    {
        public async Task<Result<Unit>> Handle(Command request, CancellationToken cancellationToken)
        {
            var result = await messagingService.MarkMessagesAsReadAsync(
                request.ChatId, request.UserId, cancellationToken);

            if (result.IsSuccess)
            {
                await chatNotifier.NotifyMessagesRead(request.ChatId, request.UserId, cancellationToken);
            }

            return result;
        }
    }
}