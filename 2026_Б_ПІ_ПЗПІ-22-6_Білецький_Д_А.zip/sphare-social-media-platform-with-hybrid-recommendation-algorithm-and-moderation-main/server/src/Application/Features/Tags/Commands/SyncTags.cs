﻿using Application.Core;
using Application.Interfaces.Services;

namespace Application.Features.Tags.Commands;

public class SyncTags
{
    public class Command : IRequest<Result<Unit>>
    {
        public string UserId { get; set; } = string.Empty;
        public string PublicationId { get; set; } = string.Empty;
        public List<string> TagNames { get; set; } = [];
    }

    public class Handler(ITagService tagService) : IRequestHandler<Command, Result<Unit>>
    {
        public async Task<Result<Unit>> Handle(Command request, CancellationToken ct)
            => await tagService.SyncTagsAsync(
                request.UserId,
                request.PublicationId,
                request.TagNames,
                ct);
    }
}