﻿namespace Application.Interfaces.Services;

public interface IProfanityWordListProvider
{
    HashSet<string> Words { get; } 
}