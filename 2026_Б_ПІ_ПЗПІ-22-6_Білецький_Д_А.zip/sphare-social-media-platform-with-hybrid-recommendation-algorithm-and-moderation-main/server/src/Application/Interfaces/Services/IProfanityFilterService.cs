﻿using Application.Core;
using Domain.Entities.Publications;

namespace Application.Interfaces.Services;



public interface IProfanityFilterService
{
    Result<ProfanityCheckResult> Analyze(string content);
}