﻿namespace Application.Interfaces;

public interface IChatNotifier
{
    Task NotifyMessagesRead(string chatId, string readerId, CancellationToken ct); 
}