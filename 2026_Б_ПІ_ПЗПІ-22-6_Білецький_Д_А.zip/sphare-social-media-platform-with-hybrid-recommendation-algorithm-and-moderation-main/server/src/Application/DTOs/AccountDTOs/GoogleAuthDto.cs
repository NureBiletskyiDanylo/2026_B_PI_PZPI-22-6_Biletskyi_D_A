﻿namespace Application.DTOs.AccountDTOs;

public class GoogleAuthDto
{
    public required string IdToken { get; set; }
}