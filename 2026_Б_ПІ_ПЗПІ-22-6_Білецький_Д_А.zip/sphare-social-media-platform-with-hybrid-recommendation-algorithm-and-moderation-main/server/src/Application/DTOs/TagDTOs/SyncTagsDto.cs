﻿namespace Application.DTOs.TagDTOs;

public class SyncTagsDto
{
    public List<string> TagNames { get; set; } = [];
}