﻿namespace Application.DTOs.PublicationDTOs;

public class FlaggedSpanDto
{
    public int Start { get; set; }
    public int End { get; set; }
}