﻿using System.ComponentModel.DataAnnotations;
using Microsoft.AspNetCore.Mvc;

namespace Application.DTOs.PublicationDTOs;
using Domain.Enums;

using Microsoft.AspNetCore.Http;
using System;
using System.Collections.Generic;

public class CreatePublicationDto : IValidatableObject
{
    [FromForm(Name = "content")]
    public string? Content { get; set; }

    [FromForm(Name = "publicationType")]
    public PublicationTypes PublicationType { get; set; } = PublicationTypes.ordinary;

    [FromForm(Name = "images")]
    public List<IFormFile>? Images { get; set; }
    
    [FromForm(Name = "publishAt")]
    public DateTime? PublishAt { get; set; }
    
    [FromForm(Name = "conditionType")]
    public ConditionType? ConditionType { get; set; }

    [FromForm(Name = "conditionTarget")]
    public int? ConditionTarget { get; set; }

    [FromForm(Name = "conditionOperator")]
    public ComparisonOperator? ConditionOperator { get; set; }


    public IEnumerable<ValidationResult> Validate(ValidationContext validationContext)
    {
        if (string.IsNullOrWhiteSpace(Content) && (Images == null || Images.Count == 0))
            yield return new ValidationResult(
                "Publication must have either content or at least one image.");

        if (PublicationType == PublicationTypes.planned)
        {
            if (PublishAt == null)
                yield return new ValidationResult(
                    "PublishAt is required for planned publications.",
                    [nameof(PublishAt)]);

            if (PublishAt <= DateTime.UtcNow)
                yield return new ValidationResult(
                    "PublishAt must be in the future.",
                    [nameof(PublishAt)]);
        }

        if (PublicationType == PublicationTypes.conditional)
        {
            if (ConditionType == null)
                yield return new ValidationResult(
                    "ConditionType is required for conditional publications.",
                    [nameof(ConditionType)]);

            if (ConditionTarget == null)
                yield return new ValidationResult(
                    "ConditionTarget is required for conditional publications.",
                    [nameof(ConditionTarget)]);

            if (ConditionOperator == null)
                yield return new ValidationResult(
                    "ConditionOperator is required for conditional publications.",
                    [nameof(ConditionOperator)]);
        }
    }
}
