﻿using Domain.Enums;

namespace Application.DTOs.PublicationDTOs;

public class PublicationUpdateData
{
    public string Id { get; set; } = string.Empty;
    public string? Content { get; set; }
    public DateTime? PublishAt { get; set; }
    public required ConditionType? ConditionType { get; set; }
    public required int? ConditionTarget { get; set; }
    public required ComparisonOperator? ComparisonOperator { get; set; }
    public PublicationTypes PublicationType { get; set; }
}