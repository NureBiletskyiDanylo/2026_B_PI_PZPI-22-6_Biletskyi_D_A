﻿namespace Application.DTOs.UserDTOs;
public class AdminUserDto
{
    public string Id { get; set; } = string.Empty;
    public string Username { get; set; } = string.Empty;
    public string UniqueNameIdentifier { get; set; } = string.Empty;
    public string Email { get; set; } = string.Empty;
    public string? ProfileImageUrl { get; set; }
    public int ViolationScore { get; set; }
    public int AmountOfViolations { get; set; }
    public bool Blocked { get; set; }
    public DateTime? BlockedAt { get; set; }
}
