﻿using Domain.Entities.Publications;
using Domain.Entities.RecomendationEntities;

namespace Infrastructure;

using Domain.Entities;
using Domain.Entities.Complaints;
using Microsoft.EntityFrameworkCore;

public class ApplicationDbContext(DbContextOptions options) : DbContext(options)
{
    public DbSet<User> Users { get; set; }
    public DbSet<Publication> Publications { get; set; }
    public DbSet<PlannedPublication> PlannedPublications { get; set; }
    public DbSet<ConditionalPublication> ConditionalPublications { get; set; }
    public DbSet<Like> Likes { get; set; }
    public DbSet<Image> Images { get; set; }
    public DbSet<Comment> Comments { get; set; }
    public DbSet<Violation> Violations { get; set; }
    public DbSet<UserProfileDetails> ProfileDetails { get; set; }
    public DbSet<Address> Addresses { get; set; }
    public DbSet<Complaint> Complaints { get; set; }
    public DbSet<PublicationComplaint> PublicationComplaints { get; set; }
    public DbSet<CommentComplaint> CommentComplaints { get; set; }
    public DbSet<Chat> Chats { get; set; }
    public DbSet<Message> Messages { get; set; }
    public DbSet<ChatUser> ChatUsers { get; set; }
    public DbSet<SpamRating> SpamRatings { get; set; }
    public DbSet<UserActionLog> UserLogs { get; set; }
    public DbSet<PublicationTag> PublicationTags { get; set; }
    public DbSet<Tag> Tags { get; set; }
    public DbSet<UserInterestTag> UserInterestTags { get; set; }
    public DbSet<PublicationView> PublicationViews { get; set; }
    public DbSet<RefreshToken> RefreshTokens { get; set; }
    public DbSet<JobCheckpoint> JobCheckpoints { get; set; }
    public DbSet<UserSettings> UserSettings { get; set; }
    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        base.OnModelCreating(modelBuilder);
        modelBuilder.Entity<Like>()
            .HasKey(k => new { k.LikedById, k.PublicationId });

        modelBuilder.Entity<Like>()
            .HasOne(l => l.LikedBy)
            .WithMany(u => u.LikedPublications)
            .HasForeignKey(l => l.LikedById)
            .OnDelete(DeleteBehavior.Cascade);

        modelBuilder.Entity<Like>()
            .HasOne(l => l.Publication)
            .WithMany(p => p.Likes)
            .HasForeignKey(l => l.PublicationId)
            .OnDelete(DeleteBehavior.Cascade);

        modelBuilder.Entity<User>()
            .HasMany(u => u.CreatedPublications)
            .WithOne(p => p.Author)
            .HasForeignKey(l => l.AuthorId)
            .OnDelete(DeleteBehavior.NoAction);


        modelBuilder.Entity<Image>(entity =>
        {
            entity.HasOne(i => i.User)
                .WithOne(a => a.ProfileImage)
                .HasForeignKey<User>(u => u.ProfileImageId)
                .OnDelete(DeleteBehavior.SetNull);

            entity.HasOne(a => a.Publication)
            .WithMany(a => a.Images)
            .HasForeignKey(a => a.PublicationId)
            .OnDelete(DeleteBehavior.Cascade);
        });

        modelBuilder.Entity<User>()
            .HasOne(u => u.Address)
            .WithOne(a => a.User)
            .HasForeignKey<Address>(a => a.UserId)
            .OnDelete(DeleteBehavior.Cascade);

        modelBuilder.Entity<User>()
            .HasOne(u => u.ProfileDetails)
            .WithOne(d => d.User)
            .HasForeignKey<UserProfileDetails>(d => d.UserId)
            .OnDelete(DeleteBehavior.Cascade);

        // complaints 
        modelBuilder.Entity<PublicationComplaint>()
            .HasOne(c => c.Publication)
            .WithMany(a => a.PublicationComplaints)
            .HasForeignKey(c => c.PublicationId)
            .OnDelete(DeleteBehavior.Cascade);

        modelBuilder.Entity<CommentComplaint>()
            .HasOne(c => c.Comment)
            .WithMany(a => a.CommentComplaints)
            .HasForeignKey(c => c.CommentId)
            .OnDelete(DeleteBehavior.Cascade);

        // comment trees
        modelBuilder.Entity<Comment>()
            .HasOne(c => c.ParentComment)
            .WithMany(c => c.Replies)
            .HasForeignKey(c => c.ParentCommentId)
            .OnDelete(DeleteBehavior.Restrict);

        modelBuilder.Entity<Comment>()
            .HasIndex(c => new { c.PublicationId, c.ParentCommentId, c.CreationDate });


        modelBuilder.Entity<UserProfileDetails>()
            .Property(x => x.DateOfBirth)
            .HasColumnType("date");

        modelBuilder.Entity<ChatUser>()
            .HasKey(x => new { x.ChatId, x.UserId });

        modelBuilder.Entity<ChatUser>()
            .HasOne(x => x.Chat)
            .WithMany(c => c.Participants)
            .HasForeignKey(x => x.ChatId)
            .OnDelete(DeleteBehavior.Cascade);

        modelBuilder.Entity<ChatUser>()
            .HasOne(x => x.User)
            .WithMany(c => c.Chats)
            .HasForeignKey(x => x.UserId)
            .OnDelete(DeleteBehavior.Cascade);

        modelBuilder.Entity<SpamRating>()
            .HasOne(u => u.User)
            .WithOne(s => s.SpamRating)
            .HasForeignKey<SpamRating>(u => u.UserId)
            .OnDelete(DeleteBehavior.Cascade); 

        modelBuilder.Entity<User>()
            .HasMany(c => c.ActionLogs)
            .WithOne(x => x.User)
            .HasForeignKey(x => x.UserId)
            .OnDelete(DeleteBehavior.NoAction);
        
        modelBuilder.Entity<Tag>()
            .HasIndex(t => t.Name)
            .HasMethod("gin")
            .HasOperators("gin_trgm_ops");

        modelBuilder.Entity<PublicationTag>()
            .HasKey(pt => new { pt.PublicationId, pt.TagId });

        modelBuilder.Entity<PublicationTag>()
            .HasOne(pt => pt.Publication)
            .WithMany(p => p.PublicationTags)
            .HasForeignKey(pt => pt.PublicationId)
            .OnDelete(DeleteBehavior.Cascade);

        modelBuilder.Entity<PublicationTag>()
            .HasOne(pt => pt.Tag)
            .WithMany(t => t.Publications)
            .HasForeignKey(pt => pt.TagId)
            .OnDelete(DeleteBehavior.Cascade);

        // UserInterestTag — composite key
        modelBuilder.Entity<UserInterestTag>()
            .HasKey(ui => new { ui.UserId, ui.TagId });

        modelBuilder.Entity<UserInterestTag>()
            .HasOne(ui => ui.User)
            .WithMany(u => u.InterestTags)
            .HasForeignKey(ui => ui.UserId)
            .OnDelete(DeleteBehavior.Cascade);

        modelBuilder.Entity<UserInterestTag>()
            .HasOne(ui => ui.Tag)
            .WithMany(t => t.UserInterests)
            .HasForeignKey(ui => ui.TagId)
            .OnDelete(DeleteBehavior.Cascade);

        // PublicationView
        modelBuilder.Entity<PublicationView>()
            .HasOne(pv => pv.User)
            .WithMany(u => u.ViewedPublications)
            .HasForeignKey(pv => pv.UserId)
            .OnDelete(DeleteBehavior.Cascade);

        modelBuilder.Entity<PublicationView>()
            .HasOne(pv => pv.Publication)
            .WithMany(p => p.Views)
            .HasForeignKey(pv => pv.PublicationId)
            .OnDelete(DeleteBehavior.Cascade);

        modelBuilder.Entity<UserInterestTag>()
            .HasIndex(ui => new { ui.UserId, ui.Weight });

        modelBuilder.Entity<PublicationView>()
            .HasIndex(pv => new { pv.UserId, pv.ViewedAt });
        
        modelBuilder.Entity<JobCheckpoint>()
            .HasKey(j => j.JobName);
        
        modelBuilder.Entity<Publication>()
            .HasDiscriminator<string>("PublicationType")
            .HasValue<Publication>("ordinary")
            .HasValue<PlannedPublication>("planned")
            .HasValue<ConditionalPublication>("conditional");

        modelBuilder.Entity<Publication>().OwnsMany(p => p.FlaggedSpans, spans =>
        {
            spans.ToJson();
        });
        
        modelBuilder.Entity<User>()
            .HasOne(u => u.UserSettings)
            .WithOne(us => us.User)
            .HasForeignKey<UserSettings>(us => us.UserId);

        modelBuilder.Entity<UserSettings>()
            .HasKey(us => us.UserId);
    }
}
