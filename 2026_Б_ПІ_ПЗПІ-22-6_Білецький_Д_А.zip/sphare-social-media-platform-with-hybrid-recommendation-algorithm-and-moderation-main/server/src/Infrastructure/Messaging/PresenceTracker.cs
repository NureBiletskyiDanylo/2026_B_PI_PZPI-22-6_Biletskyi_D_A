﻿using System.Collections.Concurrent;

namespace Infrastructure.Messaging;

public class PresenceTracker
{
    private static readonly ConcurrentDictionary<string, HashSet<string>> OnlineUsers = new();

    public Task<bool> UserConnected(string userId, string connectionId)
    {
        bool isFirstConnection = false;
        lock (OnlineUsers)
        {
            if (!OnlineUsers.ContainsKey(userId))
            {
                OnlineUsers[userId] = new HashSet<string>();
                isFirstConnection = true;
            }
            OnlineUsers[userId].Add(connectionId);
        }
        return Task.FromResult(isFirstConnection);
    }

    public Task<bool> UserDisconnected(string userId, string connectionId)
    {
        bool isLastConnectionRemoved = false;
        lock (OnlineUsers)
        {
            if (!OnlineUsers.ContainsKey(userId)) return Task.FromResult(false);

            OnlineUsers[userId].Remove(connectionId);

            if (OnlineUsers[userId].Count == 0)
            {
                OnlineUsers.TryRemove(userId, out _);
                isLastConnectionRemoved = true;
            }
        }
        return Task.FromResult(isLastConnectionRemoved);
    } 
    
    public bool IsOnline(string userId)
    {
        lock (OnlineUsers)
        {
            return OnlineUsers.TryGetValue(userId, out var conns) && conns.Count > 0;
        }
    }

    public List<string> GetOnlineUserIds(IEnumerable<string> userIds)
    {
        lock (OnlineUsers)
        {
            return userIds.Where(id => OnlineUsers.TryGetValue(id, out var c) && c.Count > 0).ToList();
        }
    }
}