﻿using Application.Core;
using Application.Core.Pagination;
using Application.DTOs.PublicationDTOs;
using Application.Errors;
using Application.Interfaces.Logger;
using Application.Interfaces.Repositories;
using Application.Interfaces.Services;
using Domain.Entities.Publications;
using Domain.Enums;
using MediatR;

namespace Infrastructure.Services;

public class PublicationService(IPublicationRepository publicationRepository, 
    IUserActionLogger<PublicationService> logger, ISpamRepository spamRepository,
    IPhotoService photoService, IUserRepository userRepository, IProfanityFilterService profanityFilterService) 
    : IPublicationService
{

    public async Task<Result<List<PublicationNotificationDto>>> GetPublicationsToRemindAsync(DateTime postedAt, int 
            batchSize, CancellationToken ct)
    {
        try
        {
            var publications = await publicationRepository.GetPublicationsToRemindAsync(postedAt, batchSize, ct);
            return Result<List<PublicationNotificationDto>>.Success(publications);
        }
        catch
        {
            return Result<List<PublicationNotificationDto>>.Failure("Publication fetching was unsuccessful", 500);
        }
    }

    public async Task<Result<List<PublicationCalendarDto>>> GetPublicationsCalendarAsync(string userId, 
        CancellationToken ct)
    {
        bool userExists = await userRepository.IsUserExistsByIdAsync(userId, ct);
        if (!userExists)
            return Result<List<PublicationCalendarDto>>
                .Failure("User was not found", 404);
        try
        {
            var publications = await publicationRepository.GetPublicationsForCalendarAsync(userId, ct);
            return Result<List<PublicationCalendarDto>>.Success(publications);
        }
        catch
        {
            return Result<List<PublicationCalendarDto>>.Failure("Calendar fetching was unsuccessful", 500);
        }

    }

    public async Task<Result<PagedList<PublicationCardDto>>> GetPublicationsByUniqueNameIdentifierAsync(
        string uniqueName, string userId, int page, int pageSize, CancellationToken ct)
    {
        bool userExists = await userRepository.IsUserExistsByIdAsync(userId, ct);
        if (!userExists)
            return Result<PagedList<PublicationCardDto>>
                .Failure("User was not found", 404);

        try
        {
            var pagedResult = await publicationRepository.GetBatchOfPublicationCardsDto(uniqueName, userId, page,
                pageSize, ct);
            return Result<PagedList<PublicationCardDto>>
                .Success(pagedResult);
        }
        catch
        {
            return Result<PagedList<PublicationCardDto>>
                .Failure("Publication loading was unsuccessful", 400);
        }
    }

    public async Task<Result<PublicationDto>> GetPublicationByIdAsync(string publicationId, string userId, 
        CancellationToken ct)
    {
        bool userExists = await userRepository.IsUserExistsByIdAsync(userId, ct);
        if (!userExists)
            return Result<PublicationDto>
                .Failure(UserErrors.UserNotFound());
        
        var publication = await publicationRepository.GetPublicationByIdAsync(publicationId, userId, ct);

        if (publication == null)
            return Result<PublicationDto>.Failure("Publication was not found", 404);

        publication.IsOwner = publication.Author.Id == userId;
        return Result<PublicationDto>.Success(publication);
    }

    public async Task<Result<List<PublicationDto>>> GetPlannedPublicationsAsync(string userId, CancellationToken ct)
    {
        bool userExists = await userRepository.IsUserExistsByIdAsync(userId, ct);
        if (!userExists)
            return Result<List<PublicationDto>>
                .Failure("User was not found", 404);
        try
        {
            var publications = await publicationRepository.GetPlannedPublicationsAsync(userId, ct);
            return Result<List<PublicationDto>>.Success(publications);
        }
        catch
        {
            return Result<List<PublicationDto>>.Failure("Fetching planned publications was unsuccessful", 500);
        }
    }

    public async Task<Result<PublicationUpdateData?>> GetPublicationUpdateDataAsync(string publicationId, string userId,
        CancellationToken ct)
    {
        bool userExists = await userRepository.IsUserExistsByIdAsync(userId, ct);
        if (!userExists)
            return Result<PublicationUpdateData?>
                .Failure(UserErrors.UserNotFound());

        var publicationUpdateData = await publicationRepository.GetUpdatePublicationData(publicationId, ct);
        if (publicationUpdateData == null)
            return Result<PublicationUpdateData?>.Failure(PublicationErrors.NotFound());

        return publicationUpdateData;
    }

    public async Task<Result<int>> UpdatePublicationViewsAsync(string publicationId, CancellationToken ct)
    {
        try
        {
            var viewCount = await publicationRepository.UpdatePublicationViewsAsync(publicationId, ct);
            return Result<int>.Success(viewCount);
        }
        catch
        {
            return Result<int>.Failure("Publication view update was unsuccessful", 500);
        }
    }


    public async Task<Result<Unit>> UpdatePublicationContentAsync(UpdatePublicationContentDto updateContentDto,
        string userId, CancellationToken ct)
    {
        var userAllowed = await publicationRepository.IsUserAuthorAsync(userId, updateContentDto.PublicationId, ct);
        if (!userAllowed)
            return Result<Unit>.Failure(
                PublicationErrors.NotAuthorised());

        List<FlaggedSpan> flaggedSpans = [];
        if (!string.IsNullOrEmpty(updateContentDto.NewContent))
        {
            var result = profanityFilterService.Analyze(updateContentDto.NewContent);
            if (result.IsSuccess && result.Value != null)
                flaggedSpans = result.Value.FlaggedSpans.ToList();
        }
        try
        {
            var contentUpdateSuccessful = await publicationRepository.UpdatePublicationContentAsync(updateContentDto, 
                ct);
            if (!contentUpdateSuccessful) return Result<Unit>.Failure(PublicationErrors.UpdateUnsuccessful());

            var flaggedSpanUpdateSuccessful = await publicationRepository.UpdateFlaggedSpans(flaggedSpans,
                updateContentDto.PublicationId, ct);
            if (!flaggedSpanUpdateSuccessful) return Result<Unit>.Failure(PublicationErrors.UpdateUnsuccessful());

            var publication = await publicationRepository.GetPublicationByIdAsync(updateContentDto.PublicationId,
                userId, ct);

            if (publication == null) return Result<Unit>.Failure(PublicationErrors.FetchingUnsuccessful());
            
            publication.IsOwner = true;
            return Result<Unit>.Success(Unit.Value);

        }
        catch
        {
            return Result<Unit>.Failure(PublicationErrors.UpdateUnsuccessful());
        }
        
    }

    public async Task<Result<Unit>> UpdateConditionalPublicationAsync(UpdateConditionalPublicationDto updateDto,
        string userId, CancellationToken ct)
    {
        var publication = await publicationRepository.GetRawPublicationByIdAsync(updateDto.PublicationId, ct);

        var verificationResult = await VerifyPublication(publication, userId, ct);
        if (!verificationResult.IsSuccess)
            return Unit.Value;

        var res = await publicationRepository.UpdateConditionalPublicationAsync(updateDto, ct);
        if (!res)
            return Result<Unit>.Failure(PublicationErrors.UpdateUnsuccessful());

        var publicationResult = await publicationRepository.GetPublicationByIdAsync(publication!.Id, userId, ct);
        if (publicationResult == null)
            return Result<Unit>.Failure(PublicationErrors.UpdateUnsuccessful());

        publicationResult.IsOwner = true;
        return Unit.Value;
    }

    //TODO: Check two calls for the publication in that method, are TWO GETS important here?
    public async Task<Result<Unit>> UpdatePlannedPublicationAsync(UpdatePlannedPublicationDto updateDto,
        string userId, CancellationToken ct)
    {
        var publication = await publicationRepository.GetRawPublicationByIdAsync(updateDto.PublicationId, ct);
        var verificationResult = await VerifyPublication(publication, userId, ct);
        if (!verificationResult.IsSuccess)
            return Unit.Value;

        var res = await publicationRepository.UpdatePlannedPublicationAsync(updateDto, ct);
        if (!res)
            return Result<Unit>.Failure(PublicationErrors.UpdateUnsuccessful());

        var publicationResult = await publicationRepository.GetPublicationByIdAsync(publication!.Id, userId, ct);
        if (publicationResult == null)
            return Result<Unit>.Failure(PublicationErrors.UpdateUnsuccessful());
        
        publicationResult.IsOwner = true;
        return Unit.Value;
    }

    public async Task<Result<Unit>> SetPublicationSentStateAsync(string publicationId, bool state, CancellationToken ct)
    {
        var isSuccess = await publicationRepository.SetPublicationStateToSentAsync(publicationId, ct);
        return !isSuccess ? Result<Unit>.Failure(PublicationErrors.NotFound()) : Result<Unit>.Success(Unit.Value);
    }

    public async Task<Result<Unit>> DeletePublicationAsync(string publicationId, string userId, CancellationToken ct)
    {
        var publicationNavProps = await publicationRepository
            .GetPublicationNavigationPropertiesAsync(publicationId, ct);

        if (publicationNavProps == null)
            return Result<Unit>.Failure(PublicationErrors.NotFound());

        if (userId != publicationNavProps.AuthorId)
            return Result<Unit>.Failure(PublicationErrors.NotAuthorised());

        var publicationExists = await publicationRepository.IsPublicationExistsAsync(publicationNavProps.PublicationId, 
            ct);

        if (!publicationExists)
            return Result<Unit>.Failure(PublicationErrors.NotFound());

        var isDeleted = await publicationRepository.DeletePublicationAsync(publicationId, ct);
        if (!isDeleted)
            return Result<Unit>.Failure(PublicationErrors.DeleteUnsuccessful());
        
        if (publicationNavProps.ImageIds is { Count: > 0 })
        {
            var deletionResult = await photoService.DeletePublicationImagesAsync(publicationNavProps.ImageIds, ct);
            if (!deletionResult.IsSuccess) return deletionResult;
        }
            
        //TODO: Fix the logging
        /*
        await logger.LogAsync(publication.AuthorId, UserLogAction.DeletePublication, new
        {
            info = $"Publication " +
                   $"was deleted by {publication.AuthorId}"
        }, publication.Id, ct);
        */
        return Result<Unit>.Success(Unit.Value);
    }

    public async Task<Result<string>> CreatePublicationAsync(CreatePublicationDto createDto, string creatorId, 
        CancellationToken ct)
    {
        var user = await userRepository.GetUserByIdAsync(creatorId, ct);
        if (user == null)
            return Result<string>
                .Failure(PublicationErrors.NotAuthorised());
        
        bool isPublicationSpamming = await spamRepository.IsPublicationSpamming(user.Id, user.DateOfCreation, ct);
        if (isPublicationSpamming)
            return Result<string>
                .Failure(SpamErrors.PublicationSpam);

        // TODO: Move it down
        /*
        var res = await spamRepository.MakePublication(user.Id, ct);
        if (!res)
        {
            return Result<bool>.Failure(
                "You cannot make more publications for today due to our anti spam rules", 400);
        }
        */
        List<FlaggedSpan> flaggedSpans = [];
        if (!string.IsNullOrEmpty(createDto.Content))
        {
            var result = profanityFilterService.Analyze(createDto.Content);
            if (result.IsSuccess && result.Value != null)
                flaggedSpans = result.Value.FlaggedSpans.ToList();
        }
            
        Publication publication = createDto.PublicationType switch
        {
            PublicationTypes.planned => new PlannedPublication
            {
                PublishAt = createDto.PublishAt!.Value,
                WasPublished = false
            },
            PublicationTypes.conditional => new ConditionalPublication
            {
                ConditionType = createDto.ConditionType!.Value,
                ConditionTarget = createDto.ConditionTarget!.Value,
                ComparisonOperator = createDto.ConditionOperator!.Value,
                WasPublished = false
            },
            _ => new Publication()
        };

        // shared fields — replaces what mapper was doing
        publication.Id = Guid.NewGuid().ToString();
        publication.Content = createDto.Content;
        publication.Author = user;
        publication.AuthorId = user.Id;
        publication.PostedAt = DateTime.UtcNow;
        publication.FlaggedSpans = flaggedSpans;

        if (createDto.Images != null && createDto.Images.Count > 0)
        {
            var images = await photoService.UploadPublicationImages(createDto.Images, publication.Id, ct);
            if (images.IsSuccess)
            {
                publication.Images = images.Value;
            }
            else
            {
                return Result<string>.Failure(images.Error!, images.Code);
            }

        }

        await publicationRepository.AddPublication(publication, ct);

        //TODO: Fix logger
        /*
        await logger.LogAsync(creatorId, UserLogAction.CreatePublication, new
        {
            info = $"User {createDto} has created a publication {publication.Id}"
        }, publication.Id, ct);
        */
        return Result<string>.Success(publication.Id);
    }

    private async Task<Result<PublicationDto>> VerifyPublication(Publication? publication, string userId, 
        CancellationToken ct)
    {
        if (publication == null)
            return Result<PublicationDto>.Failure(PublicationErrors.NotFound());

        if (publication.AuthorId != userId)
            return Result<PublicationDto>.Failure(PublicationErrors.NotAuthorised());
        
        if (publication.WasPublished)
            return Result<PublicationDto>.Failure(PublicationErrors.UpdateSpecialError());

        return Result<PublicationDto>.Success(null!);
    }
}