﻿using Application.Interfaces.Services;

namespace Infrastructure.Services;

public class FileProfanityWordListProvider : IProfanityWordListProvider
{
    public HashSet<string> Words { get; }
    
    public FileProfanityWordListProvider(string filePath)
    {
        Words = File.Exists(filePath)
            ? new HashSet<string>(
                File.ReadAllLines(filePath).Select(w => w.Trim()),
                StringComparer.OrdinalIgnoreCase)
            : new HashSet<string>(StringComparer.OrdinalIgnoreCase);
    }
}