﻿using Domain.Entities.Publications;
using Domain.Enums;

namespace Infrastructure.Services;
using Application.Core;
using Application.Core.Pagination;
using Application.DTOs.PublicationDTOs;
using Application.DTOs.UserDTOs;
using Application.Interfaces.Services;
using Extensions;
using Microsoft.EntityFrameworkCore;

public class RecommendationService(ApplicationDbContext context) : IRecommendationService
{
    public async Task<Result<PagedList<PublicationCardDto>>> GetRecommendations(string userId, int page, int pageSize,
        CancellationToken ct)
    {
        var now = DateTime.UtcNow;

        var interests = await context.UserInterestTags
            .AsNoTracking()
            .Where(i => i.UserId == userId && i.Weight > 0.1f)
            .ToListAsync(ct);

        if (!interests.Any())
        {
            var fallback = await GetFallbackRecommendationsAsync(userId, page, pageSize, ct);
            return Result<PagedList<PublicationCardDto>>.Success(fallback);
        }

        var interestTagIds = interests.Select(i => i.TagId).ToHashSet();
        var weightLookup = interests.ToDictionary(i => i.TagId, i => i.Weight);

        var seenIds = await context.PublicationViews
            .AsNoTracking()
            .Where(v => v.UserId == userId && v.ViewedAt > now.AddDays(-60))
            .Select(v => v.PublicationId)
            .ToListAsync(ct);

        var candidates = await context.Publications
            .AsNoTracking()
            .Include(p => p.Images)
            .Include(p => p.Likes)
            .Include(p => p.Comments)
            .Include(p => p.Author)
            .ThenInclude(p => p.ProfileImage)
            .Where(p => !p.IsDeleted
                        && p.AuthorId != userId 
                        && !seenIds.Contains(p.Id)
                        && p.PublicationTags.Any(pt => interestTagIds.Contains(pt.TagId)))
            .OrderByDescending(p => p.PostedAt)
            .Take(200)
            .Select(p => new RecommendationCandidate
            {
                Publication = p,
                MatchingTagIds = p.PublicationTags
                    .Where(pt => interestTagIds.Contains(pt.TagId))
                    .Select(pt => pt.TagId)
                    .ToList()
            })
            .ToListAsync(ct);

        List<Publication> recommended = [];
        int totalScoredCount = 0;

        if (candidates.Any())
        {
            var scored = RankCandidates(candidates, weightLookup, now);

            totalScoredCount = scored.Count;
            var skip = (page - 1) * pageSize;

            recommended = scored
                .Skip(skip)
                .Take(pageSize)
                .Select(x => x.Publication)
                .ToList();
        }

        if (recommended.Count < pageSize)
        {
            int needed = pageSize - recommended.Count;
            var excludedIds = recommended.Select(r => r.Id).ToList();

            var fallbackItems = await context.Publications
                .AsNoTracking()
                .Include(p => p.Images)
                .Include(p => p.Likes)
                .Include(p => p.Comments)
                .Include(p => p.Author)
                .ThenInclude(p => p.ProfileImage)
                .Where(p => !p.IsDeleted 
                            && p.AuthorId != userId 
                            && !excludedIds.Contains(p.Id)
                            && p.PostedAt > now.AddDays(-30)) 
                .OrderByDescending(p => p.Likes.Count * 0.6f + p.ViewCount * 0.1f)
                .Take(needed) 
                .ToListAsync(ct);

            recommended.AddRange(fallbackItems);
            
            if (fallbackItems.Count == needed)
            {
                totalScoredCount = Math.Max(totalScoredCount, page * pageSize + 1);
            }
            else
            {
                totalScoredCount = recommended.Count + (page - 1) * pageSize;
            }
        }

        var resultItems = recommended
            .Select(p => MapToDto(p, userId))
            .ToList();

        var pagedResult = PagedList<PublicationCardDto>.Create(resultItems, totalScoredCount, page, pageSize);

        return Result<PagedList<PublicationCardDto>>.Success(pagedResult);
    }

    private static float CalculateRawTagScore(List<int> matchingTagIds, Dictionary<int, float> weightLookup)
    {
        return matchingTagIds.Sum(tagId => weightLookup.GetValueOrDefault(tagId, 0f));
    }

    private static List<ScoredPublication> RankCandidates(
        List<RecommendationCandidate> candidates, 
        Dictionary<int, float> weightLookup, 
        DateTime now)
    {
        var rawMetrics = candidates.Select(c =>
        {
            float rawTag = CalculateRawTagScore(c.MatchingTagIds, weightLookup);
            float ageInDays = (float)(now - c.Publication.PostedAt).TotalDays;
            float rawRecency = 1f / (1f + ageInDays * 0.1f);
            float rawPopularity = MathF.Log(1f + c.Publication.ViewCount);

            return new { c.Publication, RawTag = rawTag, RawRecency = rawRecency, RawPopularity = rawPopularity };
        }).ToList();

        float maxTag = rawMetrics.Max(m => m.RawTag);
        float minTag = rawMetrics.Min(m => m.RawTag);
        float maxPopularity = rawMetrics.Max(m => m.RawPopularity);
        float minPopularity = rawMetrics.Min(m => m.RawPopularity);

        return rawMetrics.Select(m =>
        {
            float normTag = (maxTag - minTag) > 0.0001f ? (m.RawTag - minTag) / (maxTag - minTag) : 0f;
            float normRecency = m.RawRecency;
            float normPopularity = (maxPopularity - minPopularity) > 0.0001f ? (m.RawPopularity - minPopularity) / (maxPopularity - minPopularity) : 0f;

            float finalScore = (normTag * 0.70f) + (normRecency * 0.20f) + (normPopularity * 0.10f);

            return new ScoredPublication { Publication = m.Publication, Score = finalScore };
        })
        .OrderByDescending(x => x.Score)
        .ToList();
    }

    private async Task<PagedList<PublicationCardDto>> GetFallbackRecommendationsAsync(
        string userId, int page, int pageSize, CancellationToken ct)
    {
        var now = DateTime.UtcNow;

        return await context.Publications
            .AsNoTracking()
            .Where(p => !p.IsDeleted 
                        && p.AuthorId != userId 
                        && p.PostedAt > now.AddDays(-30))
            .OrderByDescending(p => p.Likes.Count * 0.6f + p.ViewCount * 0.1f)
            .Select(p => new PublicationCardDto
            {
                Id = p.Id,
                Content = p.Content,
                PostedAt = p.PostedAt,
                UpdatedAt = p.UpdatedAt,
                ImageUrls = p.Images!.Select(i => i.ImageUrl).ToList(),
                Author = new PublicUserBriefDto
                {
                    Id = p.Author.Id,
                    Username = p.Author.Username,
                    UniqueNameIdentifier = p.Author.UniqueNameIdentifier,
                    Blocked = p.Author.Blocked,
                    ImageUrl = p.Author.ProfileImage != null ? p.Author.ProfileImage.ImageUrl : null
                },
                LikesAmount = p.Likes.Count(),
                IsLikedByCurrentUser = p.Likes.Any(l => l.LikedById == userId),
                CommentAmount = p.Comments!.Count(),
                PublicationType = p is PlannedPublication ? PublicationTypes.planned
                    : p is ConditionalPublication ? PublicationTypes.conditional
                    : PublicationTypes.ordinary,
                ViewCount = p.ViewCount,
                IsDeleted = p.IsDeleted,
                IsOwner = false
            })
            .ToPagedListAsync(page, pageSize, ct);
    }

    private static PublicationCardDto MapToDto(Publication p, string userId) => new()
    {
        Id = p.Id,
        Content = p.Content,
        PostedAt = p.PostedAt,
        UpdatedAt = p.UpdatedAt,
        ImageUrls = p.Images!.Select(i => i.ImageUrl).ToList(),
        Author = new PublicUserBriefDto
        {
            Id = p.Author.Id,
            Username = p.Author.Username,
            UniqueNameIdentifier = p.Author.UniqueNameIdentifier,
            Blocked = p.Author.Blocked,
            ImageUrl = p.Author.ProfileImage != null ? p.Author.ProfileImage.ImageUrl : null
        },
        LikesAmount = p.Likes.Count(),
        IsLikedByCurrentUser = p.Likes.Any(l => l.LikedById == userId),
        CommentAmount = p.Comments!.Count(),
        PublicationType = p is PlannedPublication ? PublicationTypes.planned
                    : p is ConditionalPublication ? PublicationTypes.conditional
                    : PublicationTypes.ordinary,
        ViewCount = p.ViewCount,
        IsDeleted = p.IsDeleted,
        IsOwner = p.AuthorId == userId
    };

    private class RecommendationCandidate
    {
        public required Publication Publication { get; init; }
        public required List<int> MatchingTagIds { get; init; }
    }

    private class ScoredPublication
    {
        public required Publication Publication { get; init; }
        public float Score { get; init; }
    }
}