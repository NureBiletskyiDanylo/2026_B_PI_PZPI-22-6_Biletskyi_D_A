﻿using System.Text.RegularExpressions;
using Application.Core;
using Application.Interfaces.Services;
using Domain.Entities.Publications;

namespace Infrastructure.Services;

public class ProfanityFilterService : IProfanityFilterService
{
    private static readonly Regex WordPattern = new(
        @"\w+", RegexOptions.Compiled | RegexOptions.CultureInvariant);

    private readonly HashSet<string> _profanityWords;

    public ProfanityFilterService(IProfanityWordListProvider wordListProvider)
    {
        _profanityWords = wordListProvider.Words;
    }

    public Result<ProfanityCheckResult> Analyze(string content)
    {
        if (string.IsNullOrWhiteSpace(content))
            return Result<ProfanityCheckResult>.Success(
                new ProfanityCheckResult(false, Array.Empty<FlaggedSpan>()));

        var flagged = new List<FlaggedSpan>();

        foreach (Match match in WordPattern.Matches(content))
        {
            if (_profanityWords.Contains(match.Value))
                flagged.Add(new FlaggedSpan(match.Index, match.Index + match.Length));
        }

        return Result<ProfanityCheckResult>.Success(
            new ProfanityCheckResult(flagged.Count > 0, flagged));
    }
}