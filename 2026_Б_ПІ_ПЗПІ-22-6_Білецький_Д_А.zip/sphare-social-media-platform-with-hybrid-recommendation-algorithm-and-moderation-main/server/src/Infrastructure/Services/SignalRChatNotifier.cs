﻿using Application.Interfaces;
using Infrastructure.Messaging;
using Microsoft.AspNetCore.SignalR;

namespace Infrastructure.Services;

public class SignalRChatNotifier(IHubContext<ChatHub> hubContext) : IChatNotifier
{
    public async Task NotifyMessagesRead(string chatId, string readerId, CancellationToken ct)
    {
        await hubContext.Clients.Group(chatId)
            .SendAsync("MessagesRead", chatId, readerId, ct);
    }
}