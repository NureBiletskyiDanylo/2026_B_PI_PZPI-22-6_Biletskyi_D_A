import {AccountService} from "../../services/account.service";

declare const google: any;
import {AfterViewInit, Component, ElementRef, inject, ViewChild} from '@angular/core';
import {Router} from "@angular/router";
import {environment} from "../../../../../environments/environment";

@Component({
  selector: 'app-google-login',
  imports: [],
  templateUrl: './google-login.component.html',
  styleUrl: './google-login.component.css'
})
export class GoogleLoginComponent implements AfterViewInit {
  @ViewChild('googleBtn') googleBtn!: ElementRef;

  private googleLoginService: AccountService = inject(AccountService);
  private router: Router = inject(Router);

  ngAfterViewInit() {
    this.waitForGoogle(() => this.initGoogleButton());
  }


  private handleCredential(idToken: string) {
    this.googleLoginService.googleLogin(idToken).subscribe({
      next: (account) => {
        this.router.navigate(['/']);
      },
      error: (err) => console.error('Google login failed', err)
    });
  }

  private initGoogleButton() {
    google.accounts.id.initialize({
      client_id: environment.googleClientId,
      callback: (response: { credential: string }) => this.handleCredential(response.credential)
    });
    google.accounts.id.renderButton(this.googleBtn.nativeElement, {
      theme: 'outline',
      size: 'large'
    });
  }

  private waitForGoogle(callback: () => void, retries = 20) {
    if (typeof google !== 'undefined' && google.accounts?.id) {
      callback();
    } else if (retries > 0) {
      setTimeout(() => this.waitForGoogle(callback, retries - 1), 100);
    } else {
      console.error('Google Identity Services failed to load');
    }
  }
}
