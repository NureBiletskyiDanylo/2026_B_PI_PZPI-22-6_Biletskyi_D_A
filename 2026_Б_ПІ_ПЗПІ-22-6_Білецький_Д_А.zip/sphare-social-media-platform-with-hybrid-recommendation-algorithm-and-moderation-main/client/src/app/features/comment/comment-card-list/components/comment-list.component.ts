import {Component, HostListener, inject, OnInit} from '@angular/core';
import {ActivatedRoute} from "@angular/router";
import {CommentListService} from "../services/comment-list.service";
import {defaultPaginationParams, PagedList, PaginationParams} from "../../../../shared/models/pagedlist.dto";
import {CommentDto} from "../../comment-card-view/models/comment.dto";
import {CommentCardComponent} from "../../comment-card-view/components/comment-card.component";

@Component({
  selector: 'app-comment-list',
  imports: [
    CommentCardComponent
  ],
  templateUrl: './comment-list.component.html',
  styleUrl: './comment-list.component.css'
})
export class CommentListComponent implements OnInit {
  private route = inject(ActivatedRoute);
  private commentListService = inject(CommentListService);

  publicationId: string | null = null;

  comments: CommentDto[] = [];

  currentPage = defaultPaginationParams.page;
  pageSize = defaultPaginationParams.pageSize;
  hasNextPage = false;
  isLoading = false;

  ngOnInit(): void {
    this.route.params.subscribe(params => {
      this.publicationId = params['id'];
      this.resetAndLoadInitialComments();
    });
  }

  resetAndLoadInitialComments(): void {
    this.comments = [];
    this.currentPage = defaultPaginationParams.page;
    this.hasNextPage = false;
    this.loadComments();
  }

  loadComments(): void {
    if (!this.publicationId || this.isLoading) return;

    this.isLoading = true;

    const paginationParams: PaginationParams = {
      page: this.currentPage,
      pageSize: this.pageSize
    };

    this.commentListService.getCommentsByPublicationId(this.publicationId, paginationParams).subscribe({
      next: (data: PagedList<CommentDto>) => {
        this.comments = [...this.comments, ...data.items];
        this.hasNextPage = data.hasNextPage;
        this.isLoading = false;
      },
      error: (err) => {
        console.error('Failed to load comments pagination page:', err);
        this.isLoading = false;
      }
    });
  }

  loadNextPage(): void {
    if (this.hasNextPage && !this.isLoading) {
      this.currentPage++;
      this.loadComments();
    }
  }

  @HostListener('window:scroll', [])
  onWindowScroll(): void {
    const scrollHeight = document.documentElement.scrollHeight;

    const scrollPos = window.innerHeight + (document.documentElement.scrollTop || document.body.scrollTop);

    if (scrollPos >= scrollHeight - 200) {
      this.loadNextPage();
    }
  }
}
