import {inject, Injectable} from '@angular/core';
import {HttpClient, HttpParams} from "@angular/common/http";
import {environment} from "../../../../../environments/environment";
import { CommentDto } from "../../comment-card-view/models/comment.dto";
import {PagedList, PaginationParams} from "../../../../shared/models/pagedlist.dto";

@Injectable({
  providedIn: 'root'
})
export class CommentListService {
  private http = inject(HttpClient);
  baseUrl = environment.apiUrl;

  getCommentsByPublicationId(publicationId: string, paginationParams: PaginationParams ) {
    const params = new HttpParams()
      .set('page', paginationParams.page)
      .set('pageSize', paginationParams.pageSize);
    return this.http.get<PagedList<CommentDto>>(`${this.baseUrl}/comment/${publicationId}`, {params: params});
  }
  constructor() { }
}
