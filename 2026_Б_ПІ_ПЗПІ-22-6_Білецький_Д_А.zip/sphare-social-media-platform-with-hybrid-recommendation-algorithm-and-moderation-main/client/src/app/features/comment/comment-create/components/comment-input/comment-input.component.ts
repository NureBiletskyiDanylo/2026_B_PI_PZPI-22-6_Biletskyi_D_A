import {Component, forwardRef, input, output, signal} from '@angular/core';
import {ControlValueAccessor, NG_VALUE_ACCESSOR} from "@angular/forms";

@Component({
  selector: 'app-comment-input',
  imports: [],
  templateUrl: './comment-input.component.html',
  styleUrl: './comment-input.component.css',
  providers: [
    {
      provide: NG_VALUE_ACCESSOR,
      useExisting: forwardRef(() => CommentInputComponent),
      multi: true
    }
  ]
})
export class CommentInputComponent implements ControlValueAccessor {
  label = input<string>('Write a comment...');
  id = input<string>('comment-input-' + Math.random().toString(36).substring(2, 9));
  labelBgColor = input<string>('#FFFAFA');

  value = signal<string>('');
  disabled = signal<boolean>(false);

  valueChange = output<string>();

  onChange: any = () => {};
  onTouched: any = () => {};

  onInput(event: Event): void {
    const textarea = event.target as HTMLTextAreaElement;
    const val = textarea.value;

    this.value.set(val);
    this.onChange(val);
    this.valueChange.emit(val);

    this.adjustHeight(textarea);
  }

  private adjustHeight(textarea: HTMLTextAreaElement): void {
    textarea.style.height = 'auto';
    const newHeight = Math.min(textarea.scrollHeight, 300); // matches max-height
    textarea.style.height = `${newHeight}px`;
    textarea.style.overflowY = textarea.scrollHeight > 300 ? 'auto' : 'hidden';
  }

  writeValue(val: any): void {
    this.value.set(val || '');

    setTimeout(() => {
      const element = document.getElementById(this.id()) as HTMLTextAreaElement;
      if (element) {
        this.adjustHeight(element);
      }
    }, 0);
  }

  registerOnChange(fn: any): void {
    this.onChange = fn;
  }

  registerOnTouched(fn: any): void {
    this.onTouched = fn;
  }

  setDisabledState(isDisabled: boolean): void {
    this.disabled.set(isDisabled);
  }


}
