import {Component, inject, input, output} from '@angular/core';
import {FormControl, ReactiveFormsModule} from "@angular/forms";
import {CommentInputComponent} from "./comment-input/comment-input.component";
import {CommentActionCreateComponent} from "./comment-action-create/comment-action-create.component";
import {CreateCommentDto} from "../models/comment-create.dto";
import {CommentCreateService} from "../services/comment-create.service";

@Component({
  selector: 'app-comment-create',
  imports: [
    CommentInputComponent,
    CommentActionCreateComponent,
    ReactiveFormsModule
  ],
  templateUrl: './comment-create.component.html',
  styleUrl: './comment-create.component.css'
})
export class CommentCreateComponent {
  private commentCreateService = inject(CommentCreateService);

  publicationId = input.required<string>();
  parentCommentId = input<string | null>(null);

  commentCreated = output<void>();

  commentControl = new FormControl('', { nonNullable: true });

  get isSubmitDisabled(): boolean {
    return !this.commentControl.value || this.commentControl.value.trim().length === 0;
  }

  onSubmitComment(): void {
    const textToSend = this.commentControl.value.trim();

    if (!textToSend) {
      return;
    }

    const dto: CreateCommentDto = {
      content: textToSend,
      publicationId: this.publicationId(),
      parentCommentId: this.parentCommentId()
    };

    this.commentCreateService.createComment(dto).subscribe({
      next: () => {
        this.commentControl.reset();
        this.commentCreated.emit();
      },
      error: err => {
        console.log(err);
      }
    });
  }
}
