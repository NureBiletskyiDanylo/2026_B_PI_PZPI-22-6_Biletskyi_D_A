export interface CreateCommentDto {
  content: string;
  publicationId: string;
  parentCommentId?: string | null;
}
