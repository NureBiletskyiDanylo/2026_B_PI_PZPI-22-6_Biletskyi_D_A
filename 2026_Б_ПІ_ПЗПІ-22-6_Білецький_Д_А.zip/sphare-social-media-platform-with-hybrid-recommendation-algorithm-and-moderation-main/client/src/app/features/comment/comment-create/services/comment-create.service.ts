import {inject, Injectable} from '@angular/core';
import {HttpClient} from "@angular/common/http";
import {environment} from "../../../../../environments/environment";
import {CreateCommentDto} from "../models/comment-create.dto";
import {Observable} from "rxjs";

@Injectable({
  providedIn: 'root'
})
export class CommentCreateService {
  private http = inject(HttpClient);
  baseUrl = environment.apiUrl;

  createComment(commentModel: CreateCommentDto): Observable<void> {
    return this.http.post<void>(`${this.baseUrl}/comment`, commentModel);
  }
  constructor() { }
}
