import {Component, input, output} from '@angular/core';

@Component({
  selector: 'app-comment-action-create',
  imports: [],
  templateUrl: './comment-action-create.component.html',
  styleUrl: './comment-action-create.component.css'
})
export class CommentActionCreateComponent {
  create = output<void>();

  disabled = input<boolean>(false);
}
