import {Component, inject, input, output, viewChild} from '@angular/core';
import {CommentDto} from "../models/comment.dto";
import {IdentityComponent} from "../../../user/user-profile/components/identity/identity.component";
import {
  UserIdentityComponent
} from "../../../publication/publication-card-view/components/user-identity/user-identity.component";
import {CommentDateComponent} from "./comment-date/comment-date.component";
import {CommentContentComponent} from "./comment-content/comment-content.component";
import {CommentActivityComponent} from "./comment-activity/comment-activity.component";
import {Router} from "@angular/router";
import {CommentDeleteComponent} from "../../comment-delete/components/comment-delete.component";
import {
  CreateComplaintComponent
} from "../../../complaint/create-complaint/components/create-complaint/create-complaint.component";

@Component({
  selector: 'app-comment-card',
  imports: [
    IdentityComponent,
    UserIdentityComponent,
    CommentDateComponent,
    CommentContentComponent,
    CommentActivityComponent,
    CommentDeleteComponent,
    CreateComplaintComponent
  ],
  templateUrl: './comment-card.component.html',
  styleUrl: './comment-card.component.css'
})
export class CommentCardComponent {
  private router: Router = inject(Router);
  commentDto = input<CommentDto>();
  commentDeleted = output<void>();

  deleteModal = viewChild<CommentDeleteComponent>('deleteModal');
  complaintModal = viewChild<CreateComplaintComponent>('complaintModal');

  onViewReplies(id: string): void {
    this.router.navigate(['/comment', id]);
  }

  onWriteReply(id: string): void {
    this.router.navigate(['/comment', id], { queryParams: { focus: 'true' } });
  }

  onDelete(): void {
    this.deleteModal()?.open();
  }

  onCommentDeleted(): void {
    this.commentDeleted.emit();
  }

  onReport(): void {
    this.complaintModal()?.openModal();
  }
}
