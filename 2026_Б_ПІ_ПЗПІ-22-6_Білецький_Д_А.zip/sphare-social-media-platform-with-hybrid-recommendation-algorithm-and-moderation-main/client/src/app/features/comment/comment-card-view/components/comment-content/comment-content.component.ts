import {Component, input} from '@angular/core';

@Component({
  selector: 'app-comment-content',
  imports: [],
  templateUrl: './comment-content.component.html',
  styleUrl: './comment-content.component.css'
})
export class CommentContentComponent {
  content = input<string>();
  isDeleted = input<boolean>();
}
