import {Component, input} from '@angular/core';
import {DatePipe} from "@angular/common";

@Component({
  selector: 'app-comment-date',
  imports: [
    DatePipe
  ],
  templateUrl: './comment-date.component.html',
  styleUrl: './comment-date.component.css'
})
export class CommentDateComponent {
  createdAt = input<string | Date | null>(null);
}
