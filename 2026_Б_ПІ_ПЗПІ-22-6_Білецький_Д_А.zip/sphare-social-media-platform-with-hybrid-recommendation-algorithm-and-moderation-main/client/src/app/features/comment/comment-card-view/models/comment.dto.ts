import {PublicUserBriefDto} from "../../../publication/publication-card-view/models/publication.dto";

export interface CommentDto {
  id: string;
  content: string;
  author: PublicUserBriefDto;
  publicationId: string;
  creationDate: Date;
  isDeleted: boolean;
  repliesAmount: number;
  isOwner: boolean;
}
