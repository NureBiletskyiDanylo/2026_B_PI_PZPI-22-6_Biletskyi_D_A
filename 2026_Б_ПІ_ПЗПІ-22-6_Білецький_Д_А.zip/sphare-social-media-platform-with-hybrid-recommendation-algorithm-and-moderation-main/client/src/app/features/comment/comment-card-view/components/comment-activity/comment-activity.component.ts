import {Component, EventEmitter, Input, Output} from '@angular/core';

@Component({
  selector: 'app-comment-activity',
  imports: [],
  templateUrl: './comment-activity.component.html',
  styleUrl: './comment-activity.component.css'
})
export class CommentActivityComponent {
  @Input() commentId: string = '';

  @Input() isDeleted: boolean = false;
  @Input() isOwner: boolean = false;
  @Input() replyAmount: number = 0;

  @Output() report = new EventEmitter<void>();
  @Output() delete = new EventEmitter<void>();

  @Output() viewReplies = new EventEmitter<string>();
  @Output() writeReply = new EventEmitter<string>();
}
