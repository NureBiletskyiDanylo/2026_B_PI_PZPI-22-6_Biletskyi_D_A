import {Component, effect, HostListener, inject, input, OnInit} from '@angular/core';
import {CommentPageService} from "../../services/comment-page.service";
import {CommentDto} from "../../../comment-card-view/models/comment.dto";
import {defaultPaginationParams, PagedList, PaginationParams} from "../../../../../shared/models/pagedlist.dto";
import {CommentCardComponent} from "../../../comment-card-view/components/comment-card.component";

@Component({
  selector: 'app-replies-list',
  imports: [
    CommentCardComponent
  ],
  templateUrl: './replies-list.component.html',
  styleUrl: './replies-list.component.css'
})
export class RepliesListComponent {
  private commentPageService = inject(CommentPageService);

  parentCommentId = input<string>();
  comments: CommentDto[] = [];

  currentPage = defaultPaginationParams.page;
  pageSize = defaultPaginationParams.pageSize;
  hasNextPage = false;
  isLoading = false;

  constructor() {
    effect(() => {
      const id = this.parentCommentId();
      if (id) {
        this.resetAndLoadInitialReplies(id);
      }
    });
  }

  resetAndLoadInitialReplies(id: string): void {
    this.comments = [];
    this.currentPage = defaultPaginationParams.page;
    this.hasNextPage = false;
    this.loadReplies(id);
  }

  loadReplies(id: string): void {
    if (this.isLoading) return;

    this.isLoading = true;

    const paginationParams: PaginationParams = {
      page: this.currentPage,
      pageSize: this.pageSize
    };

    this.commentPageService.getRepliesByCommentId(id, paginationParams).subscribe({
      next: (data: PagedList<CommentDto>) => {
        this.comments = [...this.comments, ...data.items];
        this.hasNextPage = data.hasNextPage;
        this.isLoading = false;
      },
      error: (err) => {
        console.error('Failed to load replies batch:', err);
        this.isLoading = false;
      }
    });
  }

  loadNextPage(): void {
    const id = this.parentCommentId();
    if (id && this.hasNextPage && !this.isLoading) {
      this.currentPage++;
      this.loadReplies(id);
    }
  }

  @HostListener('window:scroll', [])
  onWindowScroll(): void {
    const scrollHeight = document.documentElement.scrollHeight;
    const scrollPos = window.innerHeight + (document.documentElement.scrollTop || document.body.scrollTop);

    if (scrollPos >= scrollHeight - 200) {
      this.loadNextPage();
    }
  }
}
