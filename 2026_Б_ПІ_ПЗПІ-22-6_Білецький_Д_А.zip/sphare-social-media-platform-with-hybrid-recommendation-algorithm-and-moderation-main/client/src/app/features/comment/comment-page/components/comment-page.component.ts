import {Component, ElementRef, inject, OnInit, viewChild} from '@angular/core';
import {CommentDto} from "../../comment-card-view/models/comment.dto";
import {
  UserIdentityComponent
} from "../../../publication/publication-card-view/components/user-identity/user-identity.component";
import {CommentDateComponent} from "../../comment-card-view/components/comment-date/comment-date.component";
import {CommentContentComponent} from "../../comment-card-view/components/comment-content/comment-content.component";
import {CommentActivityComponent} from "../../comment-card-view/components/comment-activity/comment-activity.component";
import {ActivatedRoute} from "@angular/router";
import {CommentPageService} from "../services/comment-page.service";
import {RepliesListComponent} from "./replies-list/replies-list.component";
import {CommentCreateComponent} from "../../comment-create/components/comment-create.component";
import {CommentDeleteComponent} from "../../comment-delete/components/comment-delete.component";

@Component({
  selector: 'app-comment-page',
  imports: [
    UserIdentityComponent,
    CommentDateComponent,
    CommentContentComponent,
    CommentActivityComponent,
    CommentCreateComponent,
    RepliesListComponent,
    CommentDeleteComponent
  ],
  templateUrl: './comment-page.component.html',
  styleUrl: './comment-page.component.css'
})
export class CommentPageComponent implements OnInit {
  private route = inject(ActivatedRoute);
  private commentPageService = inject(CommentPageService);

  private parentCommentId: string | null = null;
  comment: CommentDto | null = null;

  // View template tracking identifiers
  replyContainer = viewChild<ElementRef<HTMLElement>>('replyContainer');
  repliesList = viewChild(RepliesListComponent);
  deleteModal = viewChild<CommentDeleteComponent>('deleteModal');

  ngOnInit() {
    this.route.params.subscribe(params => {
      this.parentCommentId = params['id'];
      this.loadComment();
    });
  }

  loadComment() {
    if (this.parentCommentId) {
      this.commentPageService.getCommentById(this.parentCommentId).subscribe({
        next: (comment: CommentDto) => {
          this.comment = comment;
          this.checkFocusQueryParam();
        },
        error: error => { console.error(error); }
      });
    }
  }

  private checkFocusQueryParam(): void {
    this.route.queryParams.subscribe(queryParams => {
      if (queryParams['focus'] === 'true') {
        this.scrollToAndFocusReply();
      }
    });
  }

  protected scrollToAndFocusReply(): void {
    setTimeout(() => {
      const container = this.replyContainer()?.nativeElement;
      if (container) {
        container.scrollIntoView({ behavior: 'smooth', block: 'center' });

        const textarea = container.querySelector('textarea');
        textarea?.focus();
      }
    }, 150);
  }

  protected onReplyCreated(): void {
    if (this.comment) {
      this.comment.repliesAmount++;
    }
    const listInstance = this.repliesList() as any;
    if (listInstance && typeof listInstance.resetAndLoadInitialReplies === 'function') {
      listInstance.resetAndLoadInitialReplies(this.comment?.id);
    }
  }

  protected onDeleteRequested(): void {
    this.deleteModal()?.open();
  }

  protected onCommentDeleted(): void {
    this.loadComment();
  }
}
