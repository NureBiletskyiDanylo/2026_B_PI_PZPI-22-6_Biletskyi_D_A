import {Component, HostListener, inject, input, output} from '@angular/core';
import {CommentDeleteService} from "../services/comment-delete.service";

@Component({
  selector: 'app-comment-delete',
  imports: [],
  templateUrl: './comment-delete.component.html',
  styleUrl: './comment-delete.component.css'
})
export class CommentDeleteComponent {
  private commentDeleteService = inject(CommentDeleteService);

  // Modern Signal Architecture Properties
  commentId = input<string>();
  commentDeleted = output<void>();

  isOpen = false;
  isLoading = false;

  open(): void {
    this.isOpen = true;
  }

  close(): void {
    this.isOpen = false;
  }

  @HostListener('document:keydown.escape')
  onEscape(): void {
    if (this.isOpen) this.close();
  }

  confirmDelete(): void {
    const id = this.commentId();
    if (!id) return;

    this.isLoading = true;
    this.commentDeleteService.deleteComment(id).subscribe({
      next: () => {
        this.isLoading = false;
        this.commentDeleted.emit();
        this.close();
      },
      error: (err) => {
        console.error('Failed to delete comment:', err);
        this.isLoading = false;
      }
    });
  }
}
