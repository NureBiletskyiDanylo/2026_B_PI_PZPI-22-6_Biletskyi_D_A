import {inject, Injectable} from '@angular/core';
import {HttpClient} from "@angular/common/http";
import {environment} from "../../../../../environments/environment";

@Injectable({
  providedIn: 'root'
})
export class CommentDeleteService {
  private http = inject(HttpClient);
  baseUrl = environment.apiUrl;

  deleteComment(id: string) {
    return this.http.delete(`${this.baseUrl}/comment/${id}`, {})
  }
  constructor() { }
}
