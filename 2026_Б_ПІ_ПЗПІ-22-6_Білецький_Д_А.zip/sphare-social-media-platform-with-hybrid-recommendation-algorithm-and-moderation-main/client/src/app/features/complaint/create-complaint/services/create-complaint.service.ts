import {inject, Injectable} from '@angular/core';
import {HttpClient} from "@angular/common/http";
import {environment} from "../../../../../environments/environment";
import {CreateComplaintDto} from "../models/create-complaint.dto";

@Injectable({
  providedIn: 'root'
})
export class CreateComplaintService {
  private http = inject(HttpClient)
  private baseUrl = environment.apiUrl

  makePublicationComplaint(complaint: CreateComplaintDto) {
    return this.http.post<boolean>(`${this.baseUrl}/complaint/publication`, complaint);
  }

  makeCommentComplaint(complaint: CreateComplaintDto) {
    return this.http.post<boolean>(`${this.baseUrl}/complaint/comment`, complaint);
  }
  constructor() { }
}
