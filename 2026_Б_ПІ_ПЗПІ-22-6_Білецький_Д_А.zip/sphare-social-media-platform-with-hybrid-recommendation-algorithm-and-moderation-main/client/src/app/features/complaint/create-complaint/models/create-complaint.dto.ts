export interface CreateComplaintDto {
    reason: string,
    explanation?: string,
    targetId: number
}
