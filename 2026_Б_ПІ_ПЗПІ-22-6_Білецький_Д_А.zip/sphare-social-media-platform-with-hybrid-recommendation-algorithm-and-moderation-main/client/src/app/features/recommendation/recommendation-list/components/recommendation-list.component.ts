import {AfterViewInit, Component, ElementRef, inject, OnDestroy, OnInit, ViewChild} from '@angular/core';
import {defaultPaginationParams, PagedList, PaginationParams} from "../../../../shared/models/pagedlist.dto";
import {PublicationCardDto} from "../../../publication/publication-card-view/models/publication.dto";
import {RecommendationService} from "../services/recommendation.service";
import {
  PublicationCardComponent
} from "../../../publication/publication-card-view/components/publication-card.component";
import {NgForOf, NgIf} from "@angular/common";

@Component({
  selector: 'app-recommendation-list',
  imports: [
    PublicationCardComponent,
    NgForOf,
    NgIf
  ],
  templateUrl: './recommendation-list.component.html',
  styleUrl: './recommendation-list.component.css'
})
export class RecommendationListComponent implements OnInit, AfterViewInit, OnDestroy {
  private recommendationService: RecommendationService = inject(RecommendationService);

  @ViewChild('scrollAnchor') scrollAnchor!: ElementRef<HTMLElement>;
  private observer?: IntersectionObserver;

  publicationList: PagedList<PublicationCardDto> | null = null;
  isLoading = false;
  hasMore = true;
  private currentParams: PaginationParams = {...defaultPaginationParams};

  loadPublications(params: PaginationParams = this.currentParams, append = false) {
    if (this.isLoading) return;

    this.isLoading = true;
    this.recommendationService.getRecommendations(params).subscribe({
      next: data => {
        this.currentParams = params;

        if (append && this.publicationList) {
          this.publicationList = {
            ...data,
            items: [...this.publicationList.items, ...data.items]
          };
        } else {
          this.publicationList = data;
        }

        this.hasMore = data.items.length === params.pageSize;
        this.isLoading = false;
      },
      error: err => {
        console.log(err);
        this.isLoading = false;
      }
    });
  }

  loadMore(): void {
    if (!this.hasMore || this.isLoading) return;
    this.loadPublications({...this.currentParams, page: this.currentParams.page + 1}, true);
  }

  ngOnInit() {
    this.loadPublications();
  }

  ngAfterViewInit() {
    this.observer = new IntersectionObserver(entries => {
      if (entries[0].isIntersecting) {
        this.loadMore();
      }
    }, {rootMargin: '200px'});

    this.observer.observe(this.scrollAnchor.nativeElement);
  }

  ngOnDestroy() {
    this.observer?.disconnect();
  }

  handlePublicationChanged(wasUpdated: boolean): void {
    if (wasUpdated) {
      this.currentParams = {...defaultPaginationParams};
      this.hasMore = true;
      this.loadPublications(this.currentParams, false);
    }
  }
}
