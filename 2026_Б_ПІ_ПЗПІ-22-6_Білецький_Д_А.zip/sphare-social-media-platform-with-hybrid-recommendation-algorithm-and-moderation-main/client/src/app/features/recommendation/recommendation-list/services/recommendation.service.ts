import {inject, Injectable} from '@angular/core';
import {HttpClient, HttpParams} from "@angular/common/http";
import {environment} from "../../../../../environments/environment";
import {PagedList, PaginationParams} from "../../../../shared/models/pagedlist.dto";
import {PublicationCardDto} from "../../../publication/publication-card-view/models/publication.dto";

@Injectable({
  providedIn: 'root'
})
export class RecommendationService {
  private http = inject(HttpClient);
  baseUrl = environment.apiUrl;

  getRecommendations(paginationParams: PaginationParams) {
    const params = new HttpParams()
      .set('page', paginationParams.page)
      .set('pageSize', paginationParams.pageSize);

    return this.http.get<PagedList<PublicationCardDto>>(this.baseUrl + '/recommendation', {params: params})
  }
  constructor() { }
}
