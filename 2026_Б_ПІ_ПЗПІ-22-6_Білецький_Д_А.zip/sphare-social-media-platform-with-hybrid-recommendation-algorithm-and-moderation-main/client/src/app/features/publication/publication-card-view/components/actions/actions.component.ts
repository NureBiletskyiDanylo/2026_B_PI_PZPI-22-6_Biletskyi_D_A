import {Component, EventEmitter, Input, Output} from '@angular/core';

@Component({
  selector: 'app-actions',
  imports: [],
  templateUrl: './actions.component.html',
  styleUrl: './actions.component.css'
})
export class ActionsComponent {
  @Input() isLikedByUser: boolean = false;
  @Input() isDeleted: boolean = false;
  @Input() isOwner: boolean = false;
  @Input() likesAmount: number = 0;
  @Input() commentAmount: number = 0;
  @Input() viewCount: number = 0;

  @Output() like = new EventEmitter<void>();
  @Output() comment = new EventEmitter<void>();
  @Output() share = new EventEmitter<void>();
  @Output() report = new EventEmitter<void>();
  @Output() edit = new EventEmitter<void>();
  @Output() delete = new EventEmitter<void>();

  onLike(event: MouseEvent): void {
    event.stopPropagation();
    this.like.emit();
  }

  onComment(event: MouseEvent): void {
    event.stopPropagation();
    this.comment.emit();
  }

  onShare(event: MouseEvent): void {
    event.stopPropagation();
    this.share.emit();
  }

  onReport(event: MouseEvent): void {
    event.stopPropagation();
    this.report.emit();
  }

  onEdit(event: MouseEvent): void {
    event.stopPropagation();
    this.edit.emit();
  }

  onDelete(event: MouseEvent): void {
    event.stopPropagation();
    this.delete.emit();
  }
}
