import {Component, Input, OnDestroy} from '@angular/core';
import {ImageModalComponent} from "../../../../../shared/components/image-modal/image-modal.component";

@Component({
  selector: 'app-image-content',
  imports: [
    ImageModalComponent
  ],
  templateUrl: './image-content.component.html',
  styleUrl: './image-content.component.css'
})
export class ImageContentComponent implements OnDestroy {
  @Input() imagesUrl: string[] | null = null;

  isModalOpen = false;
  selectedImageIndex = 0;

  openModal(index: number, event: MouseEvent) {
    event.stopPropagation();
    this.selectedImageIndex = index;
    this.isModalOpen = true;
    document.body.style.overflow = 'hidden';
  }

  closeModal() {
    this.isModalOpen = false;
    document.body.style.overflow = '';
  }

  ngOnDestroy(): void {
    if (this.isModalOpen) {
      document.body.style.overflow = '';
    }
  }
}
