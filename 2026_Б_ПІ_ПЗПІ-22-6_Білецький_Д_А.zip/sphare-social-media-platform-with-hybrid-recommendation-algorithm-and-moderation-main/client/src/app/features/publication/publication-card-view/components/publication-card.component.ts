import {AfterViewInit, Component, inject, input, Input, OnDestroy, ElementRef, output, viewChild} from '@angular/core';
import {PublicationCardDto} from "../models/publication.dto";
import {UserIdentityComponent} from "./user-identity/user-identity.component";
import {DateContentComponent} from "./date-content/date-content.component";
import {TextContentComponent} from "./text-content/text-content.component";
import {ImageContentComponent} from "./image-content/image-content.component";
import {ActionsComponent} from "./actions/actions.component";
import {LikeService} from "../../../../shared/services/like.service";
import {PublicationEditComponent} from "../../publication-edit/components/publication-edit.component";
import {PublicationDeleteComponent} from "../../publication-delete/components/publication-delete.component";
import {Router} from "@angular/router";
import {
  CreateComplaintComponent
} from "../../../complaint/create-complaint/components/create-complaint/create-complaint.component";
import {PublicationViewService} from "../services/publication-view.service";

@Component({
  selector: 'app-publication-card',
  imports: [
    UserIdentityComponent,
    DateContentComponent,
    TextContentComponent,
    ImageContentComponent,
    ActionsComponent,
    PublicationEditComponent,
    PublicationDeleteComponent,
    CreateComplaintComponent
  ],
  templateUrl: './publication-card.component.html',
  styleUrl: './publication-card.component.css'
})
export class PublicationCardComponent implements AfterViewInit, OnDestroy {
  ngOnDestroy(): void {
    this.observer?.disconnect();
    if (this.viewTimeout) clearTimeout(this.viewTimeout);
  }
  ngAfterViewInit(): void {
    this.observer = new IntersectionObserver(
      (entries) => this.handleIntersection(entries),
      { threshold: 0.5 }
    );
    this.observer.observe(this.elementRef.nativeElement);
  }
  @Input() publicationDto: PublicationCardDto | null = null;
  profanityFilter = input<boolean>(true);
  private likeService: LikeService = inject(LikeService);
  private viewService: PublicationViewService = inject(PublicationViewService);
  private router: Router = inject(Router);
  private elementRef: ElementRef<HTMLElement> = inject(ElementRef);
  private observer?: IntersectionObserver;
  private viewTimeout?: ReturnType<typeof setTimeout>;
  private viewSent = false;

  publicationChanged = output<boolean>();
  editModal = viewChild<PublicationEditComponent>('editModal');
  deleteModal = viewChild<PublicationDeleteComponent>('deleteModal');
  complaintModal = viewChild<CreateComplaintComponent>('complaintModal');

  onCardClick(event: MouseEvent): void {
    if (window.getSelection()?.toString()) {
      return;
    }

    const target = event.target as HTMLElement;

    if (target.closest('button, a, input, textarea, select, [data-stop-card-nav]')) {
      return;
    }

    const id = this.publicationDto?.id;
    if (id) {
      this.router.navigate(['/publication', id]);
    }
  }

  onLike() {
    const publication = this.publicationDto;

    if (publication) {
      this.likeService.likePublication(publication.id).subscribe({
        next: (data) => {
          publication.likesAmount = data.amountOfLikes;
          publication.isLikedByCurrentUser = data.isLikedByCurrentUser;
        },
        error: (err) => {
          console.error('Failed to like publication:', err);
        }
      });
    }
  }
  onComment() {}
  onShare() {}
  onReport() {
    this.complaintModal()?.openModal();
  }
  onEdit() {
    this.editModal()?.open();
  }
  onDelete() {
    this.deleteModal()?.open();
  }

  onEditClosed(wasUpdated: boolean): void {
    if (wasUpdated) {
      this.publicationChanged.emit(wasUpdated);
    }
  }

  onPublicationDeleted(): void {
    this.publicationChanged.emit(true);
  }

  private handleIntersection(entries: IntersectionObserverEntry[]): void {
    const entry = entries[0];

    if (entry.isIntersecting) {
      if (!this.viewSent && !this.viewTimeout) {
        this.viewTimeout = setTimeout(() => this.sendView(), 1000);
      }
    } else if (this.viewTimeout) {
      clearTimeout(this.viewTimeout);
      this.viewTimeout = undefined;
    }
  }

  private sendView(): void {
    const id = this.publicationDto?.id;
    if (!id || this.viewSent) return;

    this.viewSent = true;
    this.viewService.addView(id).subscribe({
      error: (err) => console.error('Failed to register view:', err)
    });
  }
}
