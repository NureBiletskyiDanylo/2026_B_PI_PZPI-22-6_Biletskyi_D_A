import {inject, Injectable} from '@angular/core';
import {HttpClient} from "@angular/common/http";
import {environment} from "../../../../../environments/environment";

@Injectable({
  providedIn: 'root'
})
export class PublicationViewService {
  private http = inject(HttpClient);
  baseUrl = environment.apiUrl;

  addView(publicationId: string) {
    return this.http.get(this.baseUrl + `/publication/publication/view-update/${publicationId}`);
  }
  constructor() { }
}
