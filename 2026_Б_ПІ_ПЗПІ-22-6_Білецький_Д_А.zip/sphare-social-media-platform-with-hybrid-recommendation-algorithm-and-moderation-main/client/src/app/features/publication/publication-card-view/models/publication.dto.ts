import {FlaggedSpan} from "../../../../shared/models/publication.dto";

export interface PublicUserBriefDto {
  id: string;
  username: string;
  uniqueNameIdentifier: string;
  imageUrl: string | null;
  blocked: boolean;
}

export type PublicationTypes = 'ordinary' | 'planned' | 'conditional';

export interface PublicationCardDto {
  id: string;
  content: string | null;
  postedAt: string;
  updatedAt: string | null;
  imageUrls: string[];
  author: PublicUserBriefDto;
  likesAmount: number;
  isLikedByCurrentUser: boolean;
  commentAmount: number;
  publicationType: PublicationTypes;
  viewCount: number;
  isDeleted: boolean;
  isOwner: boolean;
  publishAt: string;
  flaggedSpans: FlaggedSpan[];
}
