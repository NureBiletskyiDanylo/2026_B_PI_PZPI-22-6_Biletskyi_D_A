import {Component, Input} from '@angular/core';
import {DatePipe} from "@angular/common";

@Component({
  selector: 'app-date-content',
  imports: [
    DatePipe
  ],
  templateUrl: './date-content.component.html',
  styleUrl: './date-content.component.css'
})
export class DateContentComponent {
  @Input() postedAt: string | null = null;
  @Input() updatedAt: string | null = null;
  @Input() toBePostedAt: string | null = null;
}
