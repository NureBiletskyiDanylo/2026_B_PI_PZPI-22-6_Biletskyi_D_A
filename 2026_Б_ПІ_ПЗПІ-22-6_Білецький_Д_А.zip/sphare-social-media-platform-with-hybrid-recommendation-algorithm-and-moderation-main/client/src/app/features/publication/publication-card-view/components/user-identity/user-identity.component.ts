import {Component, inject, Input} from '@angular/core';
import {PublicUserBriefDto} from "../../models/publication.dto";
import {Router} from "@angular/router";

@Component({
  selector: 'app-user-identity',
  imports: [],
  templateUrl: './user-identity.component.html',
  styleUrl: './user-identity.component.css'
})
export class UserIdentityComponent {
  @Input() userDto: PublicUserBriefDto | null = null;
  private router: Router = inject(Router)

  protected goToProfile($event: MouseEvent): void {
    $event.preventDefault();

    const identifier = this.userDto?.uniqueNameIdentifier;
    if (identifier) {
      this.router.navigate(['/profile', identifier]);
    }
  }
}
