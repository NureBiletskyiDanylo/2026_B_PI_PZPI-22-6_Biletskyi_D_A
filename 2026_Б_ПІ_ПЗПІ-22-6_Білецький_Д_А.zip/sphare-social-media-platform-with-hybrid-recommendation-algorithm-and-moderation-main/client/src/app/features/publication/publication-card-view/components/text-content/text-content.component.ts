import {Component, Input, SimpleChanges} from '@angular/core';
import {FlaggedSpan} from "../../../../../shared/models/publication.dto";
interface TextSegment {
  content: string;
  isFlagged: boolean;
  revealed: boolean;
}
@Component({
  selector: 'app-text-content',
  imports: [],
  templateUrl: './text-content.component.html',
  styleUrl: './text-content.component.css'
})
export class TextContentComponent {
  @Input() text: string | null = null;
  @Input() flaggedSpans: FlaggedSpan[] = [];
  @Input() profanitySafety = true;

  segments: TextSegment[] = [];

  ngOnChanges(changes: SimpleChanges): void {
    if (changes['text'] || changes['flaggedSpans']) {
      this.segments = this.buildSegments();
    }
  }

  toggleReveal(segment: TextSegment, event: MouseEvent): void {
    event.stopPropagation(); // Prevents the parent component from receiving the click
    segment.revealed = !segment.revealed;
  }

  private buildSegments(): TextSegment[] {
    if (!this.text) return [];

    const spans = [...this.flaggedSpans].sort((a, b) => a.start - b.start);
    const segments: TextSegment[] = [];
    let cursor = 0;

    for (const span of spans) {
      if (span.start < cursor || span.start >= span.end || span.end > this.text.length) {
        continue;
      }
      if (span.start > cursor) {
        segments.push({ content: this.text.slice(cursor, span.start), isFlagged: false, revealed: false });
      }
      segments.push({ content: this.text.slice(span.start, span.end), isFlagged: true, revealed: false });
      cursor = span.end;
    }

    if (cursor < this.text.length) {
      segments.push({ content: this.text.slice(cursor), isFlagged: false, revealed: false });
    }

    return segments;
  }
}
