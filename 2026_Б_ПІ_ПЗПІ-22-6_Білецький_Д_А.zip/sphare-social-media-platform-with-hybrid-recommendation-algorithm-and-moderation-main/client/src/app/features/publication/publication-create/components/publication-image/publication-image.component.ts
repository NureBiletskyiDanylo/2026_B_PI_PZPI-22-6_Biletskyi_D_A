import {Component, ElementRef, forwardRef, ViewChild} from '@angular/core';
import {NG_VALUE_ACCESSOR} from "@angular/forms";
import {ImageEditComponent} from "../../../../../image/image-edit/image-edit.component";
import {ImageItem} from "../../models/create-publication.dto";

@Component({
  selector: 'app-publication-image',
  imports: [
    ImageEditComponent
  ],
  templateUrl: './publication-image.component.html',
  styleUrl: './publication-image.component.css',
  providers: [{
    provide: NG_VALUE_ACCESSOR,
    useExisting: forwardRef(() => PublicationImageComponent),
    multi: true
  }]
})
export class PublicationImageComponent {
  images: ImageItem[] = [];

  private pendingQueue: File[] = [];
  pendingFile: File | undefined;

  readonly MAX_IMAGES = 4;

  private onChange: (value: File[] | null) => void = () => {};
  private onTouched: () => void = () => {};

  @ViewChild('fileInput') fileInput!: ElementRef<HTMLInputElement>;

  get canAddMore(): boolean {
    return this.images.length < this.MAX_IMAGES;
  }

  triggerFileInput(): void {
    if (!this.canAddMore) return;
    this.fileInput.nativeElement.click();
  }

  onFileSelected(event: Event): void {
    const files = (event.target as HTMLInputElement).files;
    if (!files) return;

    const remaining = this.MAX_IMAGES - this.images.length;
    const selected = Array.from(files).slice(0, remaining);

    this.pendingQueue.push(...selected);
    this.processNextPending();

    (event.target as HTMLInputElement).value = '';
  }

  onCropApplied(result: { croppedFile: File; preview: string }): void {
    this.images.push({
      file: this.pendingFile!,
      preview: result.preview,
      croppedFile: result.croppedFile
    });
    this.pendingFile = undefined;

    this.emitValue();

    this.processNextPending();
  }

  onCropCancelled(): void {
    this.pendingFile = undefined;
    this.processNextPending();
  }

  removeImage(index: number): void {
    this.images.splice(index, 1);
    this.emitValue();
  }

  private processNextPending(): void {
    if (this.pendingFile) return;
    if (this.pendingQueue.length === 0) return;
    if (!this.canAddMore) {
      this.pendingQueue = [];
      return;
    }
    this.pendingFile = this.pendingQueue.shift();
  }

  private emitValue(): void {
    const files = this.images
      .map(item => item.croppedFile)
      .filter((f): f is File => f !== undefined);
    this.onChange(files.length > 0 ? files : null);
    this.onTouched();
  }

  writeValue(val: File[] | null): void {
    if (!val || val.length === 0) {
      this.images = [];
      this.pendingQueue = [];
      this.pendingFile = undefined;
    } else {
    }
  }

  registerOnChange(fn: any): void { this.onChange = fn; }
  registerOnTouched(fn: any): void { this.onTouched = fn; }
}
