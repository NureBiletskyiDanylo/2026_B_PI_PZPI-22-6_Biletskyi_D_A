import {Component, forwardRef, OnInit, signal} from '@angular/core';
import {ControlValueAccessor, NG_VALUE_ACCESSOR} from "@angular/forms";

@Component({
  selector: 'app-publication-planned-input',
  imports: [],
  templateUrl: './publication-planned-input.component.html',
  styleUrl: './publication-planned-input.component.css',
  providers: [
    {
      provide: NG_VALUE_ACCESSOR,
      useExisting: forwardRef(() => PublicationPlannedInputComponent),
      multi: true
    }
  ]
})
export class PublicationPlannedInputComponent implements ControlValueAccessor, OnInit {
  minDateTimeString = signal<string>('');
  disabled = signal<boolean>(false);
  value = signal<string>('');

  onChange: any = () => {};
  onTouched: any = () => {};

  ngOnInit(): void {
    this.minDateTimeString.set(this.getMinDateTime());
  }

  private getMinDateTime(): string {
    const min = new Date(Date.now() + 60 * 60 * 1000); // now + 1 hour
    return this.toLocalDateTimeString(min);
  }

  private toLocalDateTimeString(date: Date): string {
    const yyyy = date.getFullYear();
    const MM = String(date.getMonth() + 1).padStart(2, '0');
    const dd = String(date.getDate()).padStart(2, '0');
    const hh = String(date.getHours()).padStart(2, '0');
    const mm = String(date.getMinutes()).padStart(2, '0');
    return `${yyyy}-${MM}-${dd}T${hh}:${mm}`;
  }

  onDateTimeChange(event: Event): void {
    const raw = (event.target as HTMLInputElement).value;
    const selected = new Date(raw);
    const minTime = new Date(Date.now() + 60 * 60 * 1000);

    const resolved = selected < minTime ? minTime : selected;
    const resolvedStr = this.toLocalDateTimeString(resolved);

    this.value.set(resolvedStr);
    this.onChange(resolved); // emit as Date object
    this.onTouched();

    if (resolved !== selected) {
      (event.target as HTMLInputElement).value = resolvedStr;
    }
  }

  writeValue(val: Date | string | null): void {
    if (!val) {
      this.value.set('');
      return;
    }
    const date = typeof val === 'string' ? new Date(val) : val;
    this.value.set(this.toLocalDateTimeString(date));
  }

  registerOnChange(fn: any): void { this.onChange = fn; }
  registerOnTouched(fn: any): void { this.onTouched = fn; }
  setDisabledState(isDisabled: boolean): void { this.disabled.set(isDisabled); }
}
