import {PublicationTypes} from "../../publication-card-view/models/publication.dto";

export enum ConditionType {
  SubscriberCount = 0,
}

export enum ComparisonOperator {
  GreaterThanOrEqual = 0,
}

export interface ConditionalPublication {
  conditionType: ConditionType;
  conditionTarget: number;
  comparisonOperator: ComparisonOperator;
}


export interface CreatePublicationDto {
  content?: string;
  publicationType: PublicationTypes;
  images?: File[];
  publishAt?: string | Date;
  conditionType?: ConditionType;
  conditionTarget?: number;
  conditionOperator?: ComparisonOperator;
}

export interface ImageItem {
  file: File;
  preview: string;
  croppedFile?: File;
}
