import {Component, HostListener, inject, input, output, viewChild} from '@angular/core';
import {
  PublicationConditionalInputComponent
} from "./publication-conditional-input/publication-conditional-input.component";
import {PublicationPlannedInputComponent} from "./publication-planned-input/publication-planned-input.component";
import {FormBuilder, FormGroup, ReactiveFormsModule, Validators} from "@angular/forms";
import {PublicationTypes} from "../../publication-card-view/models/publication.dto";
import {PublicationTextComponent} from "./publication-text/publication-text.component";
import {PublicationTypeSelectorComponent} from "./publication-type-selector/publication-type-selector.component";
import {PublicationImageComponent} from "./publication-image/publication-image.component";
import {PublicationActionsComponent} from "./publication-actions/publication-actions.component";
import {TagService} from "../../../../shared/services/tag.service";
import {CreatePublicationDto} from "../models/create-publication.dto";
import {PublicationCreateService} from "../services/publication-create.service";
import {TagListComponent} from "./tag-list/tag-list.component";

@Component({
  selector: 'app-publication-create',
  imports: [
    PublicationConditionalInputComponent,
    PublicationPlannedInputComponent,
    PublicationTextComponent,
    PublicationTypeSelectorComponent,
    ReactiveFormsModule,
    PublicationImageComponent,
    PublicationActionsComponent,
    TagListComponent
  ],
  templateUrl: './publication-create.component.html',
  styleUrl: './publication-create.component.css'
})
export class PublicationCreateComponent {
  publicationCreated = output<void>();
  showButton = input<boolean>(true)

  private fb = new FormBuilder();
  private publicationCreateService:  PublicationCreateService= inject(PublicationCreateService);
  private tagService: TagService = inject(TagService);

  private publicationId: string | null = null;
  isOpen = false;
  tagList = viewChild(TagListComponent);

  form: FormGroup = this.fb.group({
    type: ['ordinary'],
    text: ['', Validators.required],
    image: [null],
    plannedAt: [null],
    condition: [null],
  });

  constructor() {
    this.form.get('type')?.valueChanges.subscribe((type: PublicationTypes) => {
      if (type === 'planned') {
        const defaultDate = new Date(Date.now() + 60 * 60 * 1000);
        this.form.get('plannedAt')?.setValue(defaultDate);
      }
    });
  }

  get selectedType(): PublicationTypes {
    return this.form.get('type')?.value;
  }

  open(presetType?: PublicationTypes, presetDate?: Date | null): void {
    this.isOpen = true;

    if (presetType) {
      this.form.get('type')?.setValue(presetType);
    }

    if (presetDate) {
      this.form.get('plannedAt')?.setValue(presetDate);
    }
  }
  close(): void {
    this.isOpen = false;
    this.form.reset( {type: 'ordinary'} );
    this.tagList()?.clearTags();
  }

  @HostListener('document:keydown.escape')
  onEscape(): void
  {
    if (this.isOpen) this.close();
  }

  submitPublication(): void {
    if (this.form.invalid) {
      this.form.markAllAsTouched();
      return;
    }

    const publicationDto = this.buildCreatePublicationDto();

    if (publicationDto) {
      this.publicationCreateService.createPublication(publicationDto).subscribe({
        next: (id: string): void => {
          const tags = this.tagList()?.getTags() ?? [];

          if (tags.length > 0) {
            this.tagService.saveSetTags(tags, id).subscribe({
              next: (): void =>  {
                this.close();
                this.publicationCreated.emit();
              },
              error: (err): void => console.error('Error saving tags:', err)
            });
          } else {
            this.close();
            this.publicationCreated.emit();
          }
        },
        error: (err): void => console.error('Error creating publication:', err)
      });
    }
  }

  private buildCreatePublicationDto(): CreatePublicationDto {
    const formValue = this.form.value;

    const dto: CreatePublicationDto = {
      publicationType: formValue.type,
      content: formValue.text || undefined,
    };

    if (formValue.image) {
      dto.images = formValue.image;
    }

    if (formValue.type === 'planned' && formValue.plannedAt) {
      dto.publishAt = formValue.plannedAt;
    }

    if (formValue.type === 'conditional' && formValue.condition) {
      const conditionData = formValue.condition;
      dto.conditionType = conditionData.conditionType;
      dto.conditionTarget = conditionData.conditionTarget;
      dto.conditionOperator = conditionData.comparisonOperator;
    }

    return dto;
  }
}
