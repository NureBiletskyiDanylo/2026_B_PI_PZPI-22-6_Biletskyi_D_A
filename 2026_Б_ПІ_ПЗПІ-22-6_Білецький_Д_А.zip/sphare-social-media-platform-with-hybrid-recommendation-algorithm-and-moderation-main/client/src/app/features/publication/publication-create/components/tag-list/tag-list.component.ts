import { Component, DestroyRef, ElementRef, inject, input, output, signal, viewChild } from '@angular/core';
import { GeneratedTagDto, SelectableTag, TagDto } from "../../../../../shared/models/tag.dto";
import { TagService } from "../../../../../shared/services/tag.service";
import { catchError, debounceTime, distinctUntilChanged, of, Subject, switchMap } from "rxjs";
import { takeUntilDestroyed } from "@angular/core/rxjs-interop";

@Component({
  selector: 'app-tag-list',
  imports: [],
  templateUrl: './tag-list.component.html',
  styleUrl: './tag-list.component.css'
})
export class TagListComponent {
  private tagService = inject(TagService);
  private destroyRef = inject(DestroyRef);

  content = input<string>('');

  tagsChanged = output<GeneratedTagDto[]>();

  tags = signal<SelectableTag[]>([]);

  searchQuery = signal<string>('');
  searchResults = signal<TagDto[]>([]);
  isSearching = signal<boolean>(false);
  showDropdown = signal<boolean>(false);

  // ML generation
  isGenerating = signal<boolean>(false);
  generateError = signal<string>('');

  private search$ = new Subject<string>();
  searchInput = viewChild<ElementRef<HTMLInputElement>>('searchInput');

  readonly MAX_TAGS = 20;

  constructor() {
    this.search$.pipe(
      debounceTime(300),
      distinctUntilChanged(),
      switchMap(query => {
        if (!query.trim()) {
          this.searchResults.set([]);
          this.isSearching.set(false);
          return of([]);
        }
        this.isSearching.set(true);
        return this.tagService.searchTags(query).pipe(
          catchError(() => of([]))
        );
      }),
      takeUntilDestroyed(this.destroyRef)
    ).subscribe(results => {
      const current = this.tags().map(t => t.name.toLowerCase());
      this.searchResults.set(
        (results as TagDto[]).filter(r => !current.includes(r.name.toLowerCase()))
      );
      this.isSearching.set(false);
      this.showDropdown.set(true);
    });
  }

  toggleLock(index: number): void {
    this.tags.update(currentTags => {
      const updated = [...currentTags];
      updated[index] = { ...updated[index], isLocked: !updated[index].isLocked };
      return updated;
    });
  }

  onSearchInput(value: string): void {
    this.searchQuery.set(value);
    this.search$.next(value);
    if (!value.trim()) this.showDropdown.set(false);
  }

  selectFromSearch(tag: TagDto): void {
    this.addTag(tag.name);
    this.searchQuery.set('');
    this.searchResults.set([]);
    this.showDropdown.set(false);
    this.searchInput()?.nativeElement.focus();
  }

  addFromInput(): void {
    const val = this.searchQuery().trim();
    if (!val) return;
    this.addTag(val);
    this.searchQuery.set('');
    this.searchResults.set([]);
    this.showDropdown.set(false);
  }

  private addTag(name: string): void {
    if (this.tags().length >= this.MAX_TAGS) return;
    const normalized = name.toLowerCase().trim();
    if (this.tags().some(t => t.name.toLowerCase() === normalized)) return;

    // FIX TS2345: Provide the required 'isLocked' structural property explicitly
    const updated: SelectableTag[] = [...this.tags(), { name: normalized, isLocked: false }];
    this.tags.set(updated);

    // Convert SelectableTag[] to GeneratedTagDto[] for output
    this.tagsChanged.emit(updated.map(t => ({ name: t.name })));
  }

  removeTag(index: number): void {
    const updated = this.tags().filter((_, i) => i !== index);
    this.tags.set(updated);
    this.tagsChanged.emit(updated.map(t => ({ name: t.name })));
  }

  onSearchBlur(): void {
    setTimeout(() => this.showDropdown.set(false), 150);
  }

  onSearchFocus(): void {
    if (this.searchResults().length > 0) this.showDropdown.set(true);
  }

  // Uses the reactive input data from the parent component
  generateTags(): void {
    const textContent = this.content();
    if (!textContent || !textContent.trim()) return;

    this.isGenerating.set(true);
    this.generateError.set('');

    this.tagService.getGeneratedTagsForUnsavedPublication(textContent).subscribe({
      next: (newTags: GeneratedTagDto[]) => {
        const protectedTags = this.tags().filter(t => t.isLocked);
        const freshTags = newTags.map(tag => ({ name: tag.name, isLocked: false }));

        this.tags.set([...protectedTags, ...freshTags]);
        this.isGenerating.set(false);
      },
      error: (err) => {
        console.error('Failed to generate tags:', err);
        this.generateError.set('Failed to automatically generate tags.');
        this.isGenerating.set(false);
      }
    });
  }

  getTags(): GeneratedTagDto[] {
    return this.tags().map(t => ({ name: t.name }));
  }

  clearTags(): void {
    this.tags.set([]);
    this.searchQuery.set('');
    this.searchResults.set([]);
    this.showDropdown.set(false);
  }
}
