import {Component, forwardRef, signal} from '@angular/core';
import {ControlValueAccessor, NG_VALUE_ACCESSOR} from "@angular/forms";
import {PublicationTypes} from "../../../publication-card-view/models/publication.dto";

@Component({
  selector: 'app-publication-type-selector',
  imports: [],
  templateUrl: './publication-type-selector.component.html',
  styleUrl: './publication-type-selector.component.css',
  providers: [
    {
      provide: NG_VALUE_ACCESSOR,
      useExisting: forwardRef(() => PublicationTypeSelectorComponent),
      multi: true
    }
  ]
})
export class PublicationTypeSelectorComponent implements ControlValueAccessor {
  selected = signal<PublicationTypes>('ordinary');
  disabled = signal<boolean>(false);

  readonly options: readonly PublicationTypes[] = ['ordinary', 'planned', 'conditional'];

  onChange: any = () => {};
  onTouched: any = () => {};

  select(type: PublicationTypes): void {
    if (this.disabled()) return;
    this.selected.set(type);
    this.onChange(type);
    this.onTouched();
  }

  writeValue(val: PublicationTypes): void {
    this.selected.set(val ?? 'ordinary');
  }

  registerOnChange(fn: any): void { this.onChange = fn; }
  registerOnTouched(fn: any): void { this.onTouched = fn; }
  setDisabledState(isDisabled: boolean): void { this.disabled.set(isDisabled); }
}
