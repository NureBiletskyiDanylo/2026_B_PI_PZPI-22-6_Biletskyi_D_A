import {Component, output} from '@angular/core';
import {CustomButtonComponent} from "../../../../../shared/components/custom-button/custom-button.component";

@Component({
  selector: 'app-publication-actions',
  imports: [
    CustomButtonComponent
  ],
  templateUrl: './publication-actions.component.html',
  styleUrl: './publication-actions.component.css'
})
export class PublicationActionsComponent {
  publish = output<void>();
  cancel = output<void>();

  onPublish(): void {
    this.publish.emit();
  }

  onCancel(): void {
    this.cancel.emit();
  }
}
