import {inject, Injectable} from '@angular/core';
import {HttpClient} from "@angular/common/http";
import {environment} from "../../../../../environments/environment";
import {CreatePublicationDto} from "../models/create-publication.dto";

@Injectable({
  providedIn: 'root'
})
export class PublicationCreateService {
  private http = inject(HttpClient);
  baseUrl = environment.apiUrl;

  createPublication(dto: CreatePublicationDto) {
    const formData = new FormData();

    if (dto.content) {
      formData.append('content', dto.content);
    }
    formData.append('publicationType', dto.publicationType);

    if (dto.images && dto.images.length > 0) {
      dto.images.forEach((file: any) => {
        formData.append('images', file);
      });
    }

    if (dto.publishAt) {
      const publishAt =
        dto.publishAt instanceof Date
          ? dto.publishAt.toISOString()
          : dto.publishAt;

      formData.append('publishAt', publishAt);
    }
    if (dto.conditionType) {
      formData.append('conditionType', dto.conditionType);
    }
    if (dto.conditionTarget !== undefined && dto.conditionTarget !== null) {
      formData.append('conditionTarget', dto.conditionTarget.toString());
    }
    if (dto.conditionOperator) {
      formData.append('conditionOperator', dto.conditionOperator);
    }

    return this.http.post(this.baseUrl + "/publication/create-publication", formData, {
      responseType: 'text'
    });
  }


  constructor() { }
}
