import {Component, forwardRef, OnInit, signal} from '@angular/core';
import {ComparisonOperator, ConditionalPublication, ConditionType} from "../../models/create-publication.dto";
import {
  ControlValueAccessor,
  FormBuilder,
  FormGroup,
  NG_VALUE_ACCESSOR,
  ReactiveFormsModule,
  Validators
} from "@angular/forms";
import {InputFieldComponent} from "../../../../../shared/components/input-field/input-field.component";

const CONDITION_TYPE_LABELS: Record<ConditionType, string> = {
  [ConditionType.SubscriberCount]: 'Subscriber Count',
};

const COMPARISON_OPERATOR_LABELS: Record<ComparisonOperator, string> = {
  [ComparisonOperator.GreaterThanOrEqual]: '≥ Greater than or equal',
};

@Component({
  selector: 'app-publication-conditional-input',
  imports: [ReactiveFormsModule, InputFieldComponent],
  templateUrl: './publication-conditional-input.component.html',
  styleUrl: './publication-conditional-input.component.css',
  providers: [
    {
      provide: NG_VALUE_ACCESSOR,
      useExisting: forwardRef(() => PublicationConditionalInputComponent),
      multi: true
    }
  ]
})
export class PublicationConditionalInputComponent implements ControlValueAccessor, OnInit {
  private fb = new FormBuilder();

  readonly conditionTypes = Object.entries(CONDITION_TYPE_LABELS).map(
    ([key, value]) => [Number(key), value] as [ConditionType, string]
  );

  readonly comparisonOperators = Object.entries(COMPARISON_OPERATOR_LABELS).map(
    ([key, value]) => [Number(key), value] as [ComparisonOperator, string]
  );

  form!: FormGroup;
  disabled = signal<boolean>(false);

  onChange: any = () => {};
  onTouched: any = () => {};

  ngOnInit(): void {
    this.form = this.fb.group({
      conditionType: [ConditionType.SubscriberCount],
      comparisonOperator: [ComparisonOperator.GreaterThanOrEqual],
      conditionTarget: [1, [Validators.required, Validators.min(1), Validators.pattern(/^\d+$/)]]
    });

    this.form.valueChanges.subscribe(val => {
      const out: ConditionalPublication = {
        conditionType: val.conditionType,
        comparisonOperator: val.comparisonOperator,
        conditionTarget: Number(val.conditionTarget)
      };
      this.onChange(out);
      this.onTouched();
    });
  }

  writeValue(val: ConditionalPublication | null): void {
    if (!val || !this.form) return;
    this.form.patchValue({
      conditionType: val.conditionType,
      comparisonOperator: val.comparisonOperator,
      conditionTarget: val.conditionTarget
    }, {emitEvent: false});
  }

  registerOnChange(fn: any): void { this.onChange = fn; }
  registerOnTouched(fn: any): void { this.onTouched = fn; }

  setDisabledState(isDisabled: boolean): void {
    this.disabled.set(isDisabled);
    isDisabled ? this.form?.disable() : this.form?.enable();
  }
}
