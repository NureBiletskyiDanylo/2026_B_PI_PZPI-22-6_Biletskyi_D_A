import {Component, forwardRef, input, signal} from '@angular/core';
import {InputFieldComponent} from "../../../../../shared/components/input-field/input-field.component";
import {ControlValueAccessor, FormsModule, NG_VALUE_ACCESSOR, ReactiveFormsModule} from "@angular/forms";

@Component({
  selector: 'app-publication-text',
  imports: [InputFieldComponent, ReactiveFormsModule, FormsModule],
  templateUrl: './publication-text.component.html',
  styleUrl: './publication-text.component.css',
  providers: [
    {
      provide: NG_VALUE_ACCESSOR,
      useExisting: forwardRef(() => PublicationTextComponent),
      multi: true
    }
  ]
})
export class PublicationTextComponent implements ControlValueAccessor {
  readonly MAX_LENGTH = 1000;

  label = input<string>('Text');
  labelBgColor = input<string>('#FFFAFA');

  value = signal<string>('');
  disabled = signal<boolean>(false);

  onChange: any = () => {};
  onTouched: any = () => {};

  onInput(raw: string): void {
    // Clamp to max length before propagating
    const clamped = raw.slice(0, this.MAX_LENGTH);
    this.value.set(clamped);
    this.onChange(clamped);
  }

  writeValue(val: any): void {
    this.value.set(val ? String(val).slice(0, this.MAX_LENGTH) : '');
  }

  registerOnChange(fn: any): void { this.onChange = fn; }
  registerOnTouched(fn: any): void { this.onTouched = fn; }
  setDisabledState(isDisabled: boolean): void { this.disabled.set(isDisabled); }
}
