import {inject, Injectable} from '@angular/core';
import {HttpClient} from "@angular/common/http";
import {environment} from "../../../../../environments/environment";
import {PublicationDto} from "../../../../shared/models/publication.dto";

@Injectable({
  providedIn: 'root'
})
export class PublicationService {
  private http = inject(HttpClient);
  baseUrl = environment.apiUrl;

  getPublicationById(id: string) {
    return this.http.get<PublicationDto>(`${this.baseUrl}/publication/${id}`);
  }
  constructor() { }
}
