import {Component, computed, inject, input, OnInit, viewChild} from '@angular/core';
import {PublicationService} from "../services/publication.service";
import {PublicationDto} from "../../../../shared/models/publication.dto";
import {UserIdentityComponent} from "../../publication-card-view/components/user-identity/user-identity.component";
import {DateContentComponent} from "../../publication-card-view/components/date-content/date-content.component";
import {TextContentComponent} from "../../publication-card-view/components/text-content/text-content.component";
import {ImageContentComponent} from "../../publication-card-view/components/image-content/image-content.component";
import {ActionsComponent} from "../../publication-card-view/components/actions/actions.component";
import {PublicationEditComponent} from "../../publication-edit/components/publication-edit.component";
import {PublicationDeleteComponent} from "../../publication-delete/components/publication-delete.component";
import {TagDto} from "../../../../shared/models/tag.dto";
import {TagService} from "../../../../shared/services/tag.service";
import {ActivatedRoute, Router} from "@angular/router";
import {LikeService} from "../../../../shared/services/like.service";
import {CommentListComponent} from "../../../comment/comment-card-list/components/comment-list.component";
import {CommentCreateComponent} from "../../../comment/comment-create/components/comment-create.component";
import {
  CreateComplaintComponent
} from "../../../complaint/create-complaint/components/create-complaint/create-complaint.component";
import {AccountService} from "../../../auth/services/account.service";

@Component({
  selector: 'app-publication-page',
  imports: [
    UserIdentityComponent,
    DateContentComponent,
    TextContentComponent,
    ImageContentComponent,
    ActionsComponent,
    PublicationEditComponent,
    PublicationDeleteComponent,
    CommentListComponent,
    CommentCreateComponent,
    CreateComplaintComponent
  ],
  templateUrl: './publication-page.component.html',
  styleUrl: './publication-page.component.css'
})
export class PublicationPageComponent implements OnInit {
  private publicationService: PublicationService = inject(PublicationService);
  private likeService: LikeService = inject(LikeService);
  private tagService: TagService = inject(TagService);
  private route: ActivatedRoute = inject(ActivatedRoute);
  private accountService: AccountService = inject(AccountService);
  private router: Router = inject(Router);

  publicationId: string | null = null;
  publicationDto: PublicationDto | null = null;
  tags: TagDto[] = [];
  profanitySettings = computed(() => this.accountService.currentUser()?.profanityFilter ?? false);

  editModal = viewChild<PublicationEditComponent>('editModal');
  deleteModal = viewChild<PublicationDeleteComponent>('deleteModal');
  commentList = viewChild(CommentListComponent);
  complaintModal = viewChild<CreateComplaintComponent>('complaintModal');

  ngOnInit(): void {
    this.route.params.subscribe(params => {
      this.publicationId = params['id'];
      if (this.publicationId) {
        this.loadPublication();
        this.loadTags();
      }
    });
  }

  loadPublication() : void {
    const id = this.publicationId;
    if (id) {
      this.publicationService.getPublicationById(id).subscribe({
        next: (publication: PublicationDto) => {
          this.publicationDto = publication;
        },
        error: (err: Error) => {
          console.error(err);
        }
      })
    }
  }

  loadTags() : void {
    const id = this.publicationId;
    if (id) {
      this.tagService.getTagsForPublication(id).subscribe({
        next: (tags: TagDto[]) => {
          this.tags = tags;
        },
        error: (err: Error) => {
          console.error(err);
        }
      })
    }
  }

  protected onLike() {
    const publication = this.publicationDto;
    if (publication) {
      this.likeService.likePublication(publication.id).subscribe({
        next: (data) => {
          publication.likesAmount = data.amountOfLikes;
          publication.isLikedByCurrentUser = data.isLikedByCurrentUser;
        },
        error: (err) => {
          console.error('Failed to toggle like status:', err);
        }
      });
    }
  }

  protected onCommentCreated(): void {
    if (this.publicationDto) {
      this.publicationDto.commentAmount++;
    }

    const listInstance = this.commentList() as any;
    if (listInstance && typeof listInstance.resetAndLoadInitialComments === 'function') {
      listInstance.resetAndLoadInitialComments();
    }
  }

  protected onComment() {

  }

  protected onShare() {

  }

  onReport() {
    this.complaintModal()?.openModal();
  }

  protected onEdit() {
    this.editModal()?.open();
  }

  protected onDelete() {
    this.deleteModal()?.open();
  }

  protected onEditClosed(edited: boolean) {
    if (edited) {
      this.loadPublication();
      this.loadTags();
    }
  }

  protected onPublicationDeleted() {
    this.loadPublication();
    this.loadTags();
  }
}
