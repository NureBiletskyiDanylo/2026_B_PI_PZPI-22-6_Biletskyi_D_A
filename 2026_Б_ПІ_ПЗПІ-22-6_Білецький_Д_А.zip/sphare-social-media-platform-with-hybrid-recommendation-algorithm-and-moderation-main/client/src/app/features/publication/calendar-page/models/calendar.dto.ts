export interface PublicationCalendarModel {
  id: string;
  content: string | undefined | null;
  publishAt: Date
}
