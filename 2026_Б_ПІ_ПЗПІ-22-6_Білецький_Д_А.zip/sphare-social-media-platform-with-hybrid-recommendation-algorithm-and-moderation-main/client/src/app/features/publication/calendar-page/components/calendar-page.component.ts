import {Component, inject, signal, viewChild} from '@angular/core';
import { CommonModule } from '@angular/common';
import {PublicationCreateComponent} from "../../publication-create/components/publication-create.component";
import {CalendarHeaderComponent} from "./calendar-header/calendar-header.component";
import {CalendarGridComponent} from "./calendar-grid/calendar-grid.component";
import {CalendarService} from "../services/calendar.service";
import {PublicationCalendarModel} from "../models/calendar.dto";

@Component({
  selector: 'app-calendar-page',
  standalone: true,
  imports: [CommonModule, CalendarHeaderComponent, CalendarGridComponent, PublicationCreateComponent],
  templateUrl: './calendar-page.component.html',
  styleUrl: './calendar-page.component.css'
})
export class CalendarPageComponent {
  private calendarService = inject(CalendarService);

  publications = signal<PublicationCalendarModel[]>([]);
  currentMonth = signal<Date>(new Date());
  daysInMonth = signal<Date[]>([]);

  publicationCreate = viewChild(PublicationCreateComponent);

  ngOnInit(): void {
    this.fetchPublications();
  }

  fetchPublications(): void {
    this.calendarService.getPublicationCalendar().subscribe(data => {
      this.publications.set(data);
      this.buildCalendar();
    });
  }

  buildCalendar(): void {
    const month = this.currentMonth();
    const year = month.getFullYear();
    const monthIndex = month.getMonth();

    const firstDayOfMonth = new Date(year, monthIndex, 1);

    const startDayOfWeek = firstDayOfMonth.getDay(); // 0 = Sunday
    const startOffset = startDayOfWeek === 0 ? 6 : startDayOfWeek - 1; // Monday-start

    const rows = 6;
    const days: Date[] = [];

    for (let i = 0; i < rows * 7; i++) {
      days.push(new Date(year, monthIndex, 1 + i - startOffset));
    }

    this.daysInMonth.set(days);
  }

  previousMonth(): void {
    const month = this.currentMonth();
    this.currentMonth.set(new Date(month.getFullYear(), month.getMonth() - 1, 1));
    this.buildCalendar();
  }

  nextMonth(): void {
    const month = this.currentMonth();
    this.currentMonth.set(new Date(month.getFullYear(), month.getMonth() + 1, 1));
    this.buildCalendar();
  }

  onAddPublication(day: Date): void {
    const plannedDate = new Date(day);
    plannedDate.setHours(12, 0, 0, 0);

    this.publicationCreate()?.open('planned', plannedDate);
  }

  onPublicationCreated(): void {
    this.fetchPublications();
  }
}
