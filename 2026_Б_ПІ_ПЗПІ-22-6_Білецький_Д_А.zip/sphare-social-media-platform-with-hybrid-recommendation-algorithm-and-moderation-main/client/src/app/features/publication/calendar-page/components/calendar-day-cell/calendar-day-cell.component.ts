import {Component, computed, input, output} from '@angular/core';
import {RouterLink} from "@angular/router";
import {PublicationCalendarModel} from "../../models/calendar.dto";

@Component({
  selector: 'app-calendar-day-cell',
  imports: [
    RouterLink
  ],
  templateUrl: './calendar-day-cell.component.html',
  styleUrl: './calendar-day-cell.component.css'
})
export class CalendarDayCellComponent {
  day = input.required<Date>();
  currentMonth = input.required<Date>();
  publications = input<PublicationCalendarModel[]>([]);

  addPublication = output<Date>();

  isOtherMonth = computed(() => this.day().getMonth() !== this.currentMonth().getMonth());

  isPastDate = computed(() => {
    const today = new Date();
    today.setHours(0, 0, 0, 0);

    const compareDay = new Date(this.day());
    compareDay.setHours(0, 0, 0, 0);

    return compareDay < today;
  });

  onAddClick(event: Event): void {
    event.stopPropagation();
    this.addPublication.emit(this.day());
  }

  truncate(content: string | undefined | null): string {
    if (!content) return '';
    return content.length > 30 ? content.slice(0, 30) + '...' : content;
  }
}
