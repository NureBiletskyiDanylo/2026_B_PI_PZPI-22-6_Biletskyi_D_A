import {Component, input, output} from '@angular/core';
import {DatePipe} from "@angular/common";

@Component({
  selector: 'app-calendar-header',
  imports: [
    DatePipe
  ],
  templateUrl: './calendar-header.component.html',
  styleUrl: './calendar-header.component.css'
})
export class CalendarHeaderComponent {
  currentMonth = input.required<Date>();

  previous = output<void>();
  next = output<void>();
}
