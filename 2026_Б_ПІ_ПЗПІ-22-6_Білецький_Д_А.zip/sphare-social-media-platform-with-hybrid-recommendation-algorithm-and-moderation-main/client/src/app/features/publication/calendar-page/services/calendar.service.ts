import {inject, Injectable} from '@angular/core';
import {HttpClient} from "@angular/common/http";
import {environment} from "../../../../../environments/environment";
import {PublicationCalendarModel} from "../models/calendar.dto";

@Injectable({
  providedIn: 'root'
})
export class CalendarService {
  private http = inject(HttpClient);
  baseUrl = environment.apiUrl;

  getPublicationCalendar() {
    return this.http.get<PublicationCalendarModel[]>(this.baseUrl + '/publication/publication-calendar');
  }
  constructor() { }
}
