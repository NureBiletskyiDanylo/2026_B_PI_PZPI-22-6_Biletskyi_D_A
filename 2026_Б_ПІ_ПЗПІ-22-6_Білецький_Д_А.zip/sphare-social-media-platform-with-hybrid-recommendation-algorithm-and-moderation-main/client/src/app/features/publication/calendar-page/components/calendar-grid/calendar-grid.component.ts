import {Component, input, output} from '@angular/core';
import {CalendarDayCellComponent} from "../calendar-day-cell/calendar-day-cell.component";
import {PublicationCalendarModel} from "../../models/calendar.dto";
const WEEKDAYS = ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'];
@Component({
  selector: 'app-calendar-grid',
  imports: [
    CalendarDayCellComponent
  ],
  templateUrl: './calendar-grid.component.html',
  styleUrl: './calendar-grid.component.css'
})
export class CalendarGridComponent {
  days = input.required<Date[]>();
  currentMonth = input.required<Date>();
  publications = input<PublicationCalendarModel[]>([]);

  addPublication = output<Date>();

  weekdays = WEEKDAYS;

  publicationsForDay(day: Date): PublicationCalendarModel[] {
    return this.publications().filter(p => {
      const pubDate = new Date(p.publishAt);
      return pubDate.toDateString() === day.toDateString();
    });
  }
}
