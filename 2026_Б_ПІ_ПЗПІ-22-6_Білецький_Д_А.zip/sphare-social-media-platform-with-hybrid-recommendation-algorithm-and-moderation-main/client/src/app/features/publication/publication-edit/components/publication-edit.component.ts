import {Component, HostListener, inject, input, OnInit, output} from '@angular/core';
import {
  PublicationUpdateData, UpdateConditionalPublicationDto,
  UpdatePlannedPublicationDto,
  UpdatePublicationContentDto
} from "../models/publication-edit.dto";
import {PublicationEditService} from "../services/publication-edit.service";
import {FormsModule} from "@angular/forms";
import {EditContentComponent} from "./edit-content/edit-content.component";
import {TagDto} from "../../../../shared/models/tag.dto";
import {TagService} from "../../../../shared/services/tag.service";
import {ComparisonOperator, ConditionType} from "../../publication-create/models/create-publication.dto";
import {EditPlannedComponent} from "./edit-planned/edit-planned.component";
import {EditConditionalComponent} from "./edit-conditional/edit-conditional.component";
import {EditTagsComponent} from "./edit-tags/edit-tags.component";
import {PublicationTypes} from "../../../../_models/publications/publicationModel";

@Component({
  selector: 'app-publication-edit',
  imports: [
    FormsModule,
    EditContentComponent,
    EditPlannedComponent,
    EditConditionalComponent,
    EditTagsComponent
  ],
  templateUrl: './publication-edit.component.html',
  styleUrl: './publication-edit.component.css'
})
export class PublicationEditComponent{
  private publicationEditService = inject(PublicationEditService);
  private tagService = inject(TagService);

  publicationId = input<string>();
  editClosed = output<boolean>();
  publicationDto: PublicationUpdateData | null = null;
  tags: TagDto[] = [];
  isOpen = false;
  isLoading = false;
  somethingWasUpdated = false;

  loadPublication(): void {
    const id = this.publicationId();
    if (!id) return;

    this.isLoading = true;
    this.publicationEditService.getPublicationUpdateDataById(id).subscribe({
      next: (data) => {
        this.publicationDto = data;
        if (this.publicationDto) {
          this.tagService.getTagsForPublication(this.publicationDto.id).subscribe({
            next: (tags) => { this.tags = tags; },
            error: (err) => { console.error(err); }
          });
        }
        this.isLoading = false;
      },
      error: (err) => {
        console.error('Error fetching publication:', err);
        this.isLoading = false;
      }
    });
  }

  open(): void {
    this.isOpen = true;
    this.loadPublication();
  }

  close(): void {
    this.isOpen = false;
    this.editClosed.emit(this.somethingWasUpdated);
  }

  @HostListener('document:keydown.escape')
  onEscape(): void {
    if (this.isOpen) this.close();
  }

  submitUpdate(): void {
    console.log('Submit changes for DTO:', this.publicationDto);
  }

  handleContentUpdate(newText: string): void {
    const id = this.publicationId();
    if (!id) return;

    const payload: UpdatePublicationContentDto = { publicationId: id, newContent: newText };

    this.publicationEditService.updatePublicationContent(payload).subscribe({
      next: () => {
        if (this.publicationDto) this.publicationDto.content = newText;
        this.somethingWasUpdated = true;
      },
      error: (err) => console.error('Failed content update:', err)
    });
  }

  handlePlannedUpdate(newDate: string): void {
    const id = this.publicationId();
    if (!id) return;

    const payload: UpdatePlannedPublicationDto = { publicationId: id, publishAt: newDate };

    this.publicationEditService.updatePlanned(payload).subscribe({
      next: () => {
        if (this.publicationDto) this.publicationDto.publishAt = newDate;
        this.somethingWasUpdated = true;
      },
      error: (err) => console.error('Failed planned update:', err)
    });
  }

  handleConditionalUpdate(event: { conditionType: ConditionType; comparisonOperator: ComparisonOperator; conditionTarget: number }): void {
    const id = this.publicationId();
    if (!id) return;

    const payload: UpdateConditionalPublicationDto = { publicationId: id, ...event };

    this.publicationEditService.updateConditional(payload).subscribe({
      next: () => {
        if (this.publicationDto) {
          this.publicationDto.conditionType = event.conditionType;
          this.publicationDto.comparisonOperator = event.comparisonOperator;
          this.publicationDto.conditionTarget = event.conditionTarget;
          this.somethingWasUpdated = true;
        }
      },
      error: (err) => console.error('Failed conditional update:', err)
    });
  }

  handleTagsSaved(): void {
    const id = this.publicationId();
    if (!id) return;
    this.tagService.getTagsForPublication(id).subscribe({
      next: (tags) =>
      {
        this.tags = tags;
        this.somethingWasUpdated = true;
      },
      error: (err) => console.error('Failed to refresh tags:', err)
    });
  }

  protected readonly PublicationTypes = PublicationTypes;
}
