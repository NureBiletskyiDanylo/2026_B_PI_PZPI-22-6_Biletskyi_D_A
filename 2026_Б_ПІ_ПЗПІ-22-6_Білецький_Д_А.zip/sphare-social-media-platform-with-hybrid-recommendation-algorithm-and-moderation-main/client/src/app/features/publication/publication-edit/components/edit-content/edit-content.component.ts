import {Component, effect, input, output, signal} from '@angular/core';
import {FormsModule} from "@angular/forms";
import {InputFieldComponent} from "../../../../../shared/components/input-field/input-field.component";

@Component({
  selector: 'app-edit-content',
  imports: [
    FormsModule,
    InputFieldComponent
  ],
  templateUrl: './edit-content.component.html',
  styleUrl: './edit-content.component.css'
})
export class EditContentComponent {
  readonly MAX_LENGTH = 1000;

  content = input<string>('');
  label = input<string>('Edit Content');
  labelBgColor = input<string>('#FFFAFA');

  contentEditConfirm = output<string>();

  draftContent = signal<string>('');

  constructor() {
    effect(() => {
      this.draftContent.set(this.content() ?? '');
    });
  }

  onInput(raw: string): void {
    const clamped = raw.slice(0, this.MAX_LENGTH);
    this.draftContent.set(clamped);
  }

  confirmChange(): void {
    this.contentEditConfirm.emit(this.draftContent());
  }
}
