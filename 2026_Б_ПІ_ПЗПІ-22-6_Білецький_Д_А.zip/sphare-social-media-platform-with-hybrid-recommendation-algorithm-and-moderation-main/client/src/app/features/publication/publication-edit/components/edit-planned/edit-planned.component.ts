import {Component, effect, input, output, signal} from '@angular/core';

@Component({
  selector: 'app-edit-planned',
  imports: [],
  templateUrl: './edit-planned.component.html',
  styleUrl: './edit-planned.component.css'
})
export class EditPlannedComponent {
  publishAt = input<string | null | undefined>('');

  plannedEditConfirm = output<string>();

  minDateTimeString = signal<string>('');
  draftValue = signal<string>('');

  constructor() {
    this.refreshMinDateTime();

    effect(() => {
      const parentDate = this.publishAt();
      if (parentDate) {
        const dateObj = new Date(parentDate);
        this.draftValue.set(this.toLocalDateTimeString(dateObj));
      }
    });
  }

  private getMinDateTime(): string {
    const min = new Date(Date.now() + 60 * 60 * 1000); // now + 1 hour
    return this.toLocalDateTimeString(min);
  }

  private toLocalDateTimeString(date: Date): string {
    const yyyy = date.getFullYear();
    const MM = String(date.getMonth() + 1).padStart(2, '0');
    const dd = String(date.getDate()).padStart(2, '0');
    const hh = String(date.getHours()).padStart(2, '0');
    const mm = String(date.getMinutes()).padStart(2, '0');
    return `${yyyy}-${MM}-${dd}T${hh}:${mm}`;
  }

  protected refreshMinDateTime(): void {
    this.minDateTimeString.set(this.getMinDateTime());
  }

  onDateTimeChange(event: Event): void {
    this.refreshMinDateTime();

    const raw = (event.target as HTMLInputElement).value;
    if (!raw) return;

    const selected = new Date(raw);
    const minTime = new Date(Date.now() + 60 * 60 * 1000);

    const resolved = selected < minTime ? minTime : selected;
    const resolvedStr = this.toLocalDateTimeString(resolved);

    this.draftValue.set(resolvedStr);

    if (resolved !== selected) {
      (event.target as HTMLInputElement).value = resolvedStr;
    }
  }

  protected get isUnchanged(): boolean {
    const parentDate = this.publishAt();
    if (!parentDate) return false;

    const originalLocal = this.toLocalDateTimeString(new Date(parentDate));
    return this.draftValue() === originalLocal;
  }

  confirmChange(): void {
    this.refreshMinDateTime();
    if (!this.draftValue()) return;

    const finalIsoString = new Date(this.draftValue()).toISOString();
    this.plannedEditConfirm.emit(finalIsoString);
  }
}
