import {ComparisonOperator, ConditionType} from "../../publication-create/models/create-publication.dto";
import {PublicationTypes} from "../../../../_models/publications/publicationModel";

export interface UpdatePublicationContentDto {
  publicationId: string;
  newContent?: string;
}

export interface UpdatePlannedPublicationDto {
  publicationId: string;
  publishAt: string;
}

export interface UpdateConditionalPublicationDto{
  publicationId: string;
  conditionType: ConditionType;
  conditionTarget: number;
  comparisonOperator: ComparisonOperator;
}


export interface PublicationUpdateData {
  id: string;
  content?: string | null;
  publishAt?: string | null;
  conditionType: ConditionType | null;
  conditionTarget: number | null;
  comparisonOperator: ComparisonOperator | null;
  publicationType: PublicationTypes;
}
