import {inject, Injectable} from '@angular/core';
import {HttpClient} from "@angular/common/http";
import {environment} from "../../../../../environments/environment";
import {
  PublicationUpdateData,
  UpdateConditionalPublicationDto,
  UpdatePlannedPublicationDto,
  UpdatePublicationContentDto
} from "../models/publication-edit.dto";
import {PublicationDto} from "../../../../shared/models/publication.dto";

@Injectable({
  providedIn: 'root'
})
export class PublicationEditService {
  private http = inject(HttpClient);
  baseUrl = environment.apiUrl;

  updatePublicationContent(updateDto: UpdatePublicationContentDto) {
    return this.http.put<PublicationDto>(this.baseUrl + "/publication/update-content", updateDto);
  }

  updatePlanned(updateDto: UpdatePlannedPublicationDto) {
    return this.http.put<PublicationDto>(this.baseUrl + "/publication/update-planned", updateDto);
  }

  updateConditional(updateDto: UpdateConditionalPublicationDto) {
    return this.http.put<PublicationDto>(this.baseUrl + "/publication/update-conditional", updateDto);
  }

  getPublicationUpdateDataById(id: string) {
    return this.http.get<PublicationUpdateData>(this.baseUrl + "/publication/fetch-update-data/" + id);
  }

  constructor() { }
}
