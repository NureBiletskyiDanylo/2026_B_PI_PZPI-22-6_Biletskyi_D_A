import {Component, DestroyRef, ElementRef, inject, input, OnInit, output, signal, viewChild} from '@angular/core';
import {GeneratedTagDto, SelectableTag, TagDto} from "../../../../../shared/models/tag.dto";
import {TagService} from "../../../../../shared/services/tag.service";
import {catchError, debounceTime, distinctUntilChanged, of, Subject, switchMap} from "rxjs";
import {takeUntilDestroyed} from "@angular/core/rxjs-interop";

@Component({
  selector: 'app-edit-tags',
  imports: [],
  templateUrl: './edit-tags.component.html',
  styleUrl: './edit-tags.component.css'
})
export class EditTagsComponent implements OnInit {
  private tagService = inject(TagService);
  private destroyRef = inject(DestroyRef);

  publicationId = input.required<string>();
  receivedTags = input<TagDto[]>([]);
  content = input<string>('');

  saved = output<void>();
  cancelled = output<void>();

  tags = signal<SelectableTag[]>([]);
  searchQuery = signal<string>('');
  searchResults = signal<TagDto[]>([]);
  isSearching = signal<boolean>(false);
  showDropdown = signal<boolean>(false);
  isSaving = signal<boolean>(false);
  saveError = signal<string>('');
  isGenerating = signal<boolean>(false);
  generateError = signal<string>('');

  private search$ = new Subject<string>();
  searchInput = viewChild<ElementRef<HTMLInputElement>>('searchInput');

  readonly MAX_TAGS = 20;

  constructor() {
    this.search$.pipe(
      debounceTime(300),
      distinctUntilChanged(),
      switchMap(query => {
        if (!query.trim()) {
          this.searchResults.set([]);
          this.isSearching.set(false);
          return of([]);
        }
        this.isSearching.set(true);
        return this.tagService.searchTags(query).pipe(
          catchError(() => of([]))
        );
      }),
      takeUntilDestroyed(this.destroyRef)
    ).subscribe(results => {
      const current = this.tags().map(t => t.name.toLowerCase());
      this.searchResults.set(
        (results as TagDto[]).filter(r => !current.includes(r.name.toLowerCase()))
      );
      this.isSearching.set(false);
      this.showDropdown.set(true);
    });
  }

  ngOnInit(): void {
    const initial = (this.receivedTags() ?? []).map(t => ({
      name: t.name,
      isLocked: false
    }));
    this.tags.set(initial);
  }

  onSearchInput(value: string): void {
    this.searchQuery.set(value);
    this.search$.next(value);
    if (!value.trim()) this.showDropdown.set(false);
  }

  selectFromSearch(tag: TagDto): void {
    this.addTag(tag.name);
    this.searchQuery.set('');
    this.searchResults.set([]);
    this.showDropdown.set(false);
    this.searchInput()?.nativeElement.focus();
  }

  addFromInput(): void {
    const val = this.searchQuery().trim();
    if (!val) return;
    this.addTag(val);
    this.searchQuery.set('');
    this.searchResults.set([]);
    this.showDropdown.set(false);
  }

  private addTag(name: string): void {
    if (this.tags().length >= this.MAX_TAGS) return;
    const normalized = name.toLowerCase().trim();
    if (this.tags().some(t => t.name.toLowerCase() === normalized)) return;
    this.tags.update(current => [...current, { name: normalized, isLocked: false }]);
  }

  removeTag(index: number): void {
    this.tags.update(current => current.filter((_, i) => i !== index));
  }

  toggleLock(index: number): void {
    this.tags.update(current => {
      const updated = [...current];
      updated[index] = { ...updated[index], isLocked: !updated[index].isLocked };
      return updated;
    });
  }

  onSearchBlur(): void {
    setTimeout(() => this.showDropdown.set(false), 150);
  }

  onSearchFocus(): void {
    if (this.searchResults().length > 0) this.showDropdown.set(true);
  }

  generateTags(): void {
    const textContent = this.content();
    if (!textContent?.trim()) return;

    this.isGenerating.set(true);
    this.generateError.set('');

    this.tagService.getGeneratedTagsForUnsavedPublication(textContent).subscribe({
      next: (newTags: GeneratedTagDto[]) => {
        const locked = this.tags().filter(t => t.isLocked);
        const fresh = newTags.map(t => ({ name: t.name, isLocked: false }));
        this.tags.set([...locked, ...fresh]);
        this.isGenerating.set(false);
      },
      error: () => {
        this.generateError.set('Failed to auto-generate tags.');
        this.isGenerating.set(false);
      }
    });
  }

  save(): void {
    this.isSaving.set(true);
    this.saveError.set('');

    const tagNames = this.tags().map(t => t.name);

    this.tagService.syncTags(this.publicationId(), tagNames).subscribe({
      next: () => {
        this.isSaving.set(false);
        this.saved.emit();
      },
      error: () => {
        this.saveError.set('Failed to save tags. Please try again.');
        this.isSaving.set(false);
      }
    });
  }

  cancel(): void {
    this.cancelled.emit();
  }
}
