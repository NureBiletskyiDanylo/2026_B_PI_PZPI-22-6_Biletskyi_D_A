import {Component, effect, inject, input, OnInit, output} from '@angular/core';
import {ComparisonOperator, ConditionType} from "../../../publication-create/models/create-publication.dto";
import {FormBuilder, FormGroup, ReactiveFormsModule, Validators} from "@angular/forms";
import {InputFieldComponent} from "../../../../../shared/components/input-field/input-field.component";

const CONDITION_TYPE_LABELS: Record<ConditionType, string> = {
  [ConditionType.SubscriberCount]: 'Subscriber Count',
};

const COMPARISON_OPERATOR_LABELS: Record<ComparisonOperator, string> = {
  [ComparisonOperator.GreaterThanOrEqual]: '≥ Greater than or equal',
};

@Component({
  selector: 'app-edit-conditional',
  imports: [
    InputFieldComponent,
    ReactiveFormsModule
  ],
  templateUrl: './edit-conditional.component.html',
  styleUrl: './edit-conditional.component.css'
})
export class EditConditionalComponent implements OnInit {
  private fb = inject(FormBuilder);

  conditionType = input<ConditionType | null | undefined>();
  comparisonOperator = input<ComparisonOperator | null | undefined>();
  conditionTarget = input<number | null | undefined>();

  conditionalEditConfirm = output<{
    conditionType: ConditionType;
    comparisonOperator: ComparisonOperator;
    conditionTarget: number;
  }>();

  readonly conditionTypes = Object.entries(CONDITION_TYPE_LABELS).map(
    ([key, value]) => [Number(key), value] as [ConditionType, string]
  );

  readonly comparisonOperators = Object.entries(COMPARISON_OPERATOR_LABELS).map(
    ([key, value]) => [Number(key), value] as [ComparisonOperator, string]
  );

  form!: FormGroup;

  constructor() {
    effect(() => {
      if (!this.form) return;
      this.form.patchValue({
        conditionType: this.conditionType() ?? 'SubscriberCount',
        comparisonOperator: this.comparisonOperator() ?? 'GreaterThanOrEqual',
        conditionTarget: this.conditionTarget() ?? 1
      }, { emitEvent: false });
    });
  }

  ngOnInit(): void {
    this.form = this.fb.group({
      conditionType: [this.conditionType() ?? ConditionType.SubscriberCount],
      comparisonOperator: [this.comparisonOperator() ?? ComparisonOperator.GreaterThanOrEqual],
      conditionTarget: [this.conditionTarget() ?? 1, [Validators.required, Validators.min(1), Validators.pattern(/^\d+$/)]]
    });
  }

  protected get isUnchanged(): boolean {
    if (!this.form) return true;
    const val = this.form.value;
    return val.conditionType === this.conditionType() &&
      val.comparisonOperator === this.comparisonOperator() &&
      Number(val.conditionTarget) === this.conditionTarget();
  }

  confirmChange(): void {
    if (this.form.invalid) {
      this.form.markAllAsTouched();
      return;
    }

    const val = this.form.value;
    this.conditionalEditConfirm.emit({
      conditionType: val.conditionType,
      comparisonOperator: val.comparisonOperator,
      conditionTarget: Number(val.conditionTarget)
    });
  }
}
