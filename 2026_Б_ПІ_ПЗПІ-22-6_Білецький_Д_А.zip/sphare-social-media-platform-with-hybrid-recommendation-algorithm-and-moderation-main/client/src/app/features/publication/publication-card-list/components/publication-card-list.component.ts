import {Component, computed, inject, OnInit} from '@angular/core';
import {PublicationListService} from "../services/publication-list.service";
import {ActivatedRoute} from "@angular/router";
import {defaultPaginationParams, PagedList} from "../../../../shared/models/pagedlist.dto";
import {PublicationCardDto} from "../../publication-card-view/models/publication.dto";
import {PublicationCardComponent} from "../../publication-card-view/components/publication-card.component";
import {AccountService} from "../../../auth/services/account.service";

@Component({
  selector: 'app-publication-card-list',
  imports: [
    PublicationCardComponent
  ],
  templateUrl: './publication-card-list.component.html',
  styleUrl: './publication-card-list.component.css'
})
export class PublicationCardListComponent implements OnInit {
  private publicationListService: PublicationListService = inject(PublicationListService);
  private accountService: AccountService = inject(AccountService);
  private route: ActivatedRoute = inject(ActivatedRoute);

  publicationList: PagedList<PublicationCardDto> | null = null;
  profanitySettings = computed(() => this.accountService.currentUser()?.profanityFilter ?? false);

  private currentUNI: string = '';

  ngOnInit(): void {
    this.route.params.subscribe(params => {
      this.currentUNI = params['uNI'] || '';
      if (this.currentUNI) {
        this.loadPublications(this.currentUNI);
      }
    });
  }

  loadPublications(uNI: string) {
    this.publicationListService.getPublicationBatch(uNI, defaultPaginationParams).subscribe({
      next: (publications) => this.publicationList = publications,
      error: (err) => console.log(err),
    });
  }

  handlePublicationChanged(wasUpdated: boolean): void {
    if (wasUpdated && this.currentUNI) {
      this.loadPublications(this.currentUNI);
    }
  }
}
