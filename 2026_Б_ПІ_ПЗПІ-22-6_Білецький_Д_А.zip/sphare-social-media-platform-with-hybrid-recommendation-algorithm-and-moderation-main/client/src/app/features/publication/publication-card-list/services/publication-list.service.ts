import {inject, Injectable} from '@angular/core';
import {HttpClient, HttpParams} from "@angular/common/http";
import {environment} from "../../../../../environments/environment";
import {PublicationCardDto} from "../../publication-card-view/models/publication.dto";
import {PagedList, PaginationParams} from "../../../../shared/models/pagedlist.dto";

@Injectable({
  providedIn: 'root'
})
export class PublicationListService {
  private http = inject(HttpClient);
  baseUrl = environment.apiUrl;

  getPublicationBatch(uNI: string, paginationParams: PaginationParams) {
    const params = new HttpParams()
      .set('page', paginationParams.page)
      .set('pageSize', paginationParams.pageSize);

    return this.http.get<PagedList<PublicationCardDto>>(
      this.baseUrl + '/publication/publication-of-' + uNI,
      { params }
    );
  }

  constructor() { }
}
