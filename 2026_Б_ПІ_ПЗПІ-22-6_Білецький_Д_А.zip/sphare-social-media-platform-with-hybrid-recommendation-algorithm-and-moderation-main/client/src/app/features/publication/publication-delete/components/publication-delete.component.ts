import {Component, HostListener, inject, input, output} from '@angular/core';
import {PublicationDeleteService} from "../services/publication-delete.service";

@Component({
  selector: 'app-publication-delete',
  imports: [],
  templateUrl: './publication-delete.component.html',
  styleUrl: './publication-delete.component.css'
})
export class PublicationDeleteComponent {
  private deleteService: PublicationDeleteService = inject(PublicationDeleteService);

  publicationId = input<string>();
  publicationDeleted = output<void>();

  isOpen = false;
  isLoading = false;

  open(): void {
    this.isOpen = true;
  }

  close(): void {
    this.isOpen = false;
  }

  @HostListener('document:keydown.escape')
  onEscape(): void {
    if (this.isOpen) this.close();
  }

  confirmDelete(): void {
    const id = this.publicationId();
    if (!id) return;

    this.isLoading = true;
    this.deleteService.deletePublication(id).subscribe({
      next: () => {
        this.isLoading = false;
        this.publicationDeleted.emit();
        this.close();
      },
      error: (err) => {
        console.error('Failed to delete publication:', err);
        this.isLoading = false;
      }
    });
  }
}
