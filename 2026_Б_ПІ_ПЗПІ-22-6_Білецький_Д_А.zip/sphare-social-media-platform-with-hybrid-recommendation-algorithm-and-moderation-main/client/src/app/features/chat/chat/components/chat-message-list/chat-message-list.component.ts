import {Component, ElementRef, input, output, viewChild} from '@angular/core';
import {MessageDto} from "../../../../../_models/chatting/messageDto";
import {ChatUserDto} from "../../../../../_models/chatting/chatUserDto";
import {MessageViewComponent} from "../../../message-view/components/message-view.component";
import {ChatTypingIndicatorComponent} from "../chat-typing-indicator/chat-typing-indicator.component";

@Component({
  selector: 'app-chat-message-list',
  imports: [
    MessageViewComponent,
    ChatTypingIndicatorComponent
  ],
  templateUrl: './chat-message-list.component.html',
  styleUrl: './chat-message-list.component.css'
})
export class ChatMessageListComponent {
  readonly messages          = input<MessageDto[]>([]);
  readonly currentUserId     = input<string | null>(null);
  readonly otherUser         = input<ChatUserDto | null>(null);
  readonly hasMoreMessages   = input(false);
  readonly isLoadingMore     = input(false);
  readonly otherUserIsTyping = input(false);

  readonly loadMore = output<void>();

  readonly scrollRef = viewChild<ElementRef<HTMLDivElement>>('scrollContainer');

  private lastCount = 0;
  private didInitialScroll = false;

  ngAfterViewChecked(): void {
    const count = this.messages().length;
    if (count !== this.lastCount) {
      this.lastCount = count;
      this.scrollToBottom();
    } else if (!this.didInitialScroll) {
      this.didInitialScroll = true;
      this.scrollToBottom();
    }
  }

  onLoadMore(): void { this.loadMore.emit(); }

  trackByMessageId(index: number, m: MessageDto): string { return m.id; }

  private scrollToBottom(): void {
    requestAnimationFrame(() => {
      const el = this.scrollRef()?.nativeElement;
      if (el) el.scrollTop = el.scrollHeight;
    });
  }
}
