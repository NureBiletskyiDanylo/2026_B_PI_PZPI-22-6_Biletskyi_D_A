import {Component, input} from '@angular/core';
import {ChatUserDto} from "../../../../../_models/chatting/chatUserDto";
import {ChatAvatarComponent} from "../chat-avatar/chat-avatar.component";
import {RouterLink} from "@angular/router";

@Component({
  selector: 'app-chat-header',
  imports: [
    ChatAvatarComponent,
    RouterLink
  ],
  templateUrl: './chat-header.component.html',
  styleUrl: './chat-header.component.css'
})
export class ChatHeaderComponent {
  readonly otherUser   = input<ChatUserDto | null>(null);
  readonly isConnected = input(false);
}
