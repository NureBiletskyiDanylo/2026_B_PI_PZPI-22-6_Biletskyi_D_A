import {Component, input} from '@angular/core';

@Component({
  selector: 'app-chat-typing-indicator',
  imports: [],
  templateUrl: './chat-typing-indicator.component.html',
  styleUrl: './chat-typing-indicator.component.css'
})
export class ChatTypingIndicatorComponent {
  readonly username = input<string | null | undefined>(null);
}
