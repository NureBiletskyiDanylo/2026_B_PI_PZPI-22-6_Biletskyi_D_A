import {Component, computed, input, output, signal} from '@angular/core';
import {FormsModule} from "@angular/forms";

@Component({
  selector: 'app-chat-message-input',
  imports: [
    FormsModule
  ],
  templateUrl: './chat-message-input.component.html',
  styleUrl: './chat-message-input.component.css'
})
export class ChatMessageInputComponent {
  readonly isConnected = input(false);
  readonly isSending   = input(false);

  readonly send   = output<string>();
  readonly typing = output<void>();

  readonly draft = signal('');

  readonly canSend = computed(() =>
    this.draft().trim().length > 0 && this.isConnected() && !this.isSending()
  );

  onModelChange(value: string): void {
    this.draft.set(value);
    this.typing.emit();
  }

  onSubmit(): void {
    if (!this.canSend()) return;
    const text = this.draft().trim();
    this.draft.set('');
    this.send.emit(text);
  }
}
