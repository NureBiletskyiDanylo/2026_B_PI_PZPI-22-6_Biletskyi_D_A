import {Component, computed, input} from '@angular/core';

@Component({
  selector: 'app-chat-avatar',
  imports: [],
  templateUrl: './chat-avatar.component.html',
  styleUrl: './chat-avatar.component.css'
})
export class ChatAvatarComponent {
  readonly imageUrl = input<string | null | undefined>(null);
  readonly username = input<string | null | undefined>(null);
  readonly isOnline = input<boolean | undefined>(undefined);
  readonly size     = input(36);

  readonly initial = computed(() =>
    this.username()?.charAt(0)?.toUpperCase() || 'U'
  );
  readonly showStatus = computed(() => this.isOnline() !== undefined);
}
