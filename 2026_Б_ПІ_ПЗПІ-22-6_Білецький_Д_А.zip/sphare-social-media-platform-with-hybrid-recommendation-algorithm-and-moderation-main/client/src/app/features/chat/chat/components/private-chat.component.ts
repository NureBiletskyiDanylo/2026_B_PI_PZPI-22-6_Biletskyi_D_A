import {Component, inject, OnDestroy, OnInit, ViewChild, ElementRef, AfterViewChecked, signal} from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { ActivatedRoute, RouterModule } from '@angular/router';
import { Subscription } from 'rxjs';

import { SignalrService, Message, TypingEvent, PresenceEvent } from '../../../../_services/chatting/signalr.service';
import { ChatService } from '../../../../_services/chatting/chat.service';
import { AccountService } from '../../../auth/services/account.service';
import { MessageDto } from '../../../../_models/chatting/messageDto';
import { ChatWithMessageDto } from '../../../../_models/chatting/chatDto';
import { ChatUserDto } from '../../../../_models/chatting/chatUserDto';
import {ChatMessageListComponent} from "./chat-message-list/chat-message-list.component";
import {ChatMessageInputComponent} from "./chat-message-input/chat-message-input.component";
import {ChatHeaderComponent} from "./chat-header/chat-header.component";

@Component({
  selector: 'app-private-chat',
  standalone: true,
  imports: [CommonModule, FormsModule, RouterModule, ChatMessageListComponent, ChatMessageInputComponent, ChatHeaderComponent],
  templateUrl: './private-chat.component.html',
  styleUrl: './private-chat.component.css'
})
export class PrivateChatComponent implements OnInit, OnDestroy {
  private readonly signalRService = inject(SignalrService);
  private readonly chatService    = inject(ChatService);
  private readonly accountService = inject(AccountService);
  private readonly route          = inject(ActivatedRoute);

  // UI state
  readonly isConnected     = signal(false);
  readonly isLoading       = signal(false);
  readonly isSending       = signal(false);
  readonly error           = signal<string | null>(null);

  // Chat data
  readonly chatId          = signal('');
  readonly otherUser       = signal<ChatUserDto | null>(null);
  readonly currentUserId   = signal<string | null>(null);
  readonly messages        = signal<MessageDto[]>([]);

  // Typing
  readonly otherUserIsTyping = signal(false);

  // Pagination
  readonly currentPage     = signal(1);
  readonly pageSize        = 50;
  readonly hasMoreMessages = signal(false);
  readonly isLoadingMore   = signal(false);

  private subs: Subscription[] = [];
  private typingTimeout?: ReturnType<typeof setTimeout>;
  private isTyping = false;

  ngOnInit(): void {
    this.currentUserId.set(this.accountService.currentUser()?.userId ?? null);

    this.subs.push(
      this.route.params.subscribe(params => {
        const id = params['id'];
        if (!id) return;
        this.chatId.set(id);
        this.loadChatDetails();
        this.initializeSignalR();
      })
    );
  }

  ngOnDestroy(): void {
    this.subs.forEach(s => s.unsubscribe());

    if (this.chatId() && this.isConnected()) {
      this.signalRService.leaveChat(this.chatId())
        .catch(err => console.error('Failed to leave chat:', err));
    }
    this.stopTypingIndicator();
  }

  // ── Data ──────────────────────────────────────────────────────────────────
  private loadChatDetails(): void {
    this.isLoading.set(true);
    this.error.set(null);

    this.subs.push(
      this.chatService.getChat(this.chatId()).subscribe({
        next: (chat) => {
          this.messages.set(chat.messages ? [...chat.messages].reverse() : []);
          this.hasMoreMessages.set((chat.messages?.length ?? 0) === this.pageSize);

          const other = this.getOtherParticipant(chat);

          if (other) {
            const currentOther = this.otherUser();
            if (currentOther && currentOther.userId === other.userId) {
              other.isOnline = currentOther.isOnline;
            }
          }

          this.otherUser.set(other);
          this.isLoading.set(false);
          this.markAsRead();
        },
        error: (err) => {
          console.error('Failed to load chat:', err);
          this.error.set('Failed to load conversation');
          this.isLoading.set(false);
        }
      })
    );
  }

  loadMoreMessages(): void {
    if (this.isLoadingMore() || !this.hasMoreMessages()) return;
    this.isLoadingMore.set(true);
    this.currentPage.update(p => p + 1);

    this.subs.push(
      this.chatService.getMessages(this.chatId(), this.currentPage(), this.pageSize).subscribe({
        next: (older) => {
          const reversed = [...older].reverse();
          this.messages.update(m => [...reversed, ...m]);
          this.hasMoreMessages.set(older.length === this.pageSize);
          this.isLoadingMore.set(false);
        },
        error: (err) => {
          console.error('Failed to load more messages:', err);
          this.isLoadingMore.set(false);
          this.currentPage.update(p => p - 1);
        }
      })
    );
  }

  // ── SignalR ───────────────────────────────────────────────────────────────
  private initializeSignalR(): void {
    const token = this.accountService.currentUser()?.token;
    if (!token) { console.error('No auth token'); return; }

    this.signalRService.startConnection(token)
      .then(() => this.signalRService.joinChat(this.chatId()))
      .catch(err => console.error('SignalR connection failed:', err));

    this.subs.push(
      this.signalRService.connectionState$.subscribe(s => this.isConnected.set(s))
    );

    this.subs.push(
      this.signalRService.messageReceived$.subscribe((msg: Message) => {
        if (msg.chatId !== this.chatId()) return;
        const dto: MessageDto = {
          id: crypto.randomUUID(),
          content: msg.content,
          sentAt: msg.timestamp || new Date(),
          editedAt: null,
          wasEdited: false,
          senderId: msg.senderId,
          sendersUsername: msg.senderId === this.currentUserId()
            ? 'You'
            : (this.otherUser()?.username || 'User'),
          isRead: false
        };
        this.messages.update(m => [...m, dto]);
      })
    );

    this.subs.push(
      this.signalRService.userTyping$.subscribe((e: TypingEvent) => {
        if (e.chatId === this.chatId() && e.userId !== this.currentUserId()) {
          this.otherUserIsTyping.set(true);
        }
      })
    );

    this.subs.push(
      this.signalRService.userStoppedTyping$.subscribe((e: TypingEvent) => {
        if (e.chatId === this.chatId() && e.userId !== this.currentUserId()) {
          this.otherUserIsTyping.set(false);
        }
      })
    );

    this.subs.push(
      this.signalRService.sendMessageError$.subscribe(err => {
        console.error('Send error:', err);
        this.error.set('Failed to send message. Please try again.');
        this.isSending.set(false);
      })
    );

    this.subs.push(
      this.signalRService.contactPresenceChanged$.subscribe((e: PresenceEvent) => {
        const other = this.otherUser();
        if (other && String(e.userId) === other.userId) {
          this.otherUser.set({ ...other, isOnline: e.isOnline });
        }
      })
    );

    this.subs.push(
      this.signalRService.initialOnlineContacts$.subscribe(onlineIds => {
        const other = this.otherUser();
        if (other && onlineIds.includes(other.userId)) {
          this.otherUser.set({ ...other, isOnline: true });
        }
      })
    );

    this.subs.push(
      this.signalRService.messagesRead$.subscribe(({ chatId, readerId }) => {
        if (chatId !== this.chatId() || readerId === this.currentUserId()) return;
        this.messages.update(msgs =>
          msgs.map(m => m.senderId === this.currentUserId() ? { ...m, isRead: true } : m)
        );
      })
    );
  }

  // ── Outputs from children ─────────────────────────────────────────────────
  async onSendMessage(text: string): Promise<void> {
    const recipient = this.otherUser();
    if (!text.trim() || !this.chatId() || !this.currentUserId() || !recipient || !this.isConnected()) return;

    this.isSending.set(true);
    try {
      await this.signalRService.sendMessage(this.chatId(), recipient.userId, text.trim());
      this.stopTypingIndicator();
    } catch (err) {
      console.error('Send failed:', err);
      this.error.set('Failed to send message');
    } finally {
      this.isSending.set(false);
    }
  }

  onTypingStarted(): void {
    if (!this.isConnected()) return;
    if (!this.isTyping) {
      this.isTyping = true;
      this.signalRService.sendTypingIndicator(this.chatId());
    }
    if (this.typingTimeout) clearTimeout(this.typingTimeout);
    this.typingTimeout = setTimeout(() => this.stopTypingIndicator(), 2000);
  }

  private stopTypingIndicator(): void {
    if (this.isTyping && this.isConnected()) {
      this.isTyping = false;
      this.signalRService.stopTypingIndicator(this.chatId());
    }
    if (this.typingTimeout) clearTimeout(this.typingTimeout);
  }

  private markAsRead(): void {
    this.chatService.markAsRead(this.chatId()).subscribe({
      error: (err) => console.error('Failed to mark as read:', err)
    });
  }

  private getOtherParticipant(chat: ChatWithMessageDto): ChatUserDto | null {
    if (!chat?.participants || !this.currentUserId()) return null;
    return chat.participants.find(p => p.userId !== this.currentUserId()) ?? null;
  }

  dismissError(): void { this.error.set(null); }
}
