import {Component, EventEmitter, Input, Output} from '@angular/core';
import {FormsModule} from "@angular/forms";
import {NgIf} from "@angular/common";

@Component({
  selector: 'app-chat-list-header',
  imports: [
    FormsModule,
    NgIf
  ],
  templateUrl: './chat-list-header.component.html',
  styleUrl: './chat-list-header.component.css'
})
export class ChatListHeaderComponent {
  @Input() isLoading = false;
  @Input() searchTerm = '';
  @Output() searchTermChange = new EventEmitter<string>();
  @Output() refresh = new EventEmitter<void>();

  clearSearch(): void {
    this.searchTermChange.emit('');
  }
}
