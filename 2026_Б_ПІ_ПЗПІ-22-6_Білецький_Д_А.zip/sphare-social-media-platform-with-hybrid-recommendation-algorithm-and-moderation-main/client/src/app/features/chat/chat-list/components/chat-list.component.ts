import { Component, inject, OnDestroy, OnInit } from '@angular/core';
import { ChatService } from '../../../../_services/chatting/chat.service';
import { AccountService } from '../../../auth/services/account.service';
import { ChatDto } from '../../../../_models/chatting/chatDto';
import { Subscription } from 'rxjs';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';
import { FormsModule } from '@angular/forms';
import {ChatListHeaderComponent} from "./chat-list-header/chat-list-header.component";
import {ChatListStateComponent} from "./chat-list-state/chat-list-state.component";
import {ChatItemComponent} from "./chat-item/chat-item.component";

@Component({
  selector: 'app-chat-list',
  standalone: true,
  imports: [CommonModule, RouterModule, FormsModule, ChatListHeaderComponent, ChatListStateComponent, ChatItemComponent],
  templateUrl: './chat-list.component.html',
  styleUrl: './chat-list.component.css'
})
export class ChatListComponent implements OnInit, OnDestroy {
  private chatService = inject(ChatService);
  private accountService = inject(AccountService);
  private subscription?: Subscription;

  chats: ChatDto[] = [];
  filteredChats: ChatDto[] = [];
  currentUserId: string | null = null;

  isLoading = false;
  error: string | null = null;
  searchTerm = '';

  ngOnInit(): void {
    this.currentUserId = this.accountService.currentUser()?.userId ?? null;
    this.loadChats();
  }

  ngOnDestroy(): void {
    this.subscription?.unsubscribe();
  }

  loadChats(): void {
    this.isLoading = true;
    this.error = null;

    this.subscription = this.chatService.getChats().subscribe({
      next: (chats) => {
        this.chats = chats;
        this.applyFilter();
        this.isLoading = false;
      },
      error: (err) => {
        console.error('Error loading chats:', err);
        this.error = 'Failed to load chats. Please try again.';
        this.isLoading = false;
      }
    });
  }

  onSearchTermChange(term: string): void {
    this.searchTerm = term;
    this.applyFilter();
  }

  get hasUnreadChats(): boolean {
    return this.filteredChats.some(chat => chat.unreadCount > 0);
  }

  trackByChatId(_index: number, chat: ChatDto): string {
    return chat.id;
  }

  private applyFilter(): void {
    const term = this.searchTerm.toLowerCase().trim();
    this.filteredChats = term
      ? this.chats.filter(chat => this.matchesSearch(chat, term))
      : this.chats;
  }

  private matchesSearch(chat: ChatDto, term: string): boolean {
    const other = chat.participants?.find(p => p.userId !== this.currentUserId);
    return !!other?.username?.toLowerCase().includes(term) ||
      !!other?.uniqueNameIdentifier?.toLowerCase().includes(term) ||
      !!chat.lastMessage?.toLowerCase().includes(term);
  }
}
