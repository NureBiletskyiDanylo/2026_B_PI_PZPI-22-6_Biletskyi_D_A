import {Component, Input} from '@angular/core';
import {ChatUserDto} from "../../../../../_models/chatting/chatUserDto";
import {ChatDto} from "../../../../../_models/chatting/chatDto";
import {RouterLink, RouterLinkActive} from "@angular/router";
import {NgIf} from "@angular/common";

@Component({
  selector: 'app-chat-item',
  imports: [
    RouterLink,
    RouterLinkActive,
    NgIf
  ],
  templateUrl: './chat-item.component.html',
  styleUrl: './chat-item.component.css'
})
export class ChatItemComponent {
  @Input({ required: true }) chat!: ChatDto;
  @Input() currentUserId: string | null = null;

  get otherUser(): ChatUserDto | undefined {
    return this.chat.participants?.find(p => p.userId !== this.currentUserId);
  }

  get initials(): string {
    const name = this.otherUser?.username || 'User';
    return name.split(' ').map(p => p[0]).join('').toUpperCase().substring(0, 2);
  }

  get lastMessageTime(): string {
    return 'Just now';
  }
}
