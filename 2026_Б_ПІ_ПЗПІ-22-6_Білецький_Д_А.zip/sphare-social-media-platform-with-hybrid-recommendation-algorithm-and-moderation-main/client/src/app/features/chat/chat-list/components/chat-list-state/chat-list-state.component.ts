import {Component, EventEmitter, Input, Output} from '@angular/core';
import {NgSwitch, NgSwitchCase} from "@angular/common";
import {RouterLink} from "@angular/router";
export type ChatListStateType = 'loading' | 'error' | 'empty' | 'no-results';

@Component({
  selector: 'app-chat-list-state',
  imports: [
    NgSwitchCase,
    RouterLink,
    NgSwitch
  ],
  templateUrl: './chat-list-state.component.html',
  styleUrl: './chat-list-state.component.css'
})
export class ChatListStateComponent {
  @Input({ required: true }) type!: ChatListStateType;
  @Input() errorMessage: string | null = null;
  @Input() searchTerm = '';
  @Output() retry = new EventEmitter<void>();
  @Output() clearSearch = new EventEmitter<void>();
}
