import {inject, Injectable} from '@angular/core';
import {HttpClient} from "@angular/common/http";
import {environment} from "../../../../../../environments/environment";

@Injectable({
  providedIn: 'root'
})
export class SettingsService {
  private http = inject(HttpClient);
  baseUrl = environment.apiUrl;

  updateProfanityFilter(isEnabled: boolean) {
    return this.http.post<{ profanityFilter: boolean }>(
      `${this.baseUrl}/publicuser/settings/profanity`,
      { profanityFilter: isEnabled }
    );
  }
  constructor() { }
}
