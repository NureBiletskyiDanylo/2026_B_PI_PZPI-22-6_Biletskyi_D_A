import {Component, computed, inject, signal} from '@angular/core';
import {SettingsService} from "../services/settings.service";
import {AccountService} from "../../../../auth/services/account.service";

@Component({
  selector: 'app-settings-page',
  imports: [],
  templateUrl: './settings-page.component.html',
  styleUrl: './settings-page.component.css'
})
export class SettingsPageComponent {
  private accountService = inject(AccountService);
  private settingsService = inject(SettingsService);

  isProfanityFilterEnabled = computed(() => this.accountService.currentUser()?.profanityFilter ?? true);

  isMfaEnabled = signal<boolean>(false);
  isSaving = signal<boolean>(false);

  toggleProfanityFilter(): void {
    const currentValue = this.isProfanityFilterEnabled();
    const newValue = !currentValue;

    this.isSaving.set(true);

    this.settingsService.updateProfanityFilter(newValue).subscribe({
      next: () => {
        this.accountService.updateUserFilterSetting(newValue);
        this.isSaving.set(false);
      },
      error: (err) => {
        console.error('Failed to update profanity filter settings:', err);
        this.isSaving.set(false);
      }
    });
  }

  toggleMfaMock(): void {
    this.isMfaEnabled.update(val => !val);
  }
}
