import {Component, inject, OnInit, signal, viewChild} from '@angular/core';
import {SidebarComponent} from "./sidebar/sidebar.component";
import {UserProfileService} from "../services/user-profile.service";
import {UserDto} from "../models/user.dto";
import {ActivatedRoute} from "@angular/router";
import {AccountService} from "../../../auth/services/account.service";
import {
  PublicationCardListComponent
} from "../../../publication/publication-card-list/components/publication-card-list.component";
import {
  PublicationCreateComponent
} from "../../../publication/publication-create/components/publication-create.component";
import {
  RecommendationListComponent
} from "../../../recommendation/recommendation-list/components/recommendation-list.component";
type FeedTab = 'publications' | 'recommendations' | 'other';
@Component({
  selector: 'app-profile-page',
  imports: [
    SidebarComponent,
    PublicationCardListComponent,
    PublicationCreateComponent,
    RecommendationListComponent
  ],
  templateUrl: './profile-page.component.html',
  styleUrl: './profile-page.component.css'
})
export class ProfilePageComponent implements OnInit {
  private userProfileService: UserProfileService = inject(UserProfileService);
  private accountService: AccountService = inject(AccountService);
  private route = inject(ActivatedRoute);
  userProfile: UserDto | null = null;
  subscriptionsCount: number = 0;
  followersCount: number = 0;
  isFollowing = false;
  currentUNI: string | null = null;
  publicationCardList = viewChild(PublicationCardListComponent);
  activeTab = signal<FeedTab>('publications');

  ngOnInit(): void {
    this.route.params.subscribe(params => {
      const uniqueNameIdentifier = params['uNI'];
      if (uniqueNameIdentifier) {
        this.currentUNI = uniqueNameIdentifier;

        this.loadProfile(uniqueNameIdentifier);
        this.loadFollowers(uniqueNameIdentifier);
        this.loadSubscriptions(uniqueNameIdentifier);

        if (this.accountService.currentUser() && !this.userProfile?.isOwner) {
          this.isFollowingFn(uniqueNameIdentifier);
        }
      }
      else {
        console.error("No profile loaded since no UNI given")
      }
    })
  }

  loadProfile(uNI: string) {
    this.userProfileService.getProfile(uNI).subscribe({
      next: (profile) => {
        this.userProfile = profile;
      },
      error: (error) => {
        console.error(error);
      }
    })
  }

  loadSubscriptions(uNI: string) {
    this.userProfileService.getSubscriptionsCount(uNI).subscribe({
      next: (subscriptions) => {
        this.subscriptionsCount = subscriptions;
      },
      error: (error) => {
        console.error(error);
      }
    })
  }


  loadFollowers(uNI: string) {
    this.userProfileService.getFollowersCount(uNI).subscribe({
      next: (followers) => {
        this.followersCount = followers;
      },
      error: (error) => {
        console.error(error);
      }
    })
  }

  isFollowingFn(uNI: string) {
    this.userProfileService.isFollowing(uNI).subscribe(isFollowing => {
        this.isFollowing = isFollowing;
      },
      error => {
        console.error(error);
      })
  }

  onPublicationCreated(): void {
    if (this.currentUNI) {
      this.publicationCardList()?.loadPublications(this.currentUNI);
    }
  }

  setTab(tab: FeedTab): void {
    this.activeTab.set(tab);
  }

  get isProfileOwner(): boolean {
    return this.currentUNI === this.accountService.currentUser()?.uniqueNameIdentifier;
  }
}
