import {inject, Injectable} from '@angular/core';
import {HttpClient} from "@angular/common/http";
import {environment} from "../../../../../environments/environment";
import {Observable} from "rxjs";
import {ChatDto} from "../../../../_models/chatting/chatDto";

@Injectable({
  providedIn: 'root'
})
export class StartChatService {
  private http = inject(HttpClient);
  baseUrl = environment.apiUrl;

  startChat(otherUserId: string): Observable<ChatDto> {
    return this.http.post<ChatDto>(`${this.baseUrl}/chatRq/start`, { otherUserId });
  }
  constructor() { }
}
