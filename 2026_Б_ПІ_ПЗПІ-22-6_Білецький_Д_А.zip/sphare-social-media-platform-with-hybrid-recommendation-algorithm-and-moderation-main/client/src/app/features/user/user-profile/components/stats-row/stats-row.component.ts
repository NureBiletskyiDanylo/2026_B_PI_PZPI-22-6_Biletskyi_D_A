import {Component, Input} from '@angular/core';

@Component({
  selector: 'app-stats-row',
  imports: [],
  templateUrl: './stats-row.component.html',
  styleUrl: './stats-row.component.css'
})
export class StatsRowComponent {
  @Input() followingCount: number = 0;
  @Input() followersCount: number = 0;
}
