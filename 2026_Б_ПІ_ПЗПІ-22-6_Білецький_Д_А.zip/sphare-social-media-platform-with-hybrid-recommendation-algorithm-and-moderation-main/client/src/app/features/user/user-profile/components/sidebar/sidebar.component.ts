import {Component, inject, Input} from '@angular/core';
import {UserDto} from "../../models/user.dto";
import {AvatarComponent} from "../avatar/avatar.component";
import {IdentityComponent} from "../identity/identity.component";
import {StatsRowComponent} from "../stats-row/stats-row.component";
import {ProfileActivityBtnComponent} from "../profile-activity-btn/profile-activity-btn.component";
import {UserProfileService} from "../../services/user-profile.service";
import {Router} from "@angular/router";
import {AdditionaInfoComponent} from "../additiona-info/additiona-info.component";
import {InterestsComponent} from "../interests/interests.component";
import {StartChatService} from "../../services/start-chat.service";
import {ChatDto} from "../../../../../_models/chatting/chatDto";
import {CommonModule} from "@angular/common";

@Component({
  selector: 'app-sidebar',
  imports: [
    AvatarComponent,
    CommonModule,
    IdentityComponent,
    StatsRowComponent,
    ProfileActivityBtnComponent,
    AdditionaInfoComponent,
    InterestsComponent
  ],
  templateUrl: './sidebar.component.html',
  styleUrl: './sidebar.component.css'
})
export class SidebarComponent {
  private userProfileService: UserProfileService = inject(UserProfileService);
  private chatService: StartChatService = inject(StartChatService);
  private router: Router = inject(Router);
  @Input() userProfile!: UserDto | null;
  @Input() followersCount: number = 0;
  @Input() followingCount: number = 0;
  @Input() isFollowing: boolean = false;

  toggleFollow() {
    if (!this.isFollowing) {
      this.userProfileService.subscribe(this.userProfile?.uniqueNameIdentifier!)
        .subscribe(() => {
          this.isFollowing = true;
          console.log("User profile was subscribed!");
        }, error => {
          console.log(error);
        })
    }
    else {
      this.userProfileService.unsubscribe(this.userProfile?.uniqueNameIdentifier!)
        .subscribe(() => {
          this.isFollowing = false;
          console.log("User profile was unsubscribed!");
        }, error => {
          console.log(error);
        })
    }
  }

  goToEditPage() {
    this.router.navigate(['/edit-profile']);
  }

  initiateConversation() {
    const targetId = this.userProfile?.id || this.userProfile?.id;
    if (!targetId) {
      console.warn('Cannot initiate chat: userProfile identifier is missing.');
      return;
    }

    this.chatService.startChat(targetId).subscribe({
      next: (chatRoom: ChatDto) => {
        this.router.navigate(['/chat', chatRoom.id]);
      },
      error: (err) => {
        console.error('Failed to initialize workspace conversation room', err);
      }
    });
  }

  onOpenSettings() {
    this.router.navigate(['/settings']);
  }
}
