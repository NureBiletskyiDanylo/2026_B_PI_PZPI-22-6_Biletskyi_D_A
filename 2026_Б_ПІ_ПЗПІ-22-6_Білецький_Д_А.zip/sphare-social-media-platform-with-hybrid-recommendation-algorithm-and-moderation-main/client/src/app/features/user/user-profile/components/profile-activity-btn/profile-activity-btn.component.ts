import {Component, EventEmitter, Input, Output} from '@angular/core';

@Component({
  selector: 'app-profile-activity-btn',
  imports: [],
  templateUrl: './profile-activity-btn.component.html',
  styleUrl: './profile-activity-btn.component.css'
})
export class ProfileActivityBtnComponent {
  @Input() isOwner: boolean = false;
  @Input() isFollowing: boolean = false;

  @Output() editProfile = new EventEmitter<void>();
  @Output() openSettings = new EventEmitter<void>();
  @Output() toggleFollow = new EventEmitter<void>();
  @Output() report = new EventEmitter<void>();
}
