import { Component, Input } from '@angular/core';

@Component({
  selector: 'app-address',
  standalone: true,
  imports: [],
  templateUrl: './address.component.html',
  styleUrl: './address.component.css'
})
export class AddressComponent {
  @Input() city: string | null = null;
  @Input() country: string | null = null;

  get location(): string {
    return [this.city, this.country].filter(Boolean).join(', ');
  }
}
