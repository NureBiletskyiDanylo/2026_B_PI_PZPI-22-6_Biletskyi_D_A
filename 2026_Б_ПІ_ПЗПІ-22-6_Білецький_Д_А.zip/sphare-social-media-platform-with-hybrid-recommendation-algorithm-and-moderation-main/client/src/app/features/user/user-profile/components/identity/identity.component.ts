import {Component, Input} from '@angular/core';
import {DatePipe} from "@angular/common";

@Component({
  selector: 'app-identity',
  imports: [
    DatePipe
  ],
  templateUrl: './identity.component.html',
  styleUrl: './identity.component.css'
})
export class IdentityComponent {
  @Input() username: string = '';
  @Input() uni: string = '';
  @Input() joined: string = '';
}
