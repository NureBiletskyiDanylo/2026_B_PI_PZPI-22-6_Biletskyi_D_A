import {inject, Injectable} from '@angular/core';
import {HttpClient, HttpHeaders} from "@angular/common/http";
import {environment} from "../../../../../environments/environment";
import {UserDto} from "../models/user.dto";

@Injectable({
  providedIn: 'root'
})
export class UserProfileService {
  private http = inject(HttpClient);
  baseUrl = environment.apiUrl;

  getProfile(uNI: string) {
    return this.http.get<UserDto>(this.baseUrl + '/publicUser/by-uni', {params: {uNI}});
  }

  getFollowersCount(uNI: string) {
    return this.http.get<number>(`${this.baseUrl}/subscription/followers-count`, {
      params: { uniqueNameIdentifier: uNI }
    });
  }

  getSubscriptionsCount(uNI: string) {
    return this.http.get<number>(`${this.baseUrl}/subscription/subscriptions-count`, {
      params: { uniqueNameIdentifier: uNI }
    });
  }

  isFollowing(uNI: string) {
    return this.http.get<boolean>(`${this.baseUrl}/subscription/is-following`, {
      params: { uniqueNameIdentifier: uNI }
    });
  }

  subscribe(uNI: string) {
    const headers = new HttpHeaders({ 'Content-Type': 'application/json' });
    return this.http.post(this.baseUrl + '/subscription/subscribe', JSON.stringify(uNI), { headers });
  }

  unsubscribe(uNI: string) {
    const headers = new HttpHeaders({ 'Content-Type': 'application/json' });
    return this.http.post(this.baseUrl + '/subscription/unsubscribe', JSON.stringify(uNI), { headers });
  }

  constructor() { }
}
