import {Component, Input} from '@angular/core';
import {DatePipe} from "@angular/common";
import {AddressComponent} from "../address/address.component";

@Component({
  selector: 'app-additiona-info',
  imports: [
    DatePipe,
    AddressComponent
  ],
  templateUrl: './additiona-info.component.html',
  styleUrl: './additiona-info.component.css'
})
export class AdditionaInfoComponent {
  @Input() pronouns: string = '';
  @Input() description: string = '';
  @Input() dateOfBirth: string = '';
  @Input() city: string | null = null;
  @Input() country: string | null = null;
}
