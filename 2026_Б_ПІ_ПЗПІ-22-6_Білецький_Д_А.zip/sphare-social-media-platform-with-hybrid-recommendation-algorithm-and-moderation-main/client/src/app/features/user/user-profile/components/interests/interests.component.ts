import { Component, Input } from '@angular/core';
import {NgStyle} from "@angular/common";

@Component({
  selector: 'app-interests',
  standalone: true,
  imports: [
    NgStyle
  ],
  templateUrl: './interests.component.html',
  styleUrl: './interests.component.css'
})
export class InterestsComponent {
  @Input() interests: string[] = [];

  private readonly pastelPalette: { bg: string; text: string }[] = [
    { bg: '#fde8e8', text: '#c0392b' },
    { bg: '#fdebd0', text: '#c0732b' },
    { bg: '#fdf6d3', text: '#a08020' },
    { bg: '#e8f8e8', text: '#27ae60' },
    { bg: '#d4f1f4', text: '#1a7f8a' },
    { bg: '#ddeeff', text: '#2260c4' },
    { bg: '#e8e0fd', text: '#6c3ac0' },
    { bg: '#fde8f6', text: '#b0309a' },
    { bg: '#e0f5e9', text: '#1e8449' },
    { bg: '#fff0d4', text: '#c47a1a' },
    { bg: '#ffe8f0', text: '#c0306a' },
    { bg: '#e8f0fe', text: '#2851c4' },
    { bg: '#f0fde8', text: '#4a8a20' },
    { bg: '#fde8d4', text: '#b05a1a' },
    { bg: '#f4e8fd', text: '#8a30c0' },
    { bg: '#e8fdfa', text: '#1a9a80' },
    { bg: '#fdf0e8', text: '#c06030' },
    { bg: '#eefde8', text: '#3a9a20' },
    { bg: '#e8eafd', text: '#3040c0' },
    { bg: '#fde8ea', text: '#c02030' },
  ];

  getColor(index: number): { bg: string; text: string } {
    return this.pastelPalette[index % this.pastelPalette.length];
  }
}
