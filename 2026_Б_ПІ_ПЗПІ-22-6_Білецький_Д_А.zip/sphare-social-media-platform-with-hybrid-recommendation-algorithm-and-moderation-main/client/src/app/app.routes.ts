import { Routes } from '@angular/router';
import { LoginComponent } from './features/auth/login/components/login.component';
import { RegisterComponent } from './features/auth/register/components/register.component';
import { SearchPageComponent } from './search/search-page/search-page.component';
import { AdminPanelComponent } from './admin/admin-panel/admin-panel.component';
import { AdminUserListComponent } from './admin/admin-user-list/admin-user-list.component';
import { AdminViolationsComponent } from './admin/admin-violations/admin-violations.component';
import { PasswordResetComponent } from './features/auth/password-reset/components/password-reset.component';
import {HomeComponent} from "./home/home/home.component";
import { ComplaintsListComponent } from './complaint/complaints-list-component/complaints-list-component.component';
import { PrivateChatComponent } from './features/chat/chat/components/private-chat.component';
import { ChatListComponent } from './features/chat/chat-list/components/chat-list.component';
import { CalendarPageComponent } from './features/publication/calendar-page/components/calendar-page.component';
import { authGuard } from './_guards/auth.guard';
import {EditUserPageComponent} from "./features/user/edit-user/components/edit-user-page.component";
import {ProfilePageComponent} from "./features/user/user-profile/components/profile-page.component";
import {PublicationPageComponent} from "./features/publication/publication-page/components/publication-page.component";
import {CommentPageComponent} from "./features/comment/comment-page/components/comment-page.component";
import {SettingsPageComponent} from "./features/user/settings/settings-page/components/settings-page.component";

export const routes: Routes = [
    // Public routes — no guard
    { path: 'login', component: LoginComponent },
    { path: 'register', component: RegisterComponent },
    { path: 'password-reset', component: PasswordResetComponent },

    // Protected routes
    { path: '', component: HomeComponent, canActivate: [authGuard] },
  {path: 'profile/:uNI', component: ProfilePageComponent, canActivate: [authGuard] },
    { path: 'edit-profile', component: EditUserPageComponent, canActivate: [authGuard] },
    { path: 'publication/:id', component: PublicationPageComponent, canActivate: [authGuard] },
    { path: 'publications/calendar', component: CalendarPageComponent, canActivate: [authGuard] },
    { path: 'search', component: SearchPageComponent, canActivate: [authGuard] },
    { path: 'admin-panel', component: AdminPanelComponent, canActivate: [authGuard] },
    { path: 'admin/user-list', component: AdminUserListComponent, canActivate: [authGuard] },
    { path: 'admin/violation-list/:userId', component: AdminViolationsComponent, canActivate: [authGuard] },
    { path: 'admin/complaints', component: ComplaintsListComponent, canActivate: [authGuard] },
    { path: 'comment/:id', component: CommentPageComponent, canActivate: [authGuard] },
    { path: 'chats', component: ChatListComponent, canActivate: [authGuard] },
    { path: 'chat/:id', component: PrivateChatComponent, canActivate: [authGuard] },
    {path: 'settings', component: SettingsPageComponent, canActivate: [authGuard] },
];
