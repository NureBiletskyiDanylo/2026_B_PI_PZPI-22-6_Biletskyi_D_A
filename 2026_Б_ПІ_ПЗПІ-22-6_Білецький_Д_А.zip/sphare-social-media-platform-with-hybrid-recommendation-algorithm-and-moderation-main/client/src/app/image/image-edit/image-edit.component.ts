import { CommonModule } from '@angular/common';
import {
  ChangeDetectorRef,
  Component,
  EventEmitter,
  inject,
  Input,
  OnChanges,
  Output,
  SimpleChanges,
  ViewChild
} from '@angular/core';
import { ImageCroppedEvent, ImageCropperComponent } from 'ngx-image-cropper';
import {ImageDrawerComponent} from "../../shared/components/image-drawer/image-drawer.component";

@Component({
  selector: 'app-image-edit',
  standalone: true,
  imports: [ImageCropperComponent, CommonModule, ImageDrawerComponent],
  templateUrl: './image-edit.component.html',
  styleUrl: './image-edit.component.css'
})
export class ImageEditComponent implements OnChanges{
  @Input() file: File | undefined;
  @Input() index: number = 0;
  @Output() cropApplied = new EventEmitter<{croppedFile: File; preview: string; index: number}>();
  @Output() cropCancelled = new EventEmitter<void>();
  @Output() close = new EventEmitter<void>();

  @ViewChild('imageDrawer') imageDrawer!: ImageDrawerComponent;

  private cdr = inject(ChangeDetectorRef);

  mode: 'crop' | 'draw' = 'crop';

  backgroundImageBase64: string | null = null;
  drawingImageSrc: string | null = null;
  latestCroppedBase64: string | null = null;

  cropperSetupPosition: any = null;

  lastImagePosition: any = null;
  lastCropperPosition: any = null;

  private savedCropperPosition: any = null;
  private savedImagePosition: any = null;

  ngOnChanges(changes: SimpleChanges): void {
    if (changes['file'] && this.file) {
      this.mode = 'crop';
      this.initiateCropping(this.file);
    }
  }

  private initiateCropping(file: File): void {
    const reader = new FileReader();
    reader.onload = () => {
      this.backgroundImageBase64 = reader.result as string;
      this.latestCroppedBase64 = this.backgroundImageBase64;
      this.lastImagePosition = null;
      this.lastCropperPosition = null;
      this.cropperSetupPosition = null;
      this.savedCropperPosition = null;
      this.savedImagePosition = null;
      this.cdr.detectChanges();
    };
    reader.readAsDataURL(file);
  }

  imageCropped(event: ImageCroppedEvent): void {
    this.lastImagePosition = event.imagePosition;
    this.lastCropperPosition = event.cropperPosition;

    if (event.base64) {
      this.latestCroppedBase64 = event.base64;
      this.cdr.detectChanges();
    } else if (event.blob) {
      const reader = new FileReader();
      reader.onload = () => {
        this.latestCroppedBase64 = reader.result as string;
        this.cdr.detectChanges();
      };
      reader.readAsDataURL(event.blob);
    }
  }

  switchToDraw(): void {
    if (this.latestCroppedBase64) {
      this.drawingImageSrc = this.latestCroppedBase64;

      this.savedCropperPosition = this.lastCropperPosition;
      this.savedImagePosition = this.lastImagePosition;
    }
    this.mode = 'draw';
    this.cdr.detectChanges();
  }

  switchToCrop(): void {
    this.cropperSetupPosition = null;

    if (this.mode === 'draw' && this.imageDrawer && this.imageDrawer.undoHistory.length > 1) {
      const drawnSnapshot = this.imageDrawer.exportAsDataURL();

      const imgFull = new Image();
      imgFull.onload = () => {
        const canvas = document.createElement('canvas');
        canvas.width = imgFull.naturalWidth || imgFull.width;
        canvas.height = imgFull.naturalHeight || imgFull.height;
        const ctx = canvas.getContext('2d');

        if (ctx && this.savedImagePosition) {
          ctx.drawImage(imgFull, 0, 0);

          const imgCropped = new Image();
          imgCropped.onload = () => {
            const x = this.savedImagePosition.x1;
            const y = this.savedImagePosition.y1;
            const w = this.savedImagePosition.x2 - this.savedImagePosition.x1;
            const h = this.savedImagePosition.y2 - this.savedImagePosition.y1;

            ctx.drawImage(imgCropped, x, y, w, h);

            this.backgroundImageBase64 = canvas.toDataURL('image/jpeg', 0.95);
            this.mode = 'crop';
            this.cdr.detectChanges();
          };
          imgCropped.src = drawnSnapshot;
        }
      };
      imgFull.src = this.backgroundImageBase64!;
    } else {
      this.mode = 'crop';
      this.cdr.detectChanges();
    }
  }

  onCropperImageLoaded(): void {
    if (this.savedCropperPosition) {
      setTimeout(() => {
        this.cropperSetupPosition = { ...this.savedCropperPosition };
        this.cdr.detectChanges();
      }, 50);
    }
  }

  async applyCrop(): Promise<void> {
    if (!this.file) return;

    let finalBase64 = '';
    if (this.mode === 'draw' && this.imageDrawer) {
      finalBase64 = this.imageDrawer.exportAsDataURL();
    } else if (this.mode === 'crop' && this.latestCroppedBase64) {
      finalBase64 = this.latestCroppedBase64;
    } else {
      finalBase64 = this.backgroundImageBase64 || '';
    }

    if (!finalBase64) return;

    try {
      const blob = await fetch(finalBase64).then(res => res.blob());
      const finalFile = new File([blob], this.file.name, { type: 'image/jpeg', lastModified: Date.now() });

      this.cropApplied.emit({
        croppedFile: finalFile,
        preview: finalBase64,
        index: this.index
      });
      this.resetCropper();
      this.close.emit();
    } catch (error) {
      console.error('Error applying final image adjustments:', error);
      this.cancelCrop();
    }
  }

  cancelCrop(): void {
    this.resetCropper();
    this.cropCancelled.emit();
    this.close.emit();
  }

  private resetCropper(): void {
    this.backgroundImageBase64 = null;
    this.drawingImageSrc = null;
    this.latestCroppedBase64 = null;
    this.lastImagePosition = null;
    this.lastCropperPosition = null;
    this.cropperSetupPosition = null;
    this.savedCropperPosition = null;
    this.savedImagePosition = null;
    this.mode = 'crop';
  }
}
