import { HttpClient } from '@angular/common/http';
import { inject, Injectable } from '@angular/core';
import { environment } from '../../environments/environment.js';
import { MemberModel } from '../_models/user/memberModel.js';
import { UpdateMemberModel } from '../_models/user/updateMemberModel.js';

@Injectable({
  providedIn: 'root'
})
export class MemberService {
  private http = inject(HttpClient);
  baseUrl = environment.apiUrl;

  searchForUser(searchQuery: string){
    return this.http.get<MemberModel[]>(this.baseUrl + '/publicUser/user-search', { params: { searchQuery } });
  }

  constructor() { }
}

