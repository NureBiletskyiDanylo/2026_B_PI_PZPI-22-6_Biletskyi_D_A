import { HttpClient } from '@angular/common/http';
import { inject, Injectable } from '@angular/core';
import { environment } from '../../environments/environment';
import { CreateComplaintDto } from '../features/complaint/create-complaint/models/create-complaint.dto';
import { PublicationComplaintModel } from '../_models/complaints/publicationComplaintModel';
import { CommentComplaintModel } from '../_models/complaints/commentComplaintModel';
import { GroupPublicationComplaintModel } from '../_models/complaints/groupPublicationComplaintModel';

@Injectable({
  providedIn: 'root'
})
export class ComplaintService {
  private http = inject(HttpClient)
  private baseUrl = environment.apiUrl

  getPublicationComplaints() {
    return this.http.get<PublicationComplaintModel[]>(`${this.baseUrl}/complaint/publication`)
  }

  getCommentComplaints() {
    return this.http.get<CommentComplaintModel[]>(`${this.baseUrl}/complaint/comment`)
  }

  getPublicationGroupedComplaints() {
    return this.http.get<GroupPublicationComplaintModel[]>(`${this.baseUrl}/complaint/publication-grouped`)
  }

  constructor() { }
}
