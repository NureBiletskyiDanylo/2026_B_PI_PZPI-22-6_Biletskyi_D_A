import { MemberModel } from "./user/memberModel";

export interface CommentModel {
    id: string;
    content: string;
    author: MemberModel;
    publicationId: string;
    creationDate: Date;
    isDeleted: boolean;
    repliesAmount: number;
}
