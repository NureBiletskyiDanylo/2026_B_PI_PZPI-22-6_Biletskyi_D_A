import {Component, input, output} from '@angular/core';

@Component({
  selector: 'app-custom-button',
  imports: [],
  templateUrl: './custom-button.component.html',
  styleUrl: './custom-button.component.css'
})
export class CustomButtonComponent {
  label = input<string>('Button');
  type = input<'button' | 'submit' | 'reset'>('button');
  disabled = input<boolean>(false);

  // Colors
  bgColor = input<string>('#f3f7fe');
  textColor = input<string>('#3b82f6');
  hoverBgColor = input<string>('#3b82f6');
  hoverTextColor = input<string>('#ffffff');
  glowColor = input<string>('rgba(59, 130, 246, 0.37)');

  // Size
  width = input<string>('100px');
  height = input<string>('45px');
  borderRadius = input<string>('8px');
  fontSize = input<string>('1rem');

  clicked = output<void>();

  onClick(): void {
    if (!this.disabled()) this.clicked.emit();
  }
}
