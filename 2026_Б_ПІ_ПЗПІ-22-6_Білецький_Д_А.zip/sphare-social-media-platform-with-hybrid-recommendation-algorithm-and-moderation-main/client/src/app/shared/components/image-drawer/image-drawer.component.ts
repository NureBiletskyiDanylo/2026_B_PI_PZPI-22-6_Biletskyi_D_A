import {ChangeDetectorRef, Component, ElementRef, inject, Input, SimpleChanges, ViewChild} from '@angular/core';

@Component({
  selector: 'app-image-drawer',
  imports: [],
  templateUrl: './image-drawer.component.html',
  styleUrl: './image-drawer.component.css'
})
export class ImageDrawerComponent {
  @Input() src!: string;

  @ViewChild('drawingCanvas') canvasRef!: ElementRef<HTMLCanvasElement>;
  private cdr = inject(ChangeDetectorRef);

  isDrawing = false;
  currentColor = '#4caf50';
  brushSize = 4;
  undoHistory: ImageData[] = [];
  private ctx: CanvasRenderingContext2D | null = null;

  ngOnChanges(changes: SimpleChanges): void {
    if (changes['src'] && this.src) {
      this.undoHistory = [];
      setTimeout(() => this.initCanvas(), 50);
    }
  }

  private initCanvas(): void {
    if (!this.canvasRef || !this.src) return;
    const canvas = this.canvasRef.nativeElement;
    this.ctx = canvas.getContext('2d');

    const img = new Image();
    img.onload = () => {
      canvas.width = img.naturalWidth || img.width;
      canvas.height = img.naturalHeight || img.height;

      if (this.ctx) {
        this.ctx.drawImage(img, 0, 0);
        this.ctx.lineCap = 'round';
        this.ctx.lineJoin = 'round';
        this.undoHistory = [this.ctx.getImageData(0, 0, canvas.width, canvas.height)];
        this.cdr.detectChanges();
      }
    };
    img.src = this.src;
  }

  private getCoords(clientX: number, clientY: number) {
    const canvas = this.canvasRef.nativeElement;
    const rect = canvas.getBoundingClientRect();
    return {
      x: (clientX - rect.left) * (canvas.width / rect.width),
      y: (clientY - rect.top) * (canvas.height / rect.height)
    };
  }

  startDrawing(event: MouseEvent): void {
    if (!this.ctx) return;
    this.isDrawing = true;
    const coords = this.getCoords(event.clientX, event.clientY);
    this.ctx.beginPath();
    this.ctx.moveTo(coords.x, coords.y);
    this.ctx.strokeStyle = this.currentColor;
    this.ctx.lineWidth = this.brushSize;
  }

  draw(event: MouseEvent): void {
    if (!this.isDrawing || !this.ctx) return;
    const coords = this.getCoords(event.clientX, event.clientY);
    this.ctx.lineTo(coords.x, coords.y);
    this.ctx.stroke();
  }

  startDrawingTouch(event: TouchEvent): void {
    if (!this.ctx || event.touches.length === 0) return;
    event.preventDefault();
    this.isDrawing = true;
    const coords = this.getCoords(event.touches[0].clientX, event.touches[0].clientY);
    this.ctx.beginPath();
    this.ctx.moveTo(coords.x, coords.y);
    this.ctx.strokeStyle = this.currentColor;
    this.ctx.lineWidth = this.brushSize;
  }

  drawTouch(event: TouchEvent): void {
    if (!this.isDrawing || !this.ctx || event.touches.length === 0) return;
    event.preventDefault();
    const coords = this.getCoords(event.touches[0].clientX, event.touches[0].clientY);
    this.ctx.lineTo(coords.x, coords.y);
    this.ctx.stroke();
  }

  stopDrawing(): void {
    if (!this.isDrawing || !this.ctx) return;
    this.isDrawing = false;
    const canvas = this.canvasRef.nativeElement;
    this.undoHistory.push(this.ctx.getImageData(0, 0, canvas.width, canvas.height));
  }

  undoLastAction(): void {
    if (this.undoHistory.length > 1 && this.ctx) {
      this.undoHistory.pop();
      const previousState = this.undoHistory[this.undoHistory.length - 1];
      this.ctx.putImageData(previousState, 0, 0);
    }
  }

  changeColor(color: string): void {
    this.currentColor = color;
  }

  public exportAsDataURL(): string {
    if (!this.canvasRef) return this.src;
    return this.canvasRef.nativeElement.toDataURL('image/jpeg', 0.95);
  }
}
