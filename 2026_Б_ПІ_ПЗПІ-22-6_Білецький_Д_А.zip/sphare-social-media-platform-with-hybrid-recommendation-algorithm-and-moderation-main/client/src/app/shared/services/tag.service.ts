import {inject, Injectable} from '@angular/core';
import {HttpClient, HttpParams} from "@angular/common/http";
import {environment} from "../../../environments/environment";
import {GeneratedTagDto, TagDto} from "../models/tag.dto";

@Injectable({
  providedIn: 'root'
})
export class TagService {
  private http = inject(HttpClient);
  baseUrl = environment.apiUrl;

  saveSetTags(tags: GeneratedTagDto[], publicationId: string) {
    const params = new HttpParams().set('publicationId', publicationId);
    return this.http.post(this.baseUrl + '/tag/save-set-tags', tags, { params });
  }

  getTagsForPublication(publicationId: string) {
    return this.http.get<TagDto[]>(`${this.baseUrl}/tag/tags-publication`, {
      params: { publicationId }
    });
  }

  searchTags(searchName: string) {
    return this.http.get<TagDto[]>(`${this.baseUrl}/tag/tag-search`, {
      params: { searchName }
    });
  }

  removeTagPublication(publicationId: string, tagId: number){
    return this.http.delete(`${this.baseUrl}/tag/tag-publication/${publicationId}`, {
      params: {
        publicationId,
        tagId
      }
    })
  }

  getGeneratedTagsForUnsavedPublication(content: string) {
    return this.http.get<GeneratedTagDto[]>(
      `${this.baseUrl}/tag/generate-tags/unsaved-publication`,
      {
        params: { content }
      }
    );
  }

  syncTags(publicationId: string, tagNames: string[]) {
    const params = new HttpParams().set('publicationId', publicationId);
    return this.http.put<void>(`${this.baseUrl}/tag/sync`, { tagNames }, { params });
  }
  constructor() { }
}
