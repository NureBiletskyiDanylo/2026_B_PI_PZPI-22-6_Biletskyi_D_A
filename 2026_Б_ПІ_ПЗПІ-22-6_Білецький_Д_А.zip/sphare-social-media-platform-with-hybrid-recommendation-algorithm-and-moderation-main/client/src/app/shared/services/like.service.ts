import {inject, Injectable} from '@angular/core';
import {HttpClient} from "@angular/common/http";
import {environment} from "../../../environments/environment";
import {LikeDto} from "../models/like.dto";

@Injectable({
  providedIn: 'root'
})
export class LikeService {
  private http = inject(HttpClient);
  baseUrl = environment.apiUrl;

  likePublication(id: string) {
    return this.http.get<LikeDto>(this.baseUrl + "/publication/like/" + id);
  }
  constructor() { }
}
