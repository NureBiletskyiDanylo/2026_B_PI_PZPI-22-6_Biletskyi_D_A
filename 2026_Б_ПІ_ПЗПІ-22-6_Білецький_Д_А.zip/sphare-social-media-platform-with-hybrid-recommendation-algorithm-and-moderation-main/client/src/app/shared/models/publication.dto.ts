import {PublicUserBriefDto} from "../../features/publication/publication-card-view/models/publication.dto";
import {PublicationTypes} from "../../_models/publications/publicationModel";
import {
  ComparisonOperator,
  ConditionType
} from "../../features/publication/publication-create/models/create-publication.dto";

export interface PublicationDto {
  id: string;
  content: string | null;
  postedAt: string;
  updatedAt: string | null;
  images: string[];
  author: PublicUserBriefDto;
  likesAmount: number;
  isLikedByCurrentUser: boolean;
  commentAmount: number;
  publicationType: PublicationTypes;
  viewCount: number;
  isDeleted: boolean;
  isOwner: boolean;
  publishAt: string | null;
  conditionType: ConditionType | null;
  conditionTarget: number | null;
  comparisonOperator: ComparisonOperator | null;
  flaggedSpans: FlaggedSpan[];
}

export interface FlaggedSpan {
  start: number;
  end: number;
}
