export interface PagedList<T> {
  items: T[];
  totalCount: number;
  pageNumber: number;
  pageSize: number;
  totalPages: number;
  hasNextPage: boolean;
  hasPreviousPage: boolean;
}


export interface PaginationParams {
  page: number;
  pageSize: number;
}

export const defaultPaginationParams: PaginationParams = {
  page: 1,
  pageSize: 10
};

export const MAX_PAGE_SIZE = 50;
