export interface TagDto {
  id: number;
  name: string;
}

export interface GeneratedTagDto {
  name: string;
}

export interface CreateTagDto {
  name: string;
}
export interface SelectableTag {
  name: string;
  isLocked: boolean;
}
