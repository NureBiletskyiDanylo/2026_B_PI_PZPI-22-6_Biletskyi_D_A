export interface LikeDto {
  amountOfLikes: number;
  isLikedByCurrentUser: boolean;
}
