export const environment = {
    production: true,
  apiUrl: 'https://localhost:5000/api',
  baseUrl: 'https://localhost:5000',
  googleClientId: '774924023308-g0mo1dmhehul0rh0ghdjg04v2tg756me.apps.googleusercontent.com'
};
